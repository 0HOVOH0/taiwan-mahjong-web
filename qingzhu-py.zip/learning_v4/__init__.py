"""Versioned all-call decision environment and public-information learning."""

VERSION = "4.0"
