"""Public candidate teacher: compare pass, every call and legal follow-up discard."""
from learning_v4.features import analyze_actions, kind_of


def select_candidate(candidates):
    if not candidates:
        raise ValueError("no legal candidate")
    # Exact ties retain pass; a legal call is an opportunity, never an obligation.
    return min(candidates,key=lambda row:(row.score,kind_of(row.action)!="pass",row.action.to_dict()["kind"],tuple(row.action.tile_ids)))


class TeacherAgent:
    """Deterministic public efficiency/risk teacher; scores are not win probabilities."""
    def __init__(self):
        self.last_analysis = ()
        self.decisions = 0

    def analyze(self, view, legal_actions):
        self.last_analysis = analyze_actions(view,legal_actions)
        return self.last_analysis

    def act(self, view, legal_actions):
        rows = self.analyze(view,legal_actions)
        self.decisions += 1
        return select_candidate(rows).action
