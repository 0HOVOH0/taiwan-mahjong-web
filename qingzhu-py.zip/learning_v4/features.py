"""Comparable public after-action profiles for discard and every legal call.

All nonterminal candidates are compared at a waiting-hand boundary: ordinary
discards, chi/pong followed by their best legal discard, pass without drawing,
and a kong immediately before its unknown supplement. No hidden rollout is used.
"""
from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from engine.shanten import calculate_shanten, find_effective_tiles
from engine.tiles import Tile
from learning_v3.probability import (
    FEATURE_NAMES as V3_FEATURE_NAMES,
    hit_probability,
)
from learning_v4.belief import BELIEF_NOTE, analyze_beliefs

MAX_ACTIONS = 96
FEATURE_VERSION = "public-call-candidates-v4.1"
ACTION_KINDS = ("discard","declare_ready","pass","chi","pong","concealed_kong","added_kong","exposed_kong","win","draw")
FEATURE_NAMES = tuple(V3_FEATURE_NAMES) + tuple(f"action_{kind}" for kind in ACTION_KINDS) + (
    "after_fixed_meld_fraction", "after_concealed_tile_fraction", "menqing_loss",
    "declared_ready", "needs_post_call_discard", "needs_supplement",
    "supplement_progress_prior", "rob_kong_risk_score", "post_discard_risk_score",
    "shanten_gain_fraction", "ukeire_gain_fraction", "maximum_opponent_readiness_score",
    "maximum_opponent_open_fraction", "maximum_opponent_discard_pressure",
    "maximum_opponent_flush_hint", "target_retention_hint", "after_menqing",
    "call_meld_fraction",
)
FEATURE_DIM = len(FEATURE_NAMES)
assert FEATURE_DIM == 40


def kind_of(action):
    return str(getattr(action.kind,"value",action.kind))


def _action_key(action):
    return (ACTION_KINDS.index(kind_of(action)), tuple(sorted(Tile(int(t)).type_id for t in action.tile_ids)),
            -1 if action.meld_index is None else action.meld_index)


def canonical_actions(legal_actions):
    """Merge physical-copy equivalents only; retain each chi/kong/pass option."""
    selected = {}
    for action in legal_actions:
        kind = kind_of(action)
        if kind not in ACTION_KINDS:
            raise ValueError(f"unsupported V4 action {kind}")
        key = _action_key(action)
        previous = selected.get(key)
        if previous is None or tuple(action.tile_ids) < tuple(previous.tile_ids):
            selected[key] = action
    if not selected or len(selected) > MAX_ACTIONS:
        raise ValueError("V4 needs 1..96 distinct public legal actions")
    return tuple(selected[key] for key in sorted(selected))


@dataclass(frozen=True)
class HandProfile:
    shanten: int
    effective_types: tuple[int,...]
    unseen_count: int
    next_draw_prior: float
    horizon_hit_prior: float


@lru_cache(maxsize=65536)
def _profile(counts, fixed, known):
    shanten = calculate_shanten(counts,fixed_meld_count=fixed)
    effective = find_effective_tiles(counts,fixed_meld_count=fixed,visible_counts34=known)
    unseen = sum(4-known[k] for k in effective)
    population = sum(4-value for value in known)
    return HandProfile(shanten,effective,unseen,unseen/population if population else 0,
                       hit_probability(population,unseen,min(4,population)))


def _counts(hand):
    result = [0]*34
    for physical in hand:
        kind = Tile(physical).type_id
        if kind >= 34:
            raise ValueError("flowers cannot remain in concealed hand")
        result[kind] += 1
    if max(result,default=0)>4:
        raise ValueError("concealed hand exceeds four copies")
    return result


def _best_discard(counts, fixed, known, dangers, forbidden=()):
    options = []
    for kind,count in enumerate(counts):
        if count and kind not in forbidden:
            after = list(counts)
            after[kind] -= 1
            options.append((kind,_profile(tuple(after),fixed,known)))
    if not options:
        raise ValueError("a public call has no legal post-call discard")
    best = min(row.shanten for _,row in options)
    maximum = max(row.unseen_count for _,row in options if row.shanten==best)
    scale = .25 if best==0 else .55 if best==1 else 1
    return min(options,key=lambda item:(item[1].shanten+.35*max(0,maximum-item[1].unseen_count)/max(1,maximum)
                                       +2*scale*dangers[item[0]], item[0]))


@dataclass(frozen=True)
class ActionAnalysis:
    action: object
    features: np.ndarray
    score: float
    profile: HandProfile
    after_fixed_meld_count: int
    after_hand_count: int
    followup_discard_type: int | None
    menqing_loss: bool
    danger_score: float
    supplement_progress_prior: float
    rob_kong_risk_score: float
    explanation: dict

    @property
    def kind(self):
        return kind_of(self.action)

    def to_dict(self):
        return {"action":self.action.to_dict(),"score":self.score,"features":self.features.tolist(),
                "shanten":self.profile.shanten,"effective_types":list(self.profile.effective_types),
                "unseen_count":self.profile.unseen_count,"next_draw_prior":self.profile.next_draw_prior,
                "horizon_hit_prior":self.profile.horizon_hit_prior,"after_fixed_meld_count":self.after_fixed_meld_count,
                "after_hand_count":self.after_hand_count,"followup_discard_type":self.followup_discard_type,
                "menqing_loss":self.menqing_loss,"danger_score":self.danger_score,
                "supplement_progress_prior":self.supplement_progress_prior,"rob_kong_risk_score":self.rob_kong_risk_score,
                "explanation":self.explanation}


def analyze_actions(view, legal_actions):
    actions = canonical_actions(legal_actions)
    own = next(player for player in view["players"] if player["seat"]==view["viewer"])
    if not isinstance(own["hand"],list):
        raise TypeError("own concealed hand must be visible")
    counts = _counts(own["hand"])
    fixed = len(own["melds"])
    beliefs = analyze_beliefs(view)
    known = beliefs.known_counts
    population = sum(beliefs.unknown_counts)
    dangers = beliefs.danger_scores
    concealed = all(meld["kind"]=="concealed_kong" for meld in own["melds"])
    reaction = view.get("reaction")
    reaction_kind = Tile(reaction["tile_id"]).type_id if reaction else None
    ready = view.get("declared_ready",[False]*4)[view["viewer"]]
    discard_actions = [action for action in actions if kind_of(action) in ("discard","declare_ready")]
    if sum(counts)==16-3*fixed:
        baseline = _profile(tuple(counts),fixed,known)
    elif sum(counts)==17-3*fixed:
        allowed = {Tile(action.tile_ids[0]).type_id for action in discard_actions}
        forbidden = set(range(34))-allowed if allowed else set()
        _,baseline = _best_discard(counts,fixed,known,dangers,forbidden)
    else:
        raise ValueError("own hand does not match current fixed meld count")
    provisional = []
    for action in actions:
        kind = kind_of(action)
        after = list(counts)
        after_fixed = fixed
        followup = None
        danger = rob = supplement = 0.0
        needs_discard = kind in ("chi","pong")
        needs_supplement = kind in ("concealed_kong","added_kong","exposed_kong")
        breaks = concealed and kind in ("chi","pong","added_kong","exposed_kong")
        after_concealed = concealed and not breaks
        target = reaction_kind
        if kind in ("discard","declare_ready"):
            target = Tile(action.tile_ids[0]).type_id
            after[target] -= 1
            profile = _profile(tuple(after),fixed,known)
            danger = dangers[target]
        elif kind in ("chi","pong"):
            for tile in action.tile_ids:
                after[Tile(tile).type_id] -= 1
            after_fixed += 1
            forbidden = {reaction_kind}
            if kind=="chi":
                pair = [Tile(tile).type_id for tile in action.tile_ids]
                forbidden = {tile for tile in range(reaction_kind//9*9,reaction_kind//9*9+9)
                             if len(set(pair+[tile]))==3 and max(pair+[tile])-min(pair+[tile])==2}
            followup,profile = _best_discard(after,after_fixed,known,dangers,forbidden)
            after[followup] -= 1
            danger = dangers[followup]
        elif needs_supplement:
            for tile in action.tile_ids:
                after[Tile(tile).type_id] -= 1
            after_fixed += kind!="added_kong"
            profile = _profile(tuple(after),after_fixed,known)
            supplement = 0.0 if kind=="exposed_kong" and profile.shanten==0 else profile.next_draw_prior
            if kind=="added_kong":
                target = Tile(action.tile_ids[0]).type_id
                rob = dangers[target]
        elif kind in ("pass","draw"):
            profile = baseline
        elif kind=="win":
            profile = HandProfile(-1,(),0,0,0)
        else:
            raise ValueError("unhandled public action")
        if any(value<0 for value in after):
            raise ValueError("action consumes an absent concealed tile")
        provisional.append({"action":action,"kind":kind,"after":after,"fixed":after_fixed,"profile":profile,
                            "followup":followup,"danger":danger,"rob":rob,"supplement":supplement,
                            "breaks":breaks,"after_concealed":after_concealed,"needs_discard":needs_discard,
                            "needs_supplement":needs_supplement,"target":target})
    ordinary = [row for row in provisional if row["kind"] not in ("win","draw")]
    best_shanten = min((row["profile"].shanten for row in ordinary),default=baseline.shanten)
    maximum_unseen = max((row["profile"].unseen_count for row in ordinary if row["profile"].shanten==best_shanten),default=1)
    maximum_threat = beliefs.maximum_threat
    discards = [row for row in provisional if row["kind"] in ("discard","declare_ready")]
    discard_best = min((row["profile"].shanten for row in discards),default=baseline.shanten)
    discard_best_unseen = max((row["profile"].unseen_count for row in discards if row["profile"].shanten==discard_best),default=1)
    discard_maximum_unseen = max((row["profile"].unseen_count for row in discards),default=1)
    results = []
    for row in provisional:
        profile,kind = row["profile"],row["kind"]
        scale = .25 if profile.shanten==0 else .55 if profile.shanten==1 else 1
        efficiency_cost = .35*max(0,maximum_unseen-profile.unseen_count)/max(1,maximum_unseen)
        score = float(profile.shanten+efficiency_cost+2*scale*row["danger"]+.15*row["breaks"]
                      +.2*row["rob"]-.08*row["supplement"])
        if kind=="exposed_kong" and profile.shanten==0:
            score += .2*profile.next_draw_prior
        if kind=="declare_ready":
            score -= .01
        if kind=="win":
            score = -1000.0
        elif kind=="draw":
            score = -100.0
        if kind in ("discard","declare_ready"):
            # Reproduce V3's first twelve features without computing public risk
            # a second time. Calls do not alter the old base danger calculation.
            old_scale = .25 if discard_best==0 else .55 if discard_best==1 else 1
            old_score = (profile.shanten-discard_best+.35*max(0,discard_best_unseen-profile.unseen_count)/max(1,discard_best_unseen)
                         +2*old_scale*beliefs.base_danger_scores[row["target"]])
            allowance = int(discard_best>=2 and beliefs.base_maximum_threat>=.9)
            first = np.asarray((profile.shanten/8,(profile.shanten-discard_best)/8,profile.unseen_count/136,
                                profile.unseen_count/max(1,discard_maximum_unseen),profile.next_draw_prior,profile.horizon_hit_prior,
                                beliefs.base_danger_scores[row["target"]],beliefs.base_maximum_threat,min(1,max(0,old_score/4)),
                                float(profile.shanten<=discard_best+allowance),view.get("live_tiles",0)/144,population/136),dtype=np.float32)
        else:
            first = np.asarray((max(0,profile.shanten)/8,max(0,profile.shanten-best_shanten)/8,profile.unseen_count/136,
                                profile.unseen_count/max(1,maximum_unseen),profile.next_draw_prior,profile.horizon_hit_prior,
                                row["danger"],maximum_threat,min(1,max(0,score/4)),float(profile.shanten==best_shanten),
                                view.get("live_tiles",0)/144,population/136),dtype=np.float32)
            first = np.clip(first,0,1)
        action_bits = np.zeros(len(ACTION_KINDS),dtype=np.float32)
        action_bits[ACTION_KINDS.index(kind)] = 1
        opponents = beliefs.opponents
        tail = np.asarray((row["fixed"]/5,sum(row["after"])/17,float(row["breaks"]),float(ready or kind=="declare_ready"),
                           float(row["needs_discard"]),float(row["needs_supplement"]),row["supplement"],row["rob"],row["danger"],
                           (baseline.shanten-profile.shanten+8)/16,(profile.unseen_count-baseline.unseen_count+136)/272,
                           maximum_threat,max((p.open_meld_count/5 for p in opponents),default=0),
                           min(1,max((sum(p.discard_counts)/32 for p in opponents),default=0)),
                           max((p.flush_hint for p in opponents),default=0),
                           beliefs.target_retention_scores[row["target"]] if row["target"] is not None else .5,
                           float(row["after_concealed"]),row["fixed"]/5),dtype=np.float32)
        features = np.clip(np.concatenate((first,action_bits,tail)),0,1).astype(np.float32)
        if features.shape!=(FEATURE_DIM,) or not np.isfinite(features).all():
            raise ValueError("invalid public action features")
        explanation = {"comparison_boundary":"waiting hand after mandatory discard, or before unknown supplement",
                       "baseline_shanten":baseline.shanten,"baseline_unseen_count":baseline.unseen_count,
                       "maximum_opponent_threat_score":maximum_threat,"estimated_after_menqing":row["after_concealed"],
                       "kong_draw_origin":"exposed_kong_no_self_draw" if kind=="exposed_kong" else kind if row["needs_supplement"] else None,
                       "post_call_forbidden_types_applied":bool(row["needs_discard"]),"note":BELIEF_NOTE}
        results.append(ActionAnalysis(row["action"],features,score,profile,row["fixed"],sum(row["after"]),row["followup"],
                                      bool(row["breaks"]),float(row["danger"]),float(row["supplement"]),float(row["rob"]),explanation))
    return tuple(results)


def candidate_matrix(candidates):
    if not candidates or len(candidates)>MAX_ACTIONS:
        raise ValueError("invalid candidate count")
    features = np.zeros((MAX_ACTIONS,FEATURE_DIM),dtype=np.float32)
    mask = np.zeros(MAX_ACTIONS,dtype=np.float32)
    for index,row in enumerate(candidates):
        features[index] = row.features
        mask[index] = 1
    return features,mask
