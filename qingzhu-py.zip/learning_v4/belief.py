"""Public opponent-shape estimates, never a reconstruction of real hidden hands.

The expected counts and example samples are hypotheses under an explicit biased
unseen-pool prior.  They are not calibrated waiting/deal-in probabilities.
"""
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json

import numpy as np

from agents.heuristic_agent import visible_counts34
from engine.tiles import Tile
from strategies.public_risk import analyze_public_risk, public_discards

BELIEF_VERSION = "public-shape-hints-v4.1"
BELIEF_NOTE = (
    "public discard/meld-conditioned heuristic and biased unseen-pool hypotheses; "
    "not real concealed hands and not calibrated readiness, deal-in or win probabilities"
)


def _bounded(value):
    return max(0.0, min(1.0, float(value)))


@dataclass(frozen=True)
class OpponentBelief:
    seat: int
    hand_count: int
    declared_ready: bool
    open_meld_count: int
    concealed_kong_count: int
    discard_counts: tuple[int, ...]
    exposed_counts: tuple[int, ...]
    suit_retention: tuple[float, ...]
    readiness_score: float
    flush_hint: float
    expected_counts: tuple[float, ...]

    def to_dict(self):
        data = asdict(self)
        data["most_supported_types"] = sorted(range(34), key=lambda k: (-self.expected_counts[k], k))[:6]
        data["note"] = BELIEF_NOTE
        return data


@dataclass(frozen=True)
class PublicBeliefs:
    known_counts: tuple[int, ...]
    unknown_counts: tuple[int, ...]
    opponents: tuple[OpponentBelief, ...]
    danger_scores: tuple[float, ...]
    call_support_scores: tuple[float, ...]
    target_retention_scores: tuple[float, ...]
    base_danger_scores: tuple[float, ...]
    base_maximum_threat: float

    @property
    def maximum_threat(self):
        return max((row.readiness_score for row in self.opponents), default=0.0)

    def to_dict(self):
        return {"version": BELIEF_VERSION, "known_counts": list(self.known_counts),
                "unknown_counts": list(self.unknown_counts), "opponents": [row.to_dict() for row in self.opponents],
                "danger_scores": list(self.danger_scores), "call_support_scores": list(self.call_support_scores),
                "target_retention_scores": list(self.target_retention_scores), "note": BELIEF_NOTE}


def _expected_counts(unknown, size, weights):
    """Capacity-constrained mean allocation; no independent-copy overcounting."""
    result = np.zeros(34, dtype=np.float64)
    capacity = np.asarray(unknown, dtype=np.float64)
    remaining = float(size)
    for _ in range(35):
        room = capacity-result
        active = room > 1e-12
        if remaining <= 1e-10 or not active.any():
            break
        weighted = np.where(active, np.asarray(weights)*room, 0.0)
        if weighted.sum() <= 0:
            weighted = room
        allocated = np.minimum(room, remaining*weighted/weighted.sum())
        result += allocated
        remaining = float(size)-float(result.sum())
    if abs(float(result.sum())-size) > 1e-7:
        raise ValueError("unseen-pool expected hand cannot meet public hand size")
    return tuple(float(value) for value in result)


def analyze_beliefs(view):
    """Read own hand, all public rivers/melds and public history only."""
    known = visible_counts34(view)
    if any(not 0 <= count <= 4 for count in known):
        raise ValueError("invalid public tile count")
    unknown = tuple(4-count for count in known)
    population = sum(unknown)
    ready = view.get("declared_ready", [False]*4)
    if len(ready) != 4 or any(type(value) is not bool for value in ready):
        raise ValueError("declared_ready must contain four bool flags")
    opponents = []
    for player in view["players"]:
        seat = player["seat"]
        if seat == view["viewer"]:
            continue
        size = player["hand_count"]
        if type(size) is not int or not 0 <= size <= population:
            raise ValueError("invalid public concealed hand size")
        discards = public_discards(view, player)
        exposed = Counter()
        suit_melds = Counter()
        open_count = concealed_count = 0
        for meld in player["melds"]:
            ids = meld["tile_ids"]
            if meld["kind"] == "concealed_kong":
                concealed_count += 1
            else:
                open_count += 1
            if ids is not None:
                kinds = [Tile(tile).type_id for tile in ids]
                exposed.update(kinds)
                groups = {kind//9 if kind < 27 else 3 for kind in kinds}
                if len(groups) == 1:
                    suit_melds[next(iter(groups))] += 1
        discarded_groups = [sum(count for kind,count in discards.items() if (kind//9 if kind < 27 else 3) == group) for group in range(4)]
        total = sum(discarded_groups)
        preferred, concentration = (suit_melds.most_common(1)[0] if suit_melds else (-1,0))
        flush_hint = _bounded((concentration-1)/3) if preferred in range(3) else 0.0
        retention = []
        for group in range(4):
            weight = 1-.45*(discarded_groups[group]/max(1,total))
            if preferred in range(3):
                weight *= 1+.25*concentration if group == preferred else max(.65,1-.08*concentration)
            retention.append(float(np.clip(weight,.35,2.0)))
        weights = [retention[kind//9 if kind < 27 else 3]/(1+.18*discards[kind]) for kind in range(34)]
        threat = 1.0 if ready[seat] else min(.9,.12+.02*total+.12*open_count+.04*concealed_count)
        opponents.append(OpponentBelief(seat,size,ready[seat],open_count,concealed_count,
                                       tuple(discards[k] for k in range(34)),tuple(exposed[k] for k in range(34)),
                                       tuple(retention),float(threat),flush_hint,_expected_counts(unknown,size,weights)))
    base = analyze_public_risk(view, opponent_calls=True)
    by_seat = {row.seat:row for row in opponents}
    dangers, supports, retention_scores = [], [], []
    for row in base:
        components, affinities = [], []
        for other in row.opponents:
            estimate = by_seat[other.seat]
            group = row.type_id//9 if row.type_id < 27 else 3
            affinity = estimate.suit_retention[group]/max(.01,max(estimate.suit_retention))
            pressure_ratio = estimate.readiness_score/max(.01,other.threat_score)
            components.append(_bounded(other.danger_score*pressure_ratio*(.75+.35*affinity)))
            affinities.append(affinity)
        components.sort(reverse=True)
        dangers.append(_bounded(sum(weight*value for weight,value in zip((1,.15,.075),components,strict=True))))
        supports.append(float(row.call_opportunity_score))
        retention_scores.append(float(max(affinities,default=0.0)))
    return PublicBeliefs(tuple(known),unknown,tuple(opponents),tuple(dangers),tuple(supports),tuple(retention_scores),
                         tuple(row.danger_score for row in base),
                         max((other.threat_score for other in base[0].opponents),default=0.0))


def sample_possible_hand_types(view, seat, *, samples=4):
    """Deterministic examples from public hypotheses; not actual or joint hands."""
    if type(samples) is not int or not 1 <= samples <= 128:
        raise ValueError("samples must be 1..128")
    beliefs = analyze_beliefs(view)
    row = next((entry for entry in beliefs.opponents if entry.seat == seat),None)
    if row is None:
        raise ValueError("seat must name an opponent")
    signature = json.dumps({"known":beliefs.known_counts,"opponent":row.to_dict()},sort_keys=True,separators=(",",":"))
    rng = np.random.default_rng(int.from_bytes(hashlib.sha256(signature.encode()).digest()[:8],"big"))
    results = []
    base_weight = np.asarray(row.expected_counts,dtype=np.float64)/np.maximum(1,np.asarray(beliefs.unknown_counts))
    for _ in range(samples):
        remaining = np.asarray(beliefs.unknown_counts,dtype=np.int64).copy()
        counts = np.zeros(34,dtype=np.int64)
        for _ in range(row.hand_count):
            weight = remaining*base_weight
            if weight.sum() == 0:
                weight = remaining.astype(float)
            kind = int(rng.choice(34,p=weight/weight.sum()))
            counts[kind] += 1
            remaining[kind] -= 1
        results.append(tuple(int(value) for value in counts))
    return tuple(results)
