"""Public-information discard candidates and finite-population draw priors.

The unseen non-flower population contains opponents' concealed tiles and reserved
tiles as well as drawable wall tiles. Draws mean non-flower draws after automatic
flower replacement. K/N and the hypergeometric probability below are
exchangeable unseen-pool priors, not calibrated live-wall, winning, or deal-in
probabilities.  A horizon is a specified number of hypothetical own draws; it
does not assert that a hand will last that long or that the effective set stays
unchanged after subsequent discards.
"""

from dataclasses import dataclass
from math import comb

import numpy as np

from agents.heuristic_agent import visible_counts34
from strategies.balanced import analyze_balanced_discards

FEATURE_VERSION = "public-candidate-v3.1"
FEATURE_NAMES = (
    "shanten_fraction",
    "shanten_excess_fraction",
    "unseen_fraction",
    "relative_unseen",
    "next_draw_prior",
    "horizon_hit_prior",
    "danger_score",
    "maximum_threat",
    "balanced_score_fraction",
    "eligible",
    "live_fraction",
    "unknown_fraction",
)
PROBABILITY_NOTE = (
    "exchangeable unseen-pool prior including unknown opponent hands and reserved "
    "tiles; hypothetical draws without replacement, fixed effective set; not a "
    "calibrated live-wall, winning, or deal-in probability"
)


def hit_probability(population: int, effective: int, draws: int) -> float:
    """P(at least one effective tile in draws), sampling without replacement.

    All copies are exchangeable under the stated public-information prior.  The
    caller must not supply private wall or opponent-hand information.
    """
    if any(type(value) is not int for value in (population, effective, draws)):
        raise TypeError("population, effective and draws must be integers")
    if not 0 <= effective <= population or not 0 <= draws <= population:
        raise ValueError("require 0 <= effective, draws <= population")
    if not effective or not draws:
        return 0.0
    if draws > population - effective:
        return 1.0
    return 1.0 - comb(population - effective, draws) / comb(population, draws)


@dataclass(frozen=True)
class Candidate:
    """One legal discard type; duplicate physical copies are merged safely."""

    efficiency: object
    risk: object
    unknown_count: int
    effective_unseen_counts: tuple[tuple[int, int], ...]
    horizon_draws: int
    next_draw_prior: float
    horizon_hit_prior: float
    balanced_score: float
    eligible: bool
    maximum_threat: float

    @property
    def type_id(self):
        return self.efficiency.type_id

    @property
    def tile_id(self):
        return self.efficiency.tile_id

    @property
    def action(self):
        return self.efficiency.action

    @property
    def shanten(self):
        return self.efficiency.shanten

    @property
    def effective_types(self):
        return self.efficiency.effective_types

    @property
    def unseen_count(self):
        return self.efficiency.unseen_count

    @property
    def danger_score(self):
        return self.risk.danger_score

    def to_dict(self):
        return {
            **self.efficiency.to_dict(),
            "public_risk": self.risk.to_dict(),
            "unknown_count": self.unknown_count,
            "effective_unseen_counts": [
                {"type_id": kind, "unseen_count": copies}
                for kind, copies in self.effective_unseen_counts
            ],
            "horizon_draws": self.horizon_draws,
            "next_draw_prior": self.next_draw_prior,
            "horizon_hit_prior": self.horizon_hit_prior,
            "balanced_score": self.balanced_score,
            "eligible": self.eligible,
            "maximum_threat": self.maximum_threat,
            "probability_note": PROBABILITY_NOTE,
        }


def analyze_candidates(view, legal_actions, *, horizon=4, strategy_config=None):
    """Analyze every legal discard using own hand and public tiles only.

    Known copies include the tile about to be discarded: moving it from one's
    hand to a river cannot make an extra unknown copy appear.  Physical IDs are
    deduplicated by the project's public visible-count helper.  Results are in
    tile-type order; no strategy choice is hidden inside this feature function.
    """
    if type(horizon) is not int or horizon < 0:
        raise ValueError("horizon must be a nonnegative integer")
    known = visible_counts34(view)
    if any(not 0 <= count <= 4 for count in known):
        raise ValueError("public known counts must stay between zero and four")
    unknown = tuple(4 - count for count in known)
    population = sum(unknown)
    effective_draws = min(horizon, population)
    analyses = analyze_balanced_discards(
        view, legal_actions, config=strategy_config
    )
    result = []
    for row in analyses:
        efficiency = row.efficiency
        count = sum(unknown[kind] for kind in efficiency.effective_types)
        if count != efficiency.unseen_count:
            raise ValueError("effective-copy total disagrees with public analysis")
        result.append(
            Candidate(
                efficiency=efficiency,
                risk=row.risk,
                unknown_count=population,
                effective_unseen_counts=tuple(
                    (kind, unknown[kind]) for kind in efficiency.effective_types
                ),
                horizon_draws=effective_draws,
                next_draw_prior=count / population if population else 0.0,
                horizon_hit_prior=hit_probability(
                    population, count, effective_draws
                ),
                balanced_score=row.score,
                eligible=row.eligible,
                maximum_threat=max(
                    (other.threat_score for other in row.risk.opponents), default=0.0
                ),
            )
        )
    return tuple(sorted(result, key=lambda row: row.type_id))


def feature_matrix(candidates, view):
    """Return float32[35, F]; legal mask is supplied separately by the caller.

    Tile-type identity is deliberately absent from candidate features: the same
    scorer is applied to every legal discard.  Public heuristic danger remains a
    score, distinct from the finite-population probabilities.
    """
    result = np.zeros((35, len(FEATURE_NAMES)), dtype=np.float32)
    if not candidates:
        return result
    kinds = [candidate.type_id for candidate in candidates]
    if len(kinds) != len(set(kinds)) or any(kind not in range(34) for kind in kinds):
        raise ValueError("candidate tile types must be unique and in 0..33")
    best_shanten = min(candidate.shanten for candidate in candidates)
    maximum_unseen = max(candidate.unseen_count for candidate in candidates)
    live = view.get("live_tiles", 0)
    if type(live) is not int or not 0 <= live <= 144:
        raise ValueError("public live_tiles must be an integer in 0..144")
    for row in candidates:
        result[row.type_id] = (
            row.shanten / 8,
            (row.shanten - best_shanten) / 8,
            row.unseen_count / 136,
            row.unseen_count / max(1, maximum_unseen),
            row.next_draw_prior,
            row.horizon_hit_prior,
            row.danger_score,
            row.maximum_threat,
            min(1.0, max(0.0, row.balanced_score / 4)),
            float(row.eligible),
            live / 144,
            row.unknown_count / 136,
        )
    if not np.isfinite(result).all() or np.any(result < 0) or np.any(result > 1):
        raise ValueError("candidate features must be finite and in [0,1]")
    return result
