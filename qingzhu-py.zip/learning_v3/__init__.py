"""V3 public-information candidate model and probability-guided discard policy."""

VERSION = "v3.1"
