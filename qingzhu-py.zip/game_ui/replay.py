"""Bounded public replay validation. Imported records are descriptive, not executable."""

import json
import math
from collections import Counter

FORMAT = "public-mahjong-replay-v2"
MAX_BYTES = 8 * 1024 * 1024
SNAPSHOT_KEYS = set(
    [
        "version",
        "viewer",
        "phase",
        "dealer",
        "live_tiles",
        "players",
        "actions",
        "recommendation_method",
        "model_loaded",
        "model_name",
        "finished",
        "result",
        "terminal_reason",
        "events",
        "probability_note",
        "reaction",
        "chosen",
        "outcome_forecast",
        "hints",
    ]
)
ACTION_KEYS = set(
    [
        "kind",
        "types",
        "label",
        "id",
        "recommended",
        "preference",
        "shanten",
        "ukeire",
        "next_draw_prior",
        "four_draw_prior",
        "danger_score",
        "unseen_population",
        "horizon_draws",
        "followup_discard_type",
        "effective_tiles",
        "needs_discard",
        "needs_supplement",
        "teacher_recommended",
    ]
)
KINDS = {
    "discard",
    "declare_ready",
    "pass",
    "chi",
    "pong",
    "exposed_kong",
    "concealed_kong",
    "added_kong",
    "win",
    "draw",
}


def obj(value, keys, label):
    if not isinstance(value, dict) or set(value) - keys:
        raise ValueError(f"{label} 含未知欄位或不是物件")
    return value


def integer(value, lo, hi, label):
    if type(value) is not int or not lo <= value <= hi:
        raise ValueError(f"{label} 超出範圍")
    return value


def text(value, limit=300):
    if not isinstance(value, str) or len(value) > limit:
        raise ValueError("紀錄文字欄位不正確或過長")
    return value


def tiles(value, maximum=136, *, flower=False):
    if not isinstance(value, list) or len(value) > maximum:
        raise ValueError("牌面清單長度不正確")
    for t in value:
        integer(t, 34 if flower else 0, 41 if flower else 33, "牌面")
    return value


def validate_replay(raw):
    # Reject nested hidden information rather than silently copying extra keys.
    obj(raw, {"format", "snapshots", "metadata"}, "公開紀錄")
    if raw.get("format") not in (FORMAT, "public-mahjong-replay-v1"):
        raise ValueError("只接受青竹下載的公開對局紀錄")
    if len(json.dumps(raw, ensure_ascii=False, allow_nan=False).encode()) > MAX_BYTES:
        raise ValueError("公開紀錄超過 8 MB")
    meta = obj(
        raw.get("metadata", {}),
        {"rules_version", "rules_sha256", "model_name", "model_sha256"},
        "紀錄版本",
    )
    for value in meta.values():
        text(value)
    if meta.get("rules_version", "tw16-calls-0.6") != "tw16-calls-0.6":
        raise ValueError("這份紀錄使用其他規則版本")
    snapshots = raw.get("snapshots")
    if not isinstance(snapshots, list) or not 1 <= len(snapshots) <= 400:
        raise ValueError("公開紀錄須含 1 至 400 個局面")
    viewer = None
    for index, s in enumerate(snapshots):
        obj(s, SNAPSHOT_KEYS - {"outcome_forecast"}, "局面")
        seat = integer(s.get("viewer"), 0, 3, "玩家座位")
        viewer = seat if viewer is None else viewer
        if viewer != seat:
            raise ValueError("同一紀錄不可切換玩家視角")
        if index and snapshots[index - 1]["finished"]:
            raise ValueError("結算後不可接續其他局面")
        if s.get("phase") not in ("draw", "discard", "reaction", "finished"):
            raise ValueError("局面階段不正確")
        if type(s.get("finished")) is not bool or s["finished"] != (
            s["phase"] == "finished"
        ):
            raise ValueError("結算標記與階段不一致")
        integer(s.get("dealer"), 0, 3, "莊家")
        integer(s.get("live_tiles"), 0, 144, "剩餘牌數")
        for key in (
            "version",
            "recommendation_method",
            "model_name",
            "probability_note",
        ):
            text(s.get(key, ""))
        if "hints" in s and type(s["hints"]) is not bool:
            raise ValueError("提示設定格式錯誤")
        if type(s.get("model_loaded")) is not bool:
            raise ValueError("模型狀態格式錯誤")
        players = s.get("players")
        if not isinstance(players, list) or len(players) != 4:
            raise ValueError("紀錄須包含四個座位")
        known, flowers = [], []
        for i, p in enumerate(players):
            obj(
                p,
                {
                    "seat",
                    "wind",
                    "hand_count",
                    "hand",
                    "river",
                    "flowers",
                    "ready",
                    "melds",
                },
                "玩家",
            )
            if (
                p.get("seat") != i
                or type(p.get("seat")) is not int
                or p.get("wind") not in ("east", "south", "west", "north")
            ):
                raise ValueError("玩家座位順序或風位錯誤")
            integer(p.get("hand_count"), 0, 17, "手牌張數")
            if type(p.get("ready")) is not bool:
                raise ValueError("聽牌標記格式錯誤")
            if i == viewer:
                known += tiles(p.get("hand"), 17)
                if len(p["hand"]) != p["hand_count"]:
                    raise ValueError("自己手牌張數不一致")
            elif p.get("hand") is not None:
                raise ValueError("公開紀錄不可含其他玩家暗手牌")
            known += tiles(p.get("river"), 120)
            flowers += tiles(p.get("flowers"), 8, flower=True)
            if not isinstance(p.get("melds"), list) or len(p["melds"]) > 5:
                raise ValueError("固定面子不正確")
            for m in p["melds"]:
                obj(m, {"kind", "tiles"}, "固定面子")
                if m.get("kind") not in (
                    "chi",
                    "pong",
                    "exposed_kong",
                    "concealed_kong",
                    "added_kong",
                ):
                    raise ValueError("固定面子種類不正確")
                if i != viewer and m["kind"] == "concealed_kong":
                    if m.get("tiles") is not None:
                        raise ValueError("不可揭露他家的暗槓牌面")
                    continue
                group = sorted(tiles(m.get("tiles"), 4))
                count = 3 if m["kind"] in ("chi", "pong") else 4
                if len(group) != count:
                    raise ValueError("固定面子張數錯誤")
                if m["kind"] == "chi":
                    if (
                        group[-1] >= 27
                        or group[0] // 9 != group[-1] // 9
                        or group != list(range(group[0], group[0] + 3))
                    ):
                        raise ValueError("順子牌面不正確")
                elif len(set(group)) != 1:
                    raise ValueError("碰槓必須同種牌")
                known += group
        if max(Counter(known).values(), default=0) > 4 or len(set(flowers)) != len(
            flowers
        ):
            raise ValueError("公開牌面超過四張或花牌重複")
        actions = s.get("actions")
        if (
            not isinstance(actions, list)
            or len(actions) > 100
            or (s["finished"] and actions)
        ):
            raise ValueError("候選動作數量錯誤")
        ids = set()
        for a in actions:
            obj(a, ACTION_KEYS, "候選動作")
            if a.get("kind") not in KINDS:
                raise ValueError("候選動作種類錯誤")
            key = text(a.get("id"), 80)
            if key in ids:
                raise ValueError("動作 ID 重複")
            ids.add(key)
            text(a.get("label"), 100)
            tiles(a.get("types"), 4)
            integer(a.get("shanten"), -1, 16, "向聽數")
            integer(a.get("ukeire"), 0, 136, "有效未見牌")
            integer(a.get("unseen_population"), 0, 136, "未見牌數")
            integer(a.get("horizon_draws"), 0, 4, "抽樣次數")
            for flag in ("recommended", "needs_discard", "needs_supplement"):
                if type(a.get(flag)) is not bool:
                    raise ValueError("候選標記格式錯誤")
            if (
                "teacher_recommended" in a
                and type(a["teacher_recommended"]) is not bool
            ):
                raise ValueError("規則教師標記格式錯誤")
            for name in (
                "preference",
                "next_draw_prior",
                "four_draw_prior",
                "danger_score",
            ):
                value = a.get(name)
                if name == "preference" and value is None:
                    continue
                if (
                    type(value) not in (int, float)
                    or not math.isfinite(value)
                    or not 0 <= value <= 1
                ):
                    raise ValueError("機率或分數欄位不正確")
            if a.get("followup_discard_type") is not None:
                integer(a["followup_discard_type"], 0, 33, "後續棄牌")
            if (
                not isinstance(a.get("effective_tiles"), list)
                or len(a["effective_tiles"]) > 34
            ):
                raise ValueError("進張清單錯誤")
            for e in a["effective_tiles"]:
                obj(e, {"type", "name", "unseen"}, "進張")
                integer(e.get("type"), 0, 33, "進張牌面")
                integer(e.get("unseen"), 0, 4, "未見進張數")
                text(e.get("name"), 10)
        if not s["finished"] and (
            not actions or sum(a["recommended"] for a in actions) != 1
        ):
            raise ValueError("非結算局面須有動作及一個建議")
        if s.get("chosen") is not None and s["chosen"] not in ids:
            raise ValueError("選擇的動作不在候選清單")
        if s.get("reaction") is not None:
            obj(s["reaction"], {"source", "tile"}, "反應")
            integer(s["reaction"].get("source"), 0, 3, "來源座位")
            integer(s["reaction"].get("tile"), 0, 33, "反應牌面")
        if s.get("terminal_reason") is not None:
            text(s["terminal_reason"])
        events = s.get("events")
        if not isinstance(events, list) or len(events) > 28:
            raise ValueError("公開事件數量錯誤")
        for event in events:
            obj(event, {"kind", "player", "types", "tile_count"}, "公開事件")
            integer(event.get("tile_count"), 0, 4, "事件張數")
            text(event.get("kind"), 40)
            player = integer(event.get("player"), 0, 3, "事件玩家")
            ts = event.get("types")
            if not isinstance(ts, list) or len(ts) > 4:
                raise ValueError("公開事件牌面錯誤")
            for t in ts:
                integer(t, 0, 41, "事件牌面")
            if event["kind"] == "draw" and player != viewer and ts:
                raise ValueError("不可揭露他家的摸牌")
        result = s.get("result")
        if s["finished"]:
            obj(
                result,
                {"winners", "source_player", "tai", "patterns", "payments"},
                "結算",
            )
            if (
                not isinstance(result.get("payments"), list)
                or len(result["payments"]) != 4
            ):
                raise ValueError("結算付款格式錯誤")
            for payment in result["payments"]:
                integer(payment, -10000000, 10000000, "付款")
            if sum(result["payments"]) != 0:
                raise ValueError("結算付款合計不為零")
            if (
                not isinstance(result.get("winners"), list)
                or len(result["winners"]) > 1
            ):
                raise ValueError("胡牌玩家格式錯誤")
            for winner in result["winners"]:
                integer(winner, 0, 3, "胡牌玩家")
            if result.get("source_player") is not None:
                integer(result["source_player"], 0, 3, "放槍玩家")
            if (
                not isinstance(result.get("tai"), list)
                or len(result["tai"]) != 4
                or not isinstance(result.get("patterns"), list)
                or len(result["patterns"]) != 4
            ):
                raise ValueError("台數格式錯誤")
            for tai, patterns in zip(result["tai"], result["patterns"]):
                integer(tai, 0, 10000, "台數")
                if not isinstance(patterns, list) or len(patterns) > 60:
                    raise ValueError("台型格式錯誤")
                for pattern in patterns:
                    text(pattern, 100)
        elif result is not None:
            raise ValueError("尚未結算局面不可含結算")
    return raw


def export_table(table):
    advisor = table.advisor
    return {
        "format": FORMAT,
        "metadata": {
            "rules_version": advisor.rules.version,
            "model_name": table.snapshot["model_name"],
            "rules_sha256": __import__("hashlib")
            .sha256(
                json.dumps(
                    advisor.rules.to_dict(),
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode()
            )
            .hexdigest(),
            "model_sha256": getattr(advisor, "manifest", {}).get("model_sha256", ""),
        },
        "snapshots": table.history,
    }
