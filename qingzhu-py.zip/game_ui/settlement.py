"""結算亮牌：只在本局結束後公開四家手牌與計台明細。

這份資料不寫入 Table.history，因此下載的公開對局紀錄仍只包含當時看得到的資訊，
replay.py 的格式與驗證規則不受影響。台數明細來自引擎 calculate_tai 的原始結果，
並與 snapshot.result 的台數、台型及付款逐項核對；不一致時只回傳總台數，不自行推算。
"""

from engine_v4.tiles import Tile

TAI_NAMES = {
    "self_draw": "自摸",
    "concealed_hand": "門清",
    "concealed_self_draw": "門清自摸",
    "seat_wind": "門風",
    "round_wind": "圈風",
    "dragon_triplet_each": "三元牌",
    "seat_flower_each": "正花",
    "flower_set_each": "花槓",
    "all_sequences": "平胡",
    "all_triplets": "碰碰胡",
    "three_concealed_triplets": "三暗刻",
    "four_concealed_triplets": "四暗刻",
    "five_concealed_triplets": "五暗刻",
    "fully_exposed_discard_win": "全求人",
    "half_exposed_self_draw": "半求人",
    "half_flush": "混一色",
    "full_flush": "清一色",
    "all_honors": "字一色",
    "small_three_dragons": "小三元",
    "big_three_dragons": "大三元",
    "small_four_winds": "小四喜",
    "big_four_winds": "大四喜",
    "replacement_draw_win": "槓上／花上自摸",
    "rob_added_kong": "搶槓",
    "last_normal_draw_win": "海底撈月",
    "middle_wait": "中洞",
    "edge_wait": "邊張",
    "single_pair_wait": "單吊",
    "declared_ready": "宣告聽牌",
    "human_win": "人胡",
}
# 「每組／每張」計算的台型：台數 = 單位台數 × 數量
EACH_UNIT = {"dragon_triplet_each": "組", "seat_flower_each": "張", "flower_set_each": "組"}


def _types(ids):
    return [Tile(t).type_id for t in ids]


def build_settlement(table):
    """回傳結算亮牌資料；牌局未結束時回傳 None。"""
    snapshot = table.snapshot
    if snapshot is None or not snapshot["finished"]:
        return None
    game = table.game
    state = game.state
    result = snapshot["result"] or {}
    winners = list(result.get("winners") or [])
    winning_id = getattr(game.turn, "winning_tile", None)
    winning_type = None if winning_id is None else Tile(winning_id).type_id

    players = []
    for p in state.players:
        hand = sorted(_types(p.hand))
        # 自摸時完成牌已在手中；放槍時引擎只在計台時暫時加入。統一拆出來另外顯示。
        complete = len(p.hand) + 3 * len(p.melds) == 17
        if p.seat in winners and winning_type is not None and complete and winning_type in hand:
            hand.remove(winning_type)
        players.append(
            {
                "seat": p.seat,
                "wind": p.seat_wind.value,
                "hand": hand,
                "melds": [
                    {"kind": m.kind.value, "tiles": sorted(_types(m.tile_ids))}
                    for m in p.melds
                ],
                "flowers": sorted(_types(p.flowers)),
            }
        )

    scoring = None
    if winners:
        winner = winners[0]
        table_rules = table.advisor.rules.table_rules
        base = table_rules["base_points"]
        per_tai = table_rules["points_per_tai"]
        bonus = table_rules["dealer_bonus"]
        streak = getattr(state, "dealer_streak", 0)
        pattern_tai = result["tai"][winner]
        score = getattr(table, "win_scores", {}).get(winner)
        items = None
        if (
            score is not None
            and score.tai == pattern_tai
            and [i.code for i in score.items] == list(result["patterns"][winner])
        ):
            items = []
            for item in score.items:
                unit = table_rules["tai_table"][item.code]
                entry = {
                    "code": item.code,
                    "name": TAI_NAMES.get(item.code, item.code),
                    "tai": item.tai,
                }
                if item.code in EACH_UNIT and unit:
                    entry["count"] = item.tai // unit
                    entry["unit"] = EACH_UNIT[item.code]
                items.append(entry)
        payers = []
        for seat in range(4):
            amount = -result["payments"][seat]
            if seat == winner or amount <= 0:
                continue
            dealer_tai = (
                bonus["initial_tai"] + bonus["per_continuation_tai"] * streak
                if state.dealer in (seat, winner)
                else 0
            )
            payers.append(
                {
                    "seat": seat,
                    "amount": amount,
                    "dealer_tai": dealer_tai,
                    "formula_ok": amount == base + per_tai * (pattern_tai + dealer_tai),
                }
            )
        scoring = {
            "winner": winner,
            "source_player": result.get("source_player"),
            "pattern_tai": pattern_tai,
            "items": items,
            "base_points": base,
            "points_per_tai": per_tai,
            "dealer": state.dealer,
            "dealer_streak": streak,
            "payers": payers,
        }

    return {
        "version": snapshot["version"],
        "terminal_reason": snapshot["terminal_reason"],
        "winners": winners,
        "winning_tile": winning_type,
        "payments": list(result.get("payments") or [0, 0, 0, 0]),
        "players": players,
        "scoring": scoring,
        "note": "牌局結束後才公開的四家手牌；不會寫入下載的公開對局紀錄。",
    }
