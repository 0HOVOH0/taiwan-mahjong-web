"""Public-state forecasts for BC continuation, with independent per-outcome gates."""

import hashlib
import json
from pathlib import Path

import numpy as np

FEATURES = [
    "shanten",
    "next_draw_prior",
    "live_fraction",
    "ready_opponents",
    "own_melds",
    "opponent_melds",
    "own_discards",
    "danger_score",
    "dealer",
    "own_ready",
]
VERSION = "bc-continuation-v1"


def features(snapshot):
    if snapshot["finished"] or snapshot["phase"] != "discard":
        return None
    row = next((r for r in snapshot["actions"] if r["recommended"]), None)
    if row is None or row["kind"] not in ("discard", "declare_ready"):
        return None
    seat = snapshot["viewer"]
    own = snapshot["players"][seat]
    others = [p for p in snapshot["players"] if p["seat"] != seat]
    return [
        row["shanten"],
        row["next_draw_prior"],
        snapshot["live_tiles"] / 80,
        sum(p["ready"] for p in others),
        len(own["melds"]),
        sum(len(p["melds"]) for p in others),
        len(own["river"]) / 20,
        row["danger_score"],
        float(snapshot["dealer"] == seat),
        float(own["ready"]),
    ]


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()
    ).hexdigest()


class OutcomeForecast:
    def __init__(self, root, model_hash, rules_hash):
        self.data = None
        path = Path(root) / "artifacts/outcome-calibration/model.json"
        if not path.is_file():
            return
        data = json.loads(path.read_text(encoding="utf-8"))
        checksum = data.pop("sha256", None)
        if (
            checksum != digest(data)
            or data.get("version") != VERSION
            or data.get("features") != FEATURES
        ):
            raise ValueError("outcome model contract/hash mismatch")
        if data["policy_sha256"] != model_hash or data["rules_sha256"] != rules_hash:
            raise ValueError("outcome model policy/rules mismatch")
        self.data = data

    def predict(self, snapshot):
        if self.data is None:
            return None
        raw = features(snapshot)
        if raw is None:
            return None
        x = np.asarray(raw, dtype=float)
        if np.any(x < np.asarray(self.data["minimum"]) - 1e-6) or np.any(
            x > np.asarray(self.data["maximum"]) + 1e-6
        ):
            return None
        normalized = (x - self.data["mean"]) / self.data["scale"]
        estimates = {}
        reliability = {}
        for label, model in self.data["models"].items():
            if not model["accepted"]:
                continue
            z = float(normalized @ np.asarray(model["weights"]) + model["bias"])
            z = z / model["temperature"] + model["offset"]
            estimates[label] = float(1 / (1 + np.exp(-np.clip(z, -30, 30))))
            quality = self.data.get("quality", {}).get(label, {})
            bucket = next(
                (
                    b
                    for b in quality.get("bins", [])
                    if b["lower"] <= estimates[label] < b["lower"] + 0.1
                ),
                None,
            )
            reliability[label] = {"ece": quality.get("ece"), "bucket": bucket}
        if not estimates:
            return None
        return {
            "estimates": estimates,
            "reliability": reliability,
            "test_games": self.data["test_games"],
            "note": "假設從現在起持續採用 BC 建議，對三位規則 AI 的整局結果預測。自由改選動作會改變條件；此數字不是所選牌的放槍率。",
        }
