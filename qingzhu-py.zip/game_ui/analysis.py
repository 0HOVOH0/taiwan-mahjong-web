"""Hand entry uses structural facts only; incomplete history cannot imply legal calls."""

import re
from collections import Counter

from engine_v4.shanten import calculate_shanten, find_effective_tiles
from engine_v4.tiles import TILE_NAMES
from learning_v3.probability import hit_probability


def parse_tiles(value, *, maximum=136):
    if isinstance(value, str):
        if len(value) > 2048:
            raise ValueError("牌面輸入過長")
        value = value.strip().replace("，", " ").replace(",", " ")
        aliases = {name: i for i, name in enumerate(TILE_NAMES[:34])}
        aliases.update(
            {
                str(n) + suit: offset + n - 1
                for suit, offset in [("萬", 0), ("筒", 9), ("條", 18)]
                for n in range(1, 10)
            }
        )
        result = []
        for token in value.split():
            if token in aliases:
                result.append(aliases[token])
                continue
            match = re.fullmatch(r"([1-9]+)([mpsz])", token.lower())
            if not match or (match[2] == "z" and any(int(d) > 7 for d in match[1])):
                raise ValueError(
                    f"無法辨識牌面「{token}」。使用 123m（萬）、123p（筒）、123s（條）、1–7z（東南西北中發白）或以空白分隔中文牌名。"
                )
            offset = {"m": 0, "p": 9, "s": 18, "z": 27}[match[2]]
            result.extend(offset + int(d) - 1 for d in match[1])
        value = result
    if (
        not isinstance(value, list)
        or len(value) > maximum
        or any(type(t) is not int or not 0 <= t < 34 for t in value)
    ):
        raise ValueError("牌面必須為非花牌，且張數不能超過上限")
    return list(value)


def analyze_hand(body):
    if not isinstance(body, dict) or set(body) - {"hand", "melds", "public_tiles"}:
        raise ValueError("手牌試算只接受 hand、melds、public_tiles")
    hand = parse_tiles(body.get("hand", []), maximum=17)
    raw_melds = body.get("melds", [])
    if isinstance(raw_melds, str):
        raw_melds = [
            x.strip() for x in raw_melds.replace("｜", "|").split("|") if x.strip()
        ]
    if not isinstance(raw_melds, list) or len(raw_melds) > 5:
        raise ValueError("固定面子最多五組")
    melds = [sorted(parse_tiles(m, maximum=4)) for m in raw_melds]
    for group in melds:
        same = len(set(group)) == 1 and len(group) in (3, 4)
        sequence = (
            len(group) == 3
            and group[-1] < 27
            and group[0] // 9 == group[-1] // 9
            and group == list(range(group[0], group[0] + 3))
        )
        if not (same or sequence):
            raise ValueError("固定面子須為同色順子、刻子或槓子")
    public = parse_tiles(body.get("public_tiles", []))
    known = Counter(hand + public + [t for m in melds for t in m])
    if any(n > 4 for n in known.values()):
        raise ValueError(
            "暗手、固定面子與其他公開牌合計，每種牌最多四張；同一張牌請勿重複輸入"
        )
    k = len(melds)
    waiting = 16 - 3 * k
    if len(hand) not in (waiting, waiting + 1):
        raise ValueError(
            f"{k} 組固定面子需有 {waiting} 張待摸或 {waiting + 1} 張待打的暗手"
        )
    visible = [known[t] for t in range(34)]
    n = 136 - sum(visible)
    horizon = min(n, 4)
    rows = []
    for discard in sorted(set(hand)) if len(hand) == waiting + 1 else [None]:
        after = Counter(hand)
        if discard is not None:
            after[discard] -= 1
        counts = [after[t] for t in range(34)]
        shanten = calculate_shanten(counts, fixed_meld_count=k)
        effective = find_effective_tiles(
            counts, fixed_meld_count=k, visible_counts34=visible
        )
        ukeire = sum(4 - visible[t] for t in effective)
        rows.append(
            {
                "discard": discard,
                "label": "待摸牌" if discard is None else "打出 " + TILE_NAMES[discard],
                "shanten": shanten,
                "ukeire": ukeire,
                "next_draw_prior": ukeire / n if n else 0,
                "four_draw_prior": hit_probability(n, ukeire, horizon) if n else 0,
                "effective_tiles": [
                    {"type": t, "name": TILE_NAMES[t], "unseen": 4 - visible[t]}
                    for t in effective
                ],
            }
        )
    rows.sort(
        key=lambda r: (
            r["shanten"],
            -r["ukeire"],
            r["discard"] if r["discard"] is not None else -1,
        )
    )
    return {
        "hand": hand,
        "melds": melds,
        "public_tiles": public,
        "rows": rows,
        "unseen_population": n,
        "horizon_draws": horizon,
        "method": "一般型牌效率試算",
        "note": "依輸入的已知牌計算五面子一對的向聽與進張。未輸入的公開牌仍會計入未見牌池；缺少歷史，無法判定吃後禁打、宣告聽牌、可否胡牌或提供 BC／實戰勝率。",
    }
