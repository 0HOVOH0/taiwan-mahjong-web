"""Local Taiwan Mahjong table and public-information coaching interface."""
