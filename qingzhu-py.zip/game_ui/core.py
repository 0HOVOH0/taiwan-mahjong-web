from __future__ import annotations

import hashlib
import json
import secrets
import time
from copy import deepcopy
from pathlib import Path

import numpy as np
import torch

from agents.heuristic_agent import visible_counts34
from engine_v4.actions import ActionKind
from engine_v4.game import MahjongGame
from engine_v4.rules import load_rules
from engine_v4.scoring import calculate_tai
from engine_v4.state import Phase
from engine_v4.tiles import TILE_NAMES, Tile
from learning_v4.strategy import TeacherAgent
from learning_v42.artifacts import load_checkpoint
from learning_v42.env import (
    common_ready_policy,
    public_observation,
    safe_public_history,
)
from learning_v42.features import analyze_actions, canonical_actions

LABELS = {
    "discard": "打出",
    "declare_ready": "宣告聽牌",
    "pass_": "過",
    "chi": "吃",
    "pong": "碰",
    "exposed_kong": "明槓",
    "concealed_kong": "暗槓",
    "added_kong": "加槓",
    "win": "胡牌",
    "draw": "摸牌",
}
LABELS["pass"] = LABELS.pop("pass_")


def action_key(action):
    return (
        action.kind.value,
        tuple(sorted(Tile(t).type_id for t in action.tile_ids)),
        action.meld_index,
    )


class Advisor:
    def __init__(self, root: Path, checkpoint: Path | None = None):
        torch.set_num_threads(2)
        self.root = root
        self.rules = load_rules(root / "rules_v4.yaml")
        portable = root / "artifacts/inference-bc"
        self.path = checkpoint or (
            portable
            if (portable / "manifest.json").is_file()
            else root
            / "artifacts/v42-pilot-lr3x-seed73-run2/checkpoints/behavior-cloned"
        )
        self.model = None
        self.error = None
        try:
            if (self.path / "policy.pt").is_file():
                from .inference import load_inference

                self.model, self.manifest = load_inference(self.path)
            else:
                self.model, self.manifest = load_checkpoint(self.path, device="cpu")
            if (
                self.manifest["rules_sha256"]
                != hashlib.sha256(
                    json.dumps(
                        self.rules.to_dict(),
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                        allow_nan=False,
                    ).encode()
                ).hexdigest()
            ):
                raise ValueError("Model rules differ from game rules")
            self.model.policy.set_training_mode(False)
        except Exception as error:
            self.error = f"{type(error).__name__}: {error}"
            self.model = None
        self.outcome = None
        if self.model is not None:
            try:
                from .outcomes import OutcomeForecast

                self.outcome = OutcomeForecast(
                    root, self.manifest["model_sha256"], self.manifest["rules_sha256"]
                )
            except (ValueError, KeyError, OSError):
                # Optional experimental estimates must never prevent normal play.
                self.outcome = None

    def analyze(self, view, legal):
        rows = analyze_actions(view, legal, rules=self.rules)
        probabilities = {}
        recommendation = None
        method = "BC 模型"
        win = next((a for a in legal if a.kind == ActionKind.WIN), None)
        teacher_key = action_key(
            win if win else min(rows, key=lambda r: r.score).action
        )
        if win:
            recommendation = action_key(win)
            method = "合法胡牌"
        elif self.model is not None:
            # Keep the trained auto-ready action contract; humans still receive
            # every native option, including an ordinary discard instead of ready.
            model_rows = analyze_actions(
                view, common_ready_policy(legal), rules=self.rules
            )
            obs = public_observation(view, model_rows)
            tensor_obs, _ = self.model.policy.obs_to_tensor(obs)
            with torch.no_grad():
                distribution = self.model.policy.get_distribution(
                    tensor_obs, action_masks=obs["candidate_mask"].astype(bool)
                )
                probs = distribution.distribution.probs.cpu().numpy().reshape(-1)
            probabilities = {
                action_key(r.action): float(probs[i]) for i, r in enumerate(model_rows)
            }
            recommendation = action_key(
                model_rows[int(np.argmax(probs[: len(model_rows)]))].action
            )
        else:
            recommendation = action_key(min(rows, key=lambda r: r.score).action)
            method = "規則教師（模型未載入）"
        known = visible_counts34(view)
        result = []
        for row in rows:
            action = row.action
            types = [Tile(t).type_id for t in action.tile_ids]
            result.append(
                {
                    "kind": action.kind.value,
                    "types": types,
                    "label": LABELS[action.kind.value]
                    + (" " + "・".join(TILE_NAMES[t] for t in types) if types else ""),
                    "key": action_key(action),
                    "action": action,
                    "recommended": action_key(action) == recommendation,
                    "teacher_recommended": action_key(action) == teacher_key,
                    "preference": probabilities.get(action_key(action)),
                    "shanten": row.profile.shanten,
                    "ukeire": row.profile.unseen_count,
                    "next_draw_prior": row.profile.next_draw_prior,
                    "four_draw_prior": row.profile.horizon_hit_prior,
                    "danger_score": float(row.danger_score),
                    "unseen_population": sum(4 - count for count in known),
                    "horizon_draws": min(4, sum(4 - count for count in known)),
                    "followup_discard_type": row.followup_discard_type,
                    "effective_tiles": [
                        {"type": t, "name": TILE_NAMES[t], "unseen": 4 - known[t]}
                        for t in row.profile.effective_types
                    ],
                    "needs_discard": action.kind in (ActionKind.CHI, ActionKind.PONG),
                    "needs_supplement": action.kind
                    in (
                        ActionKind.ADDED_KONG,
                        ActionKind.CONCEALED_KONG,
                        ActionKind.EXPOSED_KONG,
                    ),
                }
            )
        return result, method


class Table:
    def __init__(self, advisor: Advisor, *, seat=0, seed=None, study=None, study_dir=None):
        if type(seat) is not int or seat not in range(4):
            raise ValueError("座位必須介於 0 至 3")
        self.advisor, self.seat = advisor, seat
        self.hints = True
        self.study_log = None
        if study is not None:
            from evaluation.discard import comparison_wall

            from .study import StudyLog, validate_study

            if study_dir is None:
                raise ValueError("研究模式只能在本機版使用")
            study = validate_study(study)
            self.hints = study["hints"]
            wall, dealer = comparison_wall(study["wall_seed"])
            self.game = MahjongGame(wall_order=wall, dealer=dealer, rules=advisor.rules)
            self.study_log = StudyLog(
                study_dir,
                study,
                seat=seat,
                model={
                    "model_name": "V4.2 BC" if advisor.model is not None else "規則教師",
                    "model_sha256": getattr(advisor, "manifest", {}).get("model_sha256")
                    if advisor.model is not None
                    else None,
                },
            )
        else:
            self.game = MahjongGame(
                seed=secrets.randbits(63) if seed is None else seed, rules=advisor.rules
            )
        self.teacher = TeacherAgent()
        self.actions = {}
        self.version = ""
        self.history = []
        self.snapshot = None
        # Settlement-only detail (never part of snapshot/history/replay).
        self.win_scores = {}
        self.advance()

    def _apply(self, seat, action):
        if action.kind == ActionKind.WIN:
            # Same call the engine makes in _finish_win, taken just before the
            # win is applied so the tai item breakdown can be shown after the
            # hand ends. Read-only; failures only hide the breakdown.
            # (setdefault: tables built without __init__, e.g. test wrappers.)
            scores = self.__dict__.setdefault("win_scores", {})
            try:
                scores[seat] = calculate_tai(
                    self.game.state.players[seat],
                    self.game._context(seat),
                    rules=self.advisor.rules,
                )
            except Exception:
                scores.pop(seat, None)
        self.game.apply(seat, action)

    def view(self, seat):
        view = self.game.player_view(seat)
        view["public_history"] = safe_public_history(self.game, seat)
        return view

    def advance(self):
        for _ in range(1600):
            if self.game.state.phase == Phase.FINISHED:
                break
            seat = self.game.waiting_players[0]
            legal = tuple(self.game.legal_actions(seat))
            if seat == self.seat:
                if len(legal) == 1 and legal[0].kind in (
                    ActionKind.DRAW,
                    ActionKind.PASS,
                ):
                    self._apply(seat, legal[0])
                    continue
                break
            choice = self.teacher.act(self.view(seat), legal)
            if choice not in legal:
                raise RuntimeError("對手回傳非法動作")
            self._apply(seat, choice)
        else:
            raise RuntimeError("單次推進超過有限步數")
        self.version = secrets.token_urlsafe(18)
        self.actions = {}
        view = self.view(self.seat)
        finished = self.game.state.phase == Phase.FINISHED
        started = time.perf_counter()
        recommendations, method = (
            ([], "已結算")
            if finished
            else self.advisor.analyze(
                view, canonical_actions(self.game.legal_actions(self.seat))
            )
        )
        model_ms = round((time.perf_counter() - started) * 1000, 1)
        hints = getattr(self, "hints", True)
        log = getattr(self, "study_log", None)
        advice, labels = [], {}
        for entry in recommendations:
            action = entry.pop("action")
            entry.pop("key")
            candidate = secrets.token_urlsafe(12)
            self.actions[candidate] = action
            labels[candidate] = {
                "label": entry["label"],
                "kind": entry["kind"],
                "ai": entry["recommended"],
                "teacher": entry["teacher_recommended"],
            }
            if not hints:
                from .study import scrub

                entry = scrub(entry)
            advice.append(dict(entry, id=candidate))
        if not hints:
            method = "無提示對局"
        # Explicit output schema: no seed, full snapshot, wall order, or hidden IDs.
        players = []
        for p in view["players"]:
            players.append(
                {
                    "seat": p["seat"],
                    "wind": p["seat_wind"],
                    "hand_count": p["hand_count"],
                    "hand": [Tile(t).type_id for t in p["hand"]]
                    if p["seat"] == self.seat
                    else None,
                    "river": [Tile(t).type_id for t in p["river"]],
                    "flowers": [Tile(t).type_id for t in p["flowers"]],
                    "ready": view["declared_ready"][p["seat"]],
                    "melds": [
                        {
                            "kind": m["kind"],
                            "tiles": [Tile(t).type_id for t in m["tile_ids"]]
                            if m.get("tile_ids") is not None
                            else None,
                        }
                        for m in p["melds"]
                    ],
                }
            )
        result = view["result"] if finished else None
        self.snapshot = {
            "version": self.version,
            "viewer": self.seat,
            "phase": view["phase"],
            "dealer": view["dealer"],
            "live_tiles": view["live_tiles"],
            "players": players,
            "actions": advice,
            "recommendation_method": method,
            "model_loaded": self.advisor.model is not None,
            "model_name": "V4.2 BC" if self.advisor.model is not None else "規則教師",
            "finished": finished,
            "result": result,
            "terminal_reason": view["terminal_reason"],
            "events": view["public_history"][-28:],
            "probability_note": "進張先驗假設未見牌等可能；包含對手暗牌及保留牌。四次抽牌固定進張集合、無放回抽樣，並非實戰胡牌率。",
            "reaction": None
            if view["reaction"] is None
            else {
                "source": view["reaction"]["source"],
                "tile": Tile(view["reaction"]["tile_id"]).type_id,
            },
        }
        self.snapshot["hints"] = hints
        self.history.append(json.loads(json.dumps(self.snapshot)))
        if log is not None:
            if finished:
                log.finished(result, view["terminal_reason"])
            else:
                log.shown(labels, model_ms=model_ms, reaction=view["reaction"] is not None)

    def choose(self, version, candidate):
        if self.snapshot["finished"]:
            raise ValueError("本局已結束")
        if version != self.version or candidate not in self.actions:
            raise ValueError("牌局已更新，請重新選擇")
        action = self.actions[candidate]
        if action not in self.game.legal_actions(self.seat):
            raise ValueError("這個動作目前不合法")
        # A model/opponent error must not leave the browser on an old snapshot
        # while the authoritative game has already consumed its action.
        before = (
            self.game.to_json(),
            self.version,
            self.actions.copy(),
            self.snapshot,
            deepcopy(self.history),
            dict(getattr(self, "win_scores", {})),
        )
        try:
            self.history[-1]["chosen"] = candidate
            if getattr(self, "study_log", None) is not None:
                self.study_log.chosen(candidate)
            self._apply(self.seat, action)
            self.advance()
        except Exception:
            (
                saved,
                self.version,
                self.actions,
                self.snapshot,
                self.history,
                self.win_scores,
            ) = before
            self.game = MahjongGame.from_json(saved, rules=self.advisor.rules)
            raise
        return self.snapshot
