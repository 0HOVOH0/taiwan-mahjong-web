"""以牌效率為底、公開風險作取捨；可疊加既有PPO偏好，不修改權重。"""

from dataclasses import asdict, dataclass
from math import isfinite
from pathlib import Path

import yaml

from agents.base import checked_actions
from agents.heuristic_agent import analyze_discards
from engine.actions import ActionKind
from strategies.public_risk import RISK_VERSION, analyze_public_risk


@dataclass(frozen=True)
class StrategyConfig:
    version: str = RISK_VERSION
    danger_weight: float = 2.0
    ukeire_weight: float = 0.35
    call_weight: float = 0.2
    ppo_weight: float = 0.12
    ready_attack_scale: float = 0.25
    one_shanten_scale: float = 0.55
    fold_threat_threshold: float = 0.9
    opponent_calls: bool = False

    def __post_init__(self):
        if self.version != RISK_VERSION or type(self.opponent_calls) is not bool:
            raise ValueError("策略版本或吃碰政策無效")
        for name, value in asdict(self).items():
            if name not in ("version", "opponent_calls") and (
                type(value) not in (int, float) or not isfinite(value) or value < 0
            ):
                raise ValueError(f"策略設定{name}須為非負有限數")
        if not all(0 <= value <= 1 for value in (
            self.ready_attack_scale, self.one_shanten_scale, self.fold_threat_threshold,
        )):
            raise ValueError("策略比例與門檻須為0～1")

    def to_dict(self):
        return asdict(self)


def load_strategy_config(path=None):
    if path is None:
        return StrategyConfig()
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or set(data) != set(StrategyConfig().to_dict()):
        raise ValueError("公開策略設定欄位不符")
    return StrategyConfig(**data)


@dataclass(frozen=True)
class PublicDiscardAnalysis:
    efficiency: object
    risk: object
    score: float
    eligible: bool
    shanten_penalty: float
    ukeire_penalty: float
    danger_penalty: float
    call_penalty: float
    ppo_penalty: float

    def to_dict(self):
        return {
            **self.efficiency.to_dict(), "public_risk": self.risk.to_dict(),
            **{key: value for key, value in asdict(self).items() if key not in ("efficiency", "risk")},
        }


def analyze_balanced_discards(view, legal_actions, *, config=None, probabilities=None):
    config = StrategyConfig() if config is None else config
    efficiency = analyze_discards(view, legal_actions)
    if not efficiency:
        return ()
    if probabilities is not None:
        probabilities = tuple(float(value) for value in probabilities)
        if len(probabilities) != 35 or any(not isfinite(p) or p < 0 for p in probabilities):
            raise ValueError("PPO偏好須為35個非負有限值")
        if sum(probabilities[item.type_id] for item in efficiency) <= 0:
            raise ValueError("PPO合法棄牌偏好總和須為正")
    risks = analyze_public_risk(view, opponent_calls=config.opponent_calls)
    best_shanten = min(item.shanten for item in efficiency)
    best_ukeire = max(item.unseen_count for item in efficiency if item.shanten == best_shanten)
    maximum_threat = max(other.threat_score for other in risks[0].opponents)
    # 只有自己距聽仍遠、且有強烈公開威脅時，才容許最多退一向聽。
    allowance = int(best_shanten >= 2 and maximum_threat >= config.fold_threat_threshold)
    scale = config.ready_attack_scale if best_shanten == 0 else config.one_shanten_scale if best_shanten == 1 else 1.0
    max_probability = max(probabilities[item.type_id] for item in efficiency) if probabilities is not None else 1.0
    result = []
    for item in efficiency:
        risk = risks[item.type_id]
        shanten_penalty = float(item.shanten - best_shanten)
        ukeire_penalty = config.ukeire_weight * max(0, best_ukeire - item.unseen_count) / max(1, best_ukeire)
        danger_penalty = config.danger_weight * scale * risk.danger_score
        call_penalty = config.call_weight * risk.call_opportunity_score
        ppo_penalty = 0.0 if probabilities is None else config.ppo_weight * (max_probability - probabilities[item.type_id]) / max_probability
        result.append(PublicDiscardAnalysis(
            item, risk, shanten_penalty + ukeire_penalty + danger_penalty + call_penalty + ppo_penalty,
            item.shanten <= best_shanten + allowance,
            shanten_penalty, ukeire_penalty, danger_penalty, call_penalty, ppo_penalty,
        ))
    return tuple(sorted(result, key=lambda item: (
        not item.eligible, item.score, item.efficiency.shanten,
        -item.efficiency.unseen_count, item.efficiency.type_id, item.efficiency.tile_id,
    )))


class BalancedAgent:
    """胡／摸優先、反應過；出牌融合公開風險與自己的向聽／有效進張。"""

    def __init__(self, config=None):
        self.config = StrategyConfig() if config is None else config

    def act(self, observation, legal_actions):
        actions = checked_actions(legal_actions)
        for kind in (ActionKind.WIN, ActionKind.DRAW):
            action = next((a for a in actions if a.kind == kind), None)
            if action is not None:
                return action
        if any(a.kind in (ActionKind.DISCARD, ActionKind.DECLARE_READY) for a in actions):
            return analyze_balanced_discards(observation, actions, config=self.config)[0].efficiency.action
        passed = next((a for a in actions if a.kind == ActionKind.PASS), None)
        if passed is not None:
            return passed
        raise ValueError("目前沒有公開策略支援的合法選擇")


class PublicPPOAdvisor:
    """與model.predict同介面，明確疊加公開分析；原PPO權重不變。

    環境只經player_view、legal_discards與action_masks公開入口讀取。
    """

    def __init__(self, environment, *, model=None, config=None):
        self.environment = environment
        self.model = model
        self.config = StrategyConfig() if config is None else config
        self.decisions = 0
        self.last_analysis = ()
        self.shanten_sacrifices = 0

    def analyze(self, observation, action_masks):
        probabilities = None
        if self.model is not None:
            import torch

            tensor, _ = self.model.policy.obs_to_tensor(observation)
            with torch.no_grad():
                distribution = self.model.policy.get_distribution(tensor, action_masks=action_masks)
                probabilities = distribution.distribution.probs.detach().cpu().numpy().reshape(-1)
        return analyze_balanced_discards(
            self.environment.player_view(), self.environment.legal_discards(),
            config=self.config, probabilities=probabilities,
        )

    def predict(self, observation, *, action_masks, deterministic=True):
        del deterministic  # 本選牌層為固定可重現排序；不假裝是PPO的抽樣政策。
        if action_masks[34]:
            return 34, None
        rows = self.analyze(observation, action_masks)
        if not rows:
            raise ValueError("環境沒有合法棄牌")
        chosen = rows[0]
        action = chosen.efficiency.type_id
        if not action_masks[action]:
            raise ValueError("公開策略選擇未通過合法遮罩")
        self.last_analysis = rows
        self.decisions += 1
        self.shanten_sacrifices += chosen.shanten_penalty > 0
        return action, None
