"""公開牌分析：均勻未知牌先驗與未校準的危險分數，絕不讀他家暗手。"""

from collections import Counter
from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import combinations
from math import comb

from agents.heuristic_agent import visible_counts34
from engine.tiles import Tile

RISK_VERSION = "public-risk-v1"


def _clamp(value):
    return max(0.0, min(1.0, value))


def _choose(n, k):
    return comb(n, k) if 0 <= k <= n else 0


@lru_cache(maxsize=32768)
def occupancy_prior(population: int, hand_size: int, counts: tuple[int, ...]) -> float:
    """均勻無放回分派下，指定的每種牌至少持一張之精確先驗。

    counts描述不同牌型在未知池內的張數；不是已依棄牌行為／聽牌條件校準的後驗。
    """
    if (
        type(population) is not int or type(hand_size) is not int
        or not 0 <= hand_size <= population
        or any(type(c) is not int or c < 0 for c in counts)
        or sum(counts) > population
    ):
        raise ValueError("未知牌池或暗手張數不合法")
    denominator = _choose(population, hand_size)
    probability = 0.0
    for size in range(len(counts) + 1):
        for subset in combinations(counts, size):
            probability += (-1) ** size * _choose(population - sum(subset), hand_size) / denominator
    return _clamp(probability)


def at_least_two_prior(population, hand_size, copies):
    if type(copies) is not int or not 0 <= copies <= population:
        raise ValueError("未知同型牌張數無效")
    # 以相同驗證入口處理空牌池與非法手牌。
    occupancy_prior(population, hand_size, (copies,))
    denominator = _choose(population, hand_size)
    return _clamp(1 - (_choose(population - copies, hand_size)
                       + copies * _choose(population - copies, hand_size - 1)) / denominator)


def sequence_partners(tile_type):
    if type(tile_type) is not int or tile_type not in range(34):
        raise ValueError("牌型須為0～33")
    if tile_type >= 27:
        return ()
    start, rank = (tile_type // 9) * 9, tile_type % 9
    return tuple(
        (start + first, start + second)
        for first, second in ((rank - 2, rank - 1), (rank - 1, rank + 1), (rank + 1, rank + 2))
        if 0 <= first < 9 and 0 <= second < 9
    )


def union_support_prior(population, hand_size, unknown_counts, requirements):
    """持有任一需求集合的先驗；事件重疊以容斥去重，非胡牌機率。"""
    groups = tuple(dict.fromkeys(frozenset(group) for group in requirements))
    probability = 0.0
    for size in range(1, len(groups) + 1):
        for selection in combinations(groups, size):
            required = sorted(set().union(*selection))
            probability += (-1) ** (size + 1) * occupancy_prior(
                population, hand_size, tuple(sorted(unknown_counts[k] for k in required))
            )
    return _clamp(probability)


def public_discards(view, player):
    """目前牌河加近期公開棄牌摘要；按牌型最大計數合併以避免重計。

    被吃碰移走的舊棄牌可能只存在近期歷史；更早的已移走棄牌不憑空補造。
    """
    river = Counter(Tile(tile).type_id for tile in player["river"])
    recent = Counter(
        kind for event in view.get("public_history", [])
        if event["kind"] == "discard" and event["player"] == player["seat"]
        for kind in event["types"]
    )
    return river | recent


def _affinity(player, discards, kind):
    """僅是公開棄牌／副露的輕量偏好提示，不把推測當作確定手牌。"""
    group = kind // 9 if kind < 27 else 3
    groups = Counter((k // 9 if k < 27 else 3) for k, count in discards.items() for _ in range(count))
    total = sum(groups.values())
    # 丟得較多的花色稍降保留偏好，不能推論已無該花色。
    value = 1.0 - 0.25 * (groups[group] / total if total else 0)
    value *= 1.0 / (1.0 + 0.12 * discards[kind])
    visible_meld_suits = []
    for meld in player["melds"]:
        ids = meld["tile_ids"]
        if ids:
            types = [Tile(tile).type_id for tile in ids]
            if all(tile < 27 for tile in types) and len({tile // 9 for tile in types}) == 1:
                visible_meld_suits.append(types[0] // 9)
    if len(visible_meld_suits) >= 2 and len(set(visible_meld_suits)) == 1:
        preferred = visible_meld_suits[0]
        other_discards = total - groups[preferred] - groups[3]
        if other_discards >= 2:
            value *= 1.25 if group == preferred else (1.08 if group == 3 else 0.85)
    return max(0.45, min(1.35, value))


@dataclass(frozen=True)
class OpponentTileRisk:
    seat: int
    type_id: int
    declared_ready: bool
    threat_score: float
    held_one_prior: float
    held_pair_prior: float
    sequence_support_prior: float
    win_group_support_prior: float
    pong_opportunity_prior: float
    chi_opportunity_prior: float
    retention_hint: float
    danger_score: float


@dataclass(frozen=True)
class TileRisk:
    type_id: int
    danger_score: float
    call_opportunity_score: float
    opponents: tuple[OpponentTileRisk, ...]

    def to_dict(self):
        return asdict(self)


def analyze_public_risk(view, *, opponent_calls=False):
    """0～33每張牌的相對危險與吃碰組合支持度。

    只用自己手牌、公開牌、他家暗手張數及公開宣告；不讀任何他家hand、牌牆或seed。
    danger_score不是放槍率；未宣告者是否聽牌目前沒有校準機率。
    opponent_calls=False對應現有V1固定過牌政策，實際吃碰機會明確為0。
    """
    if type(opponent_calls) is not bool:
        raise TypeError("opponent_calls須為布林值")
    known = visible_counts34(view)
    if any(count > 4 for count in known):
        raise ValueError("公開已知同型牌不能超過4張")
    unknown = tuple(4 - count for count in known)
    population = sum(unknown)
    viewer = view["viewer"]
    ready = view.get("declared_ready", [False] * 4)
    if len(ready) != 4 or any(type(flag) is not bool for flag in ready):
        raise ValueError("宣告狀態須為四個布林值")
    rows = {kind: [] for kind in range(34)}
    for player in view["players"]:
        seat = player["seat"]
        if seat == viewer:
            continue
        size = player["hand_count"]
        if type(size) is not int or not 0 <= size <= population:
            raise ValueError("對手暗手張數與未知牌池不符")
        melds = len(player["melds"])
        discards = public_discards(view, player)
        threat = 1.0 if ready[seat] else min(0.75, 0.12 + 0.025 * sum(discards.values()) + 0.08 * melds)
        calls_available = opponent_calls and not ready[seat] and melds < 5 and view.get("live_tiles", 0) > 3
        for kind in range(34):
            held = occupancy_prior(population, size, (unknown[kind],))
            pair = at_least_two_prior(population, size, unknown[kind])
            partners = sequence_partners(kind) if size >= 2 else ()
            sequences = union_support_prior(population, size, unknown, partners)
            # 任一可能的完成眼牌／順子；刻子需兩張同牌，已包含在至少一張的必要支持內。
            requirements = ((kind,), *partners) if size >= 1 else ()
            support = union_support_prior(population, size, unknown, requirements)
            hint = _affinity(player, discards, kind)
            danger = _clamp(threat * support * hint)
            rows[kind].append(OpponentTileRisk(
                seat=seat, type_id=kind, declared_ready=ready[seat], threat_score=threat,
                held_one_prior=held, held_pair_prior=pair, sequence_support_prior=sequences,
                win_group_support_prior=support,
                pong_opportunity_prior=pair if calls_available else 0.0,
                chi_opportunity_prior=sequences if calls_available and (seat - viewer) % 4 == 1 else 0.0,
                retention_hint=hint, danger_score=danger,
            ))
    result = []
    for kind in range(34):
        others = tuple(rows[kind])
        dangers = sorted((other.danger_score for other in others), reverse=True)
        # 相對分數的多家壓力加權；刻意不標成聯合放槍機率。
        score = _clamp(sum(weight * value for weight, value in zip((1.0, 0.15, 0.075), dangers, strict=True)))
        calls = max(max(other.pong_opportunity_prior, other.chi_opportunity_prior) for other in others)
        result.append(TileRisk(kind, score, calls, others))
    return tuple(result)
