"""一般完成型的計台及零和付款。模糊／尚未支援的規則明確拒絕。"""

from collections import Counter
from dataclasses import dataclass
from enum import Enum

from engine.rules import (
    SUPPORTED_RULE_VERSIONS,
    TRAINING_RULES_VERSION,
    RulesConfig,
    load_rules,
    ordinary_flower_scoring,
)
from engine.state import MeldKind, PlayerState, RoundResult, Wind
from engine.tiles import Tile
from engine.win import (
    HandMeldKind,
    WinDecomposition,
    analyze_player_hand,
    find_win_decompositions,
    is_winning_hand,
)

PROFILE_VERSION = TRAINING_RULES_VERSION
SUPPORTED_PROFILE_VERSIONS = SUPPORTED_RULE_VERSIONS
SUPPORTED_TAI_CODES = frozenset(
    {
        "self_draw",
        "concealed_hand",
        "concealed_self_draw",
        "seat_wind",
        "round_wind",
        "dragon_triplet_each",
        "seat_flower_each",
        "flower_set_each",
        "all_sequences",
        "all_triplets",
        "three_concealed_triplets",
        "four_concealed_triplets",
        "five_concealed_triplets",
        "fully_exposed_discard_win",
        "half_exposed_self_draw",
        "half_flush",
        "full_flush",
        "all_honors",
        "small_three_dragons",
        "big_three_dragons",
        "small_four_winds",
        "big_four_winds",
        "replacement_draw_win",
        "rob_added_kong",
        "last_normal_draw_win",
        "middle_wait",
        "edge_wait",
        "single_pair_wait",
        "declared_ready",
        "human_win",
    }
)


class UnsupportedRuleError(ValueError):
    """要求了停用或尚未實作的特殊規則。"""


class WinMethod(str, Enum):
    SELF_DRAW = "self_draw"
    DISCARD = "discard"
    ROB_ADDED_KONG = "rob_added_kong"


class DrawOrigin(str, Enum):
    NORMAL = "normal"
    FLOWER = "flower"
    CONCEALED_KONG = "concealed_kong"
    ADDED_KONG = "added_kong"
    EXPOSED_KONG = "exposed_kong"


@dataclass(frozen=True)
class WinContext:
    winning_tile_id: int
    method: WinMethod
    source_player: int | None = None
    round_wind: Wind = Wind.EAST
    draw_origin: DrawOrigin | None = None
    declared_ready: bool = False
    last_normal_draw: bool = False
    source_first_discard: bool = False
    special_pattern: str | None = None


@dataclass(frozen=True)
class TaiItem:
    code: str
    tai: int


@dataclass(frozen=True)
class TaiResult:
    rules_version: str
    winner: int
    method: WinMethod
    source_player: int | None
    items: tuple[TaiItem, ...]
    decomposition: WinDecomposition
    completed_group: int | None  # None 代表完成眼牌

    @property
    def tai(self) -> int:
        return sum(item.tai for item in self.items)

    def to_dict(self) -> dict:
        return {
            "rules_version": self.rules_version,
            "winner": self.winner,
            "method": self.method.value,
            "source_player": self.source_player,
            "tai": self.tai,
            "items": [{"code": i.code, "tai": i.tai} for i in self.items],
            "decomposition": self.decomposition.to_dict(),
            "completed_group": self.completed_group,
        }


def _seat(value: int) -> None:
    if type(value) is not int or not 0 <= value < 4:
        raise ValueError("座位必須是 0～3 的整數")


def _rules(rules: RulesConfig | None) -> RulesConfig:
    rules = load_rules() if rules is None else rules
    if (
        not isinstance(rules, RulesConfig)
        or rules.version not in SUPPORTED_PROFILE_VERSIONS
    ):
        raise ValueError("計分模組僅支援目前的明確規則子集，請勿混用舊版本")
    ordinary_flower_scoring(rules)
    table = rules.table_rules
    if set(table["tai_table"]) != SUPPORTED_TAI_CODES:
        raise UnsupportedRuleError("設定含未支援或缺少的計台項目")
    for value in (table["base_points"], table["points_per_tai"]):
        if type(value) is not int or value <= 0:
            raise ValueError("底與每台分數必須是正整數")
    if any(
        type(value) is not int or value < 0 for value in table["tai_table"].values()
    ):
        raise ValueError("台數必須是非負整數")
    return rules


def _context(player: PlayerState, context: WinContext, rules: RulesConfig) -> None:
    if not isinstance(context, WinContext) or not isinstance(context.method, WinMethod):
        raise TypeError("請提供 WinContext 與 WinMethod")
    _seat(player.seat)
    if not isinstance(player.seat_wind, Wind) or not isinstance(
        context.round_wind, Wind
    ):
        raise TypeError("座風與圈風必須是 Wind")
    for flag in (
        context.declared_ready,
        context.last_normal_draw,
        context.source_first_discard,
    ):
        if type(flag) is not bool:
            raise TypeError("局況旗標必須是布林值")
    if context.special_pattern is not None:
        raise UnsupportedRuleError("特殊花胡、天地胡、地聽等目前不由一般計台入口處理")
    if context.draw_origin == DrawOrigin.EXPOSED_KONG:
        raise UnsupportedRuleError("大明槓後胡牌政策已停用")
    if context.method == WinMethod.SELF_DRAW:
        if context.source_player is not None or context.source_first_discard:
            raise ValueError("自摸不可有放槍來源")
        if not isinstance(context.draw_origin, DrawOrigin):
            raise ValueError("自摸必須明確提供摸牌來源")
        if context.winning_tile_id not in player.hand:
            raise ValueError("自摸完成牌必須已在暗手牌中")
    else:
        _seat(context.source_player)
        if context.source_player == player.seat or context.draw_origin is not None:
            raise ValueError("胡棄牌／搶槓的來源或摸牌資訊不符")
        if context.method == WinMethod.ROB_ADDED_KONG and context.source_first_discard:
            raise ValueError("搶槓不是來源玩家的首次棄牌")
    if context.last_normal_draw and (
        context.method != WinMethod.SELF_DRAW
        or context.draw_origin != DrawOrigin.NORMAL
    ):
        raise ValueError("海底自摸必須來自最後一次正常摸牌")
    if len(player.flowers) >= 7 and not ordinary_flower_scoring(rules):
        raise UnsupportedRuleError("七／八花局面需獨立花胡評估器，目前暫不計分")


def _structural_waits(counts: list[int], fixed_counts: Counter, fixed: int) -> set[int]:
    waits = set()
    for tile_type in range(34):
        if counts[tile_type] + fixed_counts[tile_type] >= 4:
            continue
        candidate = counts.copy()
        candidate[tile_type] += 1
        if is_winning_hand(candidate, fixed_meld_count=fixed):
            waits.add(tile_type)
    return waits


def calculate_tai(
    player: PlayerState, context: WinContext, *, rules: RulesConfig | None = None
) -> TaiResult:
    """自摸 hand 已含完成牌；放槍／搶槓由 context 臨時加入完成牌。

    枚舉拆法及完成牌落點，從單一合法解讀選最高台；不移動牌、不判回合合法性。
    """
    rules = _rules(rules)
    if not isinstance(player, PlayerState):
        raise TypeError("player 必須是 PlayerState")
    _context(player, context, rules)
    tile = Tile(context.winning_tile_id)
    if tile.is_flower:
        raise ValueError("一般完成牌不可為花牌")
    if any(m.kind == MeldKind.EXPOSED_KONG for m in player.melds):
        raise UnsupportedRuleError("目前明確子集停用大明槓局面")
    if context.declared_ready and any(
        m.kind == MeldKind.CONCEALED_KONG for m in player.melds
    ):
        raise UnsupportedRuleError("宣告與暗槓的先後資格尚未有狀態驗證，本版拒絕此組合")
    external = context.method != WinMethod.SELF_DRAW
    decompositions = analyze_player_hand(
        player, winning_tile_id=context.winning_tile_id if external else None
    )
    if not decompositions:
        raise ValueError("不是五面子一對完成型，不能計台")
    counts = player.counts34()
    if external:
        counts[tile.type_id] += 1
    before = counts.copy()
    before[tile.type_id] -= 1
    fixed_counts = Counter(Tile(i).type_id for m in player.melds for i in m.tile_ids)
    waits = _structural_waits(before, fixed_counts, len(player.melds))
    table = rules.table_rules
    scores = table["tai_table"]
    completed_types = {i for i, count in enumerate(counts) if count} | set(fixed_counts)
    suits = {i // 9 for i in completed_types if i < 27}
    honors = any(i >= 27 for i in completed_types)
    concealed = all(m.kind == MeldKind.CONCEALED_KONG for m in player.melds)
    fixed_triplets = [
        Tile(m.tile_ids[0]).type_id for m in player.melds if m.kind != MeldKind.CHI
    ]
    pinfu_pair_wait = False
    for wait in waits:
        candidate = before.copy()
        candidate[wait] += 1
        if any(
            d.pair_type_id == wait
            for d in find_win_decompositions(
                candidate, fixed_meld_count=len(player.melds)
            )
        ):
            pinfu_pair_wait = True
    base = tile.type_id // 9 * 9
    pinfu_overlap = False
    if tile.type_id < 27:
        if tile.type_id % 9 == 2:
            pinfu_overlap = all(before[base + rank] for rank in (0, 1, 3, 4))
        elif tile.type_id % 9 == 6:
            pinfu_overlap = all(before[base + rank] for rank in (4, 5, 7, 8))
    candidates = []
    for decomposition in decompositions:
        groups = decomposition.concealed_melds
        positions = [i for i, m in enumerate(groups) if tile.type_id in m.type_ids]
        if decomposition.pair_type_id == tile.type_id:
            positions.append(None)
        for position in positions:
            found: dict[str, int] = {}

            def add(code: str, times: int = 1, into: dict[str, int] = found) -> None:
                if times:
                    into[code] = scores[code] * times

            if context.method == WinMethod.SELF_DRAW and concealed:
                add("concealed_self_draw")
            else:
                if context.method == WinMethod.SELF_DRAW:
                    add("self_draw")
                if concealed:
                    add("concealed_hand")
            if context.declared_ready:
                add("declared_ready")
            if context.source_first_discard:
                add("human_win")
            if context.method == WinMethod.ROB_ADDED_KONG:
                add("rob_added_kong")
            if context.draw_origin in (
                DrawOrigin.FLOWER,
                DrawOrigin.CONCEALED_KONG,
                DrawOrigin.ADDED_KONG,
            ):
                add("replacement_draw_win")
            if context.last_normal_draw:
                add("last_normal_draw_win")
            triplets = fixed_triplets + [
                m.type_ids[0] for m in groups if m.kind == HandMeldKind.TRIPLET
            ]
            dragons = sum(i in triplets for i in (31, 32, 33))
            winds = sum(i in triplets for i in (27, 28, 29, 30))
            if dragons == 3:
                add("big_three_dragons")
            elif dragons == 2 and decomposition.pair_type_id in (31, 32, 33):
                add("small_three_dragons")
            else:
                add("dragon_triplet_each", dragons)
            if winds == 4:
                add("big_four_winds")
            else:
                if winds == 3 and decomposition.pair_type_id in (27, 28, 29, 30):
                    add("small_four_winds")
                if 27 + list(Wind).index(player.seat_wind) in triplets:
                    add("seat_wind")
                if 27 + list(Wind).index(context.round_wind) in triplets:
                    add("round_wind")
            if not suits:
                add("all_honors")
            else:
                if len(suits) == 1:
                    add("half_flush" if honors else "full_flush")
                if len(triplets) == 5:
                    add("all_triplets")
            dark_count = sum(m.kind == MeldKind.CONCEALED_KONG for m in player.melds)
            dark_count += sum(m.kind == HandMeldKind.TRIPLET for m in groups)
            if (
                external
                and position is not None
                and groups[position].kind == HandMeldKind.TRIPLET
            ):
                dark_count -= 1
            if dark_count >= 3:
                add(
                    {
                        3: "three_concealed_triplets",
                        4: "four_concealed_triplets",
                        5: "five_concealed_triplets",
                    }[dark_count]
                )
            flowers = {Tile(i).type_id for i in player.flowers}
            flower_config = table["tai_stacking"]
            covered = set()
            flower_sets = 0
            for flower_set in flower_config["flower_sets"]:
                if set(flower_set) <= flowers:
                    covered.update(flower_set)
                    flower_sets += 1
            add("flower_set_each", flower_sets)
            matching = set(
                flower_config["flower_type_ids_by_seat_wind"][player.seat_wind.value]
            )
            add("seat_flower_each", len((flowers - covered) & matching))
            exposed = len(player.melds) == 5 and all(
                m.kind != MeldKind.CONCEALED_KONG for m in player.melds
            )
            if exposed:
                add(
                    "half_exposed_self_draw"
                    if context.method == WinMethod.SELF_DRAW
                    else "fully_exposed_discard_win"
                )
            elif len(waits) == 1:
                if position is None:
                    add("single_pair_wait")
                elif groups[position].kind == HandMeldKind.SEQUENCE:
                    sequence = groups[position].type_ids
                    if tile.type_id == sequence[1]:
                        add("middle_wait")
                    elif (sequence[0] % 9 == 0 and tile.type_id == sequence[2]) or (
                        sequence[0] % 9 == 6 and tile.type_id == sequence[0]
                    ):
                        add("edge_wait")
            if (
                context.method == WinMethod.DISCARD
                and not honors
                and not flowers
                and not triplets
                and len(waits) >= 2
                and not pinfu_pair_wait
                and not pinfu_overlap
                and position is not None
            ):
                sequence = groups[position].type_ids
                edge = (sequence[0] % 9 == 0 and tile.type_id == sequence[2]) or (
                    sequence[0] % 9 == 6 and tile.type_id == sequence[0]
                )
                if tile.type_id != sequence[1] and not edge:
                    add("all_sequences")
            candidates.append(
                TaiResult(
                    rules.version,
                    player.seat,
                    context.method,
                    context.source_player,
                    tuple(TaiItem(k, v) for k, v in sorted(found.items())),
                    decomposition,
                    position,
                )
            )
    result = max(candidates, key=lambda candidate: candidate.tai)
    if result.tai < table["minimum_tai"]:
        raise ValueError("未達最低胡牌台數")
    return result


def settle_score(
    score: TaiResult,
    *,
    dealer: int,
    dealer_streak: int = 0,
    rules: RulesConfig | None = None,
) -> RoundResult:
    """使用 calculate_tai 的結果，產生四家零和支付；不裁決回合。"""
    rules = _rules(rules)
    if not isinstance(score, TaiResult) or score.rules_version != rules.version:
        raise ValueError("計台結果與付款設定版本不符")
    _seat(dealer)
    _seat(score.winner)
    table = rules.table_rules
    cap = table["dealer_bonus"]["max_continuations"]
    if type(dealer_streak) is not int or not 0 <= dealer_streak <= cap:
        raise ValueError("連莊次數超出支援範圍")
    if not isinstance(score.method, WinMethod) or any(
        type(i.tai) is not int or i.tai < 0 for i in score.items
    ):
        raise ValueError("計台結果無效")
    if len({item.code for item in score.items}) != len(score.items):
        raise ValueError("計台結果不可重複列出同項台型")
    for item in score.items:
        if item.code not in SUPPORTED_TAI_CODES:
            raise UnsupportedRuleError("計台結果包含未支援項目")
        unit = table["tai_table"][item.code]
        limit = {
            "dragon_triplet_each": 3,
            "seat_flower_each": 2,
            "flower_set_each": 2,
        }.get(item.code, 1)
        if item.tai not in {unit * count for count in range(1, limit + 1)}:
            raise ValueError("台型台數與本版設定不符")
    if score.method == WinMethod.SELF_DRAW:
        if score.source_player is not None:
            raise ValueError("自摸不能有放槍者")
        payers = [i for i in range(4) if i != score.winner]
    else:
        _seat(score.source_player)
        if score.source_player == score.winner:
            raise ValueError("不能胡自己的牌")
        payers = [score.source_player]
    payments = [0] * 4
    for payer in payers:
        dealer_tai = 0
        if dealer in (payer, score.winner):
            dealer_tai = (
                table["dealer_bonus"]["initial_tai"]
                + table["dealer_bonus"]["per_continuation_tai"] * dealer_streak
            )
        amount = table["base_points"] + table["points_per_tai"] * (
            score.tai + dealer_tai
        )
        payments[payer] -= amount
        payments[score.winner] += amount
    tai = [0] * 4
    tai[score.winner] = score.tai
    patterns = [[] for _ in range(4)]
    patterns[score.winner] = [item.code for item in score.items]
    return RoundResult([score.winner], score.source_player, tai, patterns, payments)


def settle_draw() -> RoundResult:
    """流局無付款。"""
    return RoundResult()
