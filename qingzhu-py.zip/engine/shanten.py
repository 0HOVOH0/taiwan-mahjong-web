"""台灣十六張一般型的精確向聽與有效進張；不計特殊胡牌型或台數。

向聽是到「五面子一對」合法暗手目標牌形尚缺的最少張數減一。
每個目標牌形的同種牌最多四張，避免四張字牌被當成兩對後，
又假設能補第五張的錯誤。固定副露在此只提供面子數；其牌面由
呼叫端透過 visible_counts34 排除摸不到的牌，並由牌局引擎驗證。
"""

from collections.abc import Iterable
from functools import lru_cache
from numbers import Integral

_IMPOSSIBLE = 99
_MAX_MELDS = 5


def _counts(value: Iterable[int], label: str) -> tuple[int, ...]:
    if isinstance(value, (str, bytes)):
        raise TypeError(f"{label} 必須是 34 個整數，不可傳文字")
    result = tuple(value)
    if len(result) != 34:
        raise ValueError(f"{label} 必須剛好有 34 個元素，花牌另記")
    for item in result:
        if isinstance(item, bool) or not isinstance(item, Integral):
            raise TypeError(f"{label} 每項必須是整數")
        if not 0 <= item <= 4:
            raise ValueError(f"{label} 每種牌的張數必須介於 0～4")
    return tuple(int(item) for item in result)


def _fixed(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError("fixed_meld_count 必須是整數")
    if not 0 <= value <= 5:
        raise ValueError("fixed_meld_count 必須介於 0～5")
    return int(value)


@lru_cache(maxsize=32768)
def _section_costs(counts: tuple[int, ...], honor: bool) -> tuple[int, ...]:
    """各面子數/雀頭數的最少缺牌；沿牌序保存前兩格順子起點。

    狀態 (前格起點數, 前前格起點數, 已用面子數, 已用雀頭數)。
    每格選擇新順子、刻子、雀頭，枚舉所有合法目標而不逐一存牌形。
    回傳索引 2*面子數+雀頭數的代價，最多五面子與一雀頭。
    """
    if not any(counts):
        return tuple(3 * melds + 2 * pair for melds in range(6) for pair in range(2))
    states = {(0, 0, 0, 0): 0}
    for rank, owned in enumerate(counts):
        following: dict[tuple[int, int, int, int], int] = {}
        for (previous, older, melds, paired), missing in states.items():
            carried = previous + older
            max_start = min(4 - carried, _MAX_MELDS - melds)
            if honor or rank >= 7:
                max_start = 0
            for start in range(max_start + 1):
                for triplet in range(min(1, _MAX_MELDS - melds - start) + 1):
                    target = carried + start + 3 * triplet
                    if target > 4:
                        continue
                    for pair in range(2 - paired):
                        total = target + 2 * pair
                        if total > 4:
                            continue
                        key = (start, previous, melds + start + triplet, paired + pair)
                        cost = missing + max(total - owned, 0)
                        if cost < following.get(key, _IMPOSSIBLE):
                            following[key] = cost
        states = following
    return tuple(
        states.get((0, 0, melds, pair), _IMPOSSIBLE)
        for melds in range(6)
        for pair in range(2)
    )


@lru_cache(maxsize=65536)
def _shanten(counts: tuple[int, ...], fixed: int) -> int:
    needed = 5 - fixed
    costs = [0] + [_IMPOSSIBLE] * (2 * needed + 1)
    for section, honor in (
        (counts[:9], False),
        (counts[9:18], False),
        (counts[18:27], False),
        (counts[27:], True),
    ):
        local = _section_costs(section, honor)
        combined = [_IMPOSSIBLE] * len(costs)
        for melds in range(needed + 1):
            for pair in range(2):
                current = costs[2 * melds + pair]
                if current >= _IMPOSSIBLE:
                    continue
                for extra in range(needed - melds + 1):
                    for head in range(2 - pair):
                        index = 2 * (melds + extra) + pair + head
                        value = current + local[2 * extra + head]
                        combined[index] = min(combined[index], value)
        costs = combined
    return costs[2 * needed + 1] - 1


def calculate_shanten(counts34: Iterable[int], *, fixed_meld_count: int = 0) -> int:
    """回傳一般型向聽：完成為 -1、聽牌為 0、一進聽為 1。

    counts34 是 34 種非花暗手計數，各項 0～4；固定副露/花牌不放入。
    k 組固定面子只接受待摸 16-3*k 或摸後 17-3*k 張暗手。
    已有槓算一組固定面子。非法格式與不合張數分別拋 TypeError/
    ValueError；不修改輸入。此結果不裁決台數、胡牌權或牌牆剩餘量。
    """
    counts = _counts(counts34, "counts34")
    fixed = _fixed(fixed_meld_count)
    waiting_size = 16 - 3 * fixed
    if sum(counts) not in (waiting_size, waiting_size + 1):
        raise ValueError(
            f"{fixed} 組固定面子須有 {waiting_size} 或 {waiting_size + 1} 張暗手牌"
        )
    return _shanten(counts, fixed)


def find_effective_tiles(
    counts34: Iterable[int],
    *,
    fixed_meld_count: int = 0,
    visible_counts34: Iterable[int] | None = None,
) -> tuple[int, ...]:
    """回傳能降低向聽的牌型 ID，依 0～33 排序，無重複。

    僅接受待摸 16-3*k 張；摸後須先模擬打出一張。visible_counts34
    是所有已知實體牌去重後的 34 種計數，包含本人的暗手與固定副露。
    省略時只知道暗手；每項必須至少為暗手張數且不超過四張。
    已知四張、暗手已有四張的牌均不可補入。已知牌不更改向聽定義；
    此函式只過濾目前可補入的牌型，未知牌不代表仍在活牌牆內。
    """
    counts = _counts(counts34, "counts34")
    fixed = _fixed(fixed_meld_count)
    waiting_size = 16 - 3 * fixed
    if sum(counts) != waiting_size:
        raise ValueError(f"有效進張須先打牌，暗手張數必須是 {waiting_size}")
    visible = (
        counts
        if visible_counts34 is None
        else _counts(visible_counts34, "visible_counts34")
    )
    if any(known < held for known, held in zip(visible, counts, strict=True)):
        raise ValueError("visible_counts34 必須包含本人的全部暗手牌")
    before = _shanten(counts, fixed)
    effective = []
    for type_id, known in enumerate(visible):
        if known == 4:
            continue
        after = list(counts)
        after[type_id] += 1
        if _shanten(tuple(after), fixed) < before:
            effective.append(type_id)
    return tuple(effective)
