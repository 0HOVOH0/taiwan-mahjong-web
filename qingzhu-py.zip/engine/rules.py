"""讀取版本化桌規；未確認的規則保留 null，避免默默選用某套桌規。"""

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

DEFAULT_RULES_PATH = Path(__file__).resolve().parents[1] / "rules.yaml"
LEGACY_RULES_VERSION = "tw16-gamesofa-clear-0.4"
TRAINING_RULES_VERSION = "tw16-discard-train-0.5"
SUPPORTED_RULE_VERSIONS = frozenset({LEGACY_RULES_VERSION, TRAINING_RULES_VERSION})
LEGACY_RULES_PATH = (
    Path(__file__).resolve().parent / "profiles" / f"{LEGACY_RULES_VERSION}.yaml"
)
ORDINARY_FLOWER_POLICY = "ordinary_replacement_and_scoring"
TABLE_RULE_KEYS = (
    "normal_draw_end",
    "flower_replacement_end",
    "kong_replacement_end",
    "initial_flower_order",
    "initial_phase",
    "reserved_wall_tiles",
    "chi_source",
    "reaction_priority",
    "same_priority_resolution",
    "multiple_winners",
    "passed_win_restriction",
    "rob_added_kong",
    "post_chi_discard_restriction",
    "minimum_tai",
    "tai_table",
    "tai_stacking",
    "base_points",
    "points_per_tai",
    "discard_payment",
    "self_draw_payment",
    "dealer_bonus",
    "draw_payment",
    "dealer_continuation",
)


@dataclass(frozen=True)
class RulesConfig:
    """本階段只驗證已支援的牌組與結構，不把草案冒充完整規則引擎。"""

    version: str
    status: str
    _data: dict[str, Any]

    @property
    def pending_fields(self) -> tuple[str, ...]:
        """列出巢狀設定中的所有待釐清路徑。"""
        pending = []

        def visit(value: Any, path: str) -> None:
            if value is None:
                pending.append(path)
            elif isinstance(value, dict):
                for key, item in value.items():
                    visit(item, f"{path}.{key}" if path else str(key))
            elif isinstance(value, list):
                for index, item in enumerate(value):
                    visit(item, f"{path}[{index}]")

        visit(self._data["table_rules"], "")
        return tuple(pending)

    @property
    def table_rules(self) -> dict[str, Any]:
        return deepcopy(self._data["table_rules"])

    def to_dict(self) -> dict[str, Any]:
        """供實驗保存實際規則，回傳獨立副本而非可修改的內部參照。"""
        return deepcopy(self._data)

    def require_frozen(self) -> None:
        """未來正式開局入口需先呼叫；解凍不代表回合引擎已實作。"""
        if self.status != "frozen" or self.pending_fields:
            pending = "、".join(self.pending_fields) or "規則尚未標為 frozen"
            raise ValueError(f"桌規 {self.version} 尚未凍結：{pending}")


def load_rules(path: str | Path = DEFAULT_RULES_PATH) -> RulesConfig:
    return load_rules_data(yaml.safe_load(Path(path).read_text(encoding="utf-8")))


def load_rules_data(data: dict[str, Any]) -> RulesConfig:
    """以相同schema檢查記憶體規則，讓重播不依賴當下YAML或臨時檔。"""
    if not isinstance(data, dict):
        raise TypeError("規則檔必須是 YAML 物件")
    required = {
        "schema_version",
        "rules_version",
        "status",
        "players",
        "tiles",
        "hand_structure",
        "table_rules",
    }
    if set(data) != required:
        raise ValueError("規則檔欄位不符 schema_version 1")
    if type(data["schema_version"]) is not int or data["schema_version"] != 1:
        raise ValueError("不支援的規則 schema_version")
    if not isinstance(data["rules_version"], str) or not data["rules_version"].strip():
        raise ValueError("rules_version 不可空白")
    if data["status"] not in ("draft", "frozen"):
        raise ValueError("status 必須是 draft 或 frozen")
    if type(data["players"]) is not int or data["players"] != 4:
        raise ValueError("目前只支援四人牌局")
    expected_tiles = {
        "non_flower_types": 34,
        "copies_per_non_flower": 4,
        "flower_types": 8,
        "copies_per_flower": 1,
        "total": 144,
    }
    if data["tiles"] != expected_tiles or any(
        type(value) is not int for value in data["tiles"].values()
    ):
        raise ValueError("目前只支援 136 張非花牌加 8 張花牌")
    expected_hand = {
        "regular_hand_size": 16,
        "dealer_initial_hand_size": 17,
        "complete_melds": 5,
        "pairs": 1,
        "special_hands": [],
    }
    if data["hand_structure"] != expected_hand:
        raise ValueError("目前只支援十六張、五面子一對且排除特殊牌型的資料規格")
    table = data["table_rules"]
    if not isinstance(table, dict) or set(table) != set(TABLE_RULE_KEYS):
        raise ValueError("table_rules 必須列出所有桌規欄位，未確認者填 null")
    rules = RulesConfig(data["rules_version"], data["status"], deepcopy(data))
    if rules.version in SUPPORTED_RULE_VERSIONS:
        ordinary_flower_scoring(rules)
    if rules.status == "frozen":
        rules.require_frozen()
    return rules


def ordinary_flower_scoring(rules: RulesConfig) -> bool:
    """版本化七／八花政策；0.4 缺省仍拒絕，0.5 必須明確選定簡化玩法。"""
    if (
        not isinstance(rules, RulesConfig)
        or rules.version not in SUPPORTED_RULE_VERSIONS
    ):
        raise ValueError("不支援的明確規則版本")
    try:
        stacking = rules.table_rules["tai_stacking"]
        special = stacking["special_rules"]
        flower = special["flower_wins"]
        policy = flower.get("seven_or_eight_flower_policy")
    except (KeyError, TypeError, AttributeError) as error:
        raise ValueError("花牌政策設定不完整") from error
    if (
        flower.get("enabled") is not False
        or stacking.get("separate_flower_or_kong_payments") is not False
    ):
        raise ValueError("目前版本停用特殊花胡與獨立花槓支付")
    if rules.version == LEGACY_RULES_VERSION:
        if policy not in (None, "reject_unsupported_flower_win"):
            raise ValueError("0.4 不可改成一般七／八花計分，請使用新規則版本")
        return False
    if (
        policy != ORDINARY_FLOWER_POLICY
        or special.get("standard_win_adapter_dispatch")
        != "standard_only_special_flower_wins_disabled"
    ):
        raise ValueError("0.5 必須明確設定七／八花只補花並按一般花台計分")
    return True
