"""牌型、實體牌與初始牌組；不包含洗牌、發牌或其他桌規。"""

from collections import Counter
from dataclasses import dataclass
from enum import Enum


class Suit(str, Enum):
    WAN = "萬子"
    TONG = "筒子"
    TIAO = "條子"
    HONOR = "字牌"
    FLOWER = "花牌"


# 牌型 ID：0～8 萬、9～17 筒、18～26 條、27～33 字牌。
# 花牌另外使用 34～41；不放入模型的 counts[34]。
HONOR_NAMES = ("東", "南", "西", "北", "中", "發", "白")
FLOWER_NAMES = ("春", "夏", "秋", "冬", "梅", "蘭", "竹", "菊")
TILE_NAMES = (
    tuple(f"{number}萬" for number in range(1, 10))
    + tuple(f"{number}筒" for number in range(1, 10))
    + tuple(f"{number}條" for number in range(1, 10))
    + HONOR_NAMES
    + FLOWER_NAMES
)

NON_FLOWER_TYPE_COUNT = 34
FLOWER_TYPE_COUNT = 8
TILE_TYPE_COUNT = NON_FLOWER_TYPE_COUNT + FLOWER_TYPE_COUNT
COPIES_PER_NON_FLOWER = 4
NON_FLOWER_TILE_COUNT = NON_FLOWER_TYPE_COUNT * COPIES_PER_NON_FLOWER
TOTAL_TILE_COUNT = NON_FLOWER_TILE_COUNT + FLOWER_TYPE_COUNT


def _validate_id(value: int, limit: int, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{label} 必須是整數")
    if not 0 <= value < limit:
        raise ValueError(f"{label} 必須介於 0～{limit - 1}")


def tile_name(type_id: int) -> str:
    """根據牌型 ID（0～41）取得名稱。"""
    _validate_id(type_id, TILE_TYPE_COUNT, "牌型 ID")
    return TILE_NAMES[type_id]


def tile_suit(type_id: int) -> Suit:
    """取得牌型所屬花色／類別。"""
    _validate_id(type_id, TILE_TYPE_COUNT, "牌型 ID")
    if type_id < 9:
        return Suit.WAN
    if type_id < 18:
        return Suit.TONG
    if type_id < 27:
        return Suit.TIAO
    if type_id < NON_FLOWER_TYPE_COUNT:
        return Suit.HONOR
    return Suit.FLOWER


@dataclass(frozen=True)
class Tile:
    """一張實體牌；即使牌面相同，physical_id 也不同。

    0～135 是非花牌，每連續 4 個 ID 對應同一牌型。
    136～143 依序對應春、夏、秋、冬、梅、蘭、竹、菊。
    """

    physical_id: int

    def __post_init__(self) -> None:
        _validate_id(self.physical_id, TOTAL_TILE_COUNT, "實體牌 ID")

    @property
    def type_id(self) -> int:
        if self.physical_id < NON_FLOWER_TILE_COUNT:
            return self.physical_id // COPIES_PER_NON_FLOWER
        return NON_FLOWER_TYPE_COUNT + self.physical_id - NON_FLOWER_TILE_COUNT

    @property
    def name(self) -> str:
        return tile_name(self.type_id)

    @property
    def suit(self) -> Suit:
        return tile_suit(self.type_id)

    @property
    def is_flower(self) -> bool:
        return self.type_id >= NON_FLOWER_TYPE_COUNT


def create_deck() -> list[Tile]:
    """建立未洗牌的完整 144 張牌；每次回傳獨立的新清單。"""
    return [Tile(physical_id) for physical_id in range(TOTAL_TILE_COUNT)]


def initial_counts34() -> list[int]:
    """整副牌各非花牌的初始數量；不是玩家的起手牌。"""
    return [COPIES_PER_NON_FLOWER] * NON_FLOWER_TYPE_COUNT


def main() -> None:
    deck = create_deck()
    totals = Counter(tile.suit for tile in deck)
    print("台灣十六張麻將：初始牌組")
    for suit in Suit:
        names = [tile_name(i) for i in range(TILE_TYPE_COUNT) if tile_suit(i) == suit]
        print(f"{suit.value}：{'、'.join(names)}（共 {totals[suit]} 張）")
    print(f"非花牌：{sum(initial_counts34())} 張")
    print(f"總牌數：{len(deck)} 張")


if __name__ == "__main__":
    main()
