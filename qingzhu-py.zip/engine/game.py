"""明確子集的單局引擎：合法動作、收集反應、移牌與一般結算。"""

import json
import random
from collections import defaultdict
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from functools import lru_cache

from engine.actions import Action, ActionKind
from engine.rules import RulesConfig, load_rules, ordinary_flower_scoring
from engine.scoring import (
    SUPPORTED_PROFILE_VERSIONS,
    DrawOrigin,
    UnsupportedRuleError,
    WinContext,
    WinMethod,
    calculate_tai,
    settle_draw,
    settle_score,
)
from engine.state import (
    DiscardRecord,
    Event,
    EventKind,
    GameState,
    Meld,
    MeldKind,
    Phase,
    Wind,
    new_game_state,
)
from engine.tiles import Tile
from engine.win import analyze_player_hand, is_winning_hand


class IllegalActionError(ValueError):
    """不在該玩家當下合法清單中的動作。"""


@lru_cache(maxsize=32768)
def _structural_waits(
    counts: tuple[int, ...], fixed: tuple[int, ...], fixed_count: int
) -> tuple[int, ...]:
    """只快取自己的結構資料，不讀對手暗手、牌牆或事件歷史。"""
    result = []
    for kind in range(34):
        if counts[kind] + fixed[kind] < 4:
            candidate = list(counts)
            candidate[kind] += 1
            if is_winning_hand(candidate, fixed_meld_count=fixed_count):
                result.append(kind)
    return tuple(result)


def _check_flow_rules(rules: RulesConfig) -> None:
    """尚未泛化的行牌政策必須明確匹配；改 YAML 不可被靜默忽略。"""
    if rules.version not in SUPPORTED_PROFILE_VERSIONS or rules.pending_fields:
        raise ValueError("回合引擎僅接受目前明確子集")
    ordinary_flower_scoring(rules)
    expected = {
        "normal_draw_end": "front",
        "flower_replacement_end": "back",
        "kong_replacement_end": "back",
        "initial_flower_order": "dealer_order_rounds_new_flowers_wait_next_round",
        "initial_phase": "discard",
        "reserved_wall_tiles": 16,
        "chi_source": "previous_player_only",
        "reaction_priority": [["win"], ["pong", "kong"], ["chi"]],
        "same_priority_resolution": "nearest_from_source_in_turn_order",
        "multiple_winners": False,
        "minimum_tai": 0,
        "passed_win_restriction": {
            "enabled": False,
            "policy": "deferred_no_passed_win_restriction",
        },
        "rob_added_kong": {
            "enabled": True,
            "rob_concealed_kong": False,
            "rob_exposed_kong": False,
            "payment": "added_kong_player_is_discarder",
            "commit_kong_after_responses": True,
        },
        "post_chi_discard_restriction": {
            "chi": "forbid_all_tiles_completing_selected_two_tile_sequence",
            "pong": "forbid_same_type",
            "immediate_kong_after_chi_or_pong": False,
            "exposed_kong_from_previous_player": False,
            "claims_when_live_tiles_lte_3": ["win", "pass"],
            "self_draw_after_exposed_kong": False,
            "reserved_tiles_increase_per_kong": 1,
            "passed_pong_same_cycle_block": True,
            "concealed_kong_hidden_from_opponents": True,
            "self_kong_allowed_with_live_tiles_lte_3": True,
            "exposed_kong_enabled": False,
            "concealed_kong_after_declared_ready_enabled": False,
        },
    }
    table = rules.table_rules
    for key, value in expected.items():
        if table[key] != value:
            raise UnsupportedRuleError(f"行牌設定 {key} 尚未支援此值")
    special = table["tai_stacking"]["special_rules"]
    if (
        special["ready"]
        != {
            "enabled": True,
            "locks_concealed_hand": True,
            "automatic_added_kong": True,
            "record_original_waits": True,
            "concealed_kong_after_ready_enabled": False,
        }
        or special["early_wins"]
        != {
            "heavenly_win": False,
            "earthly_win": False,
            "human_win": "win_on_source_players_first_discard",
        }
        or special["flower_wins"]["enabled"] is not False
    ):
        raise UnsupportedRuleError("特殊行牌設定與目前子集不符")


@dataclass
class TurnData:
    extra_player: int | None = None
    drawn_tile: int | None = None
    draw_origin: str | None = None
    last_normal_draw: bool = False
    can_self_kong: bool = True
    discard_counts: list[int] = field(default_factory=lambda: [0] * 4)
    forbidden_types: list[int] = field(default_factory=list)
    ready: list[bool] = field(default_factory=lambda: [False] * 4)
    ready_waits: list[list[int]] = field(default_factory=lambda: [[] for _ in range(4)])
    passed_pong: list[list[int]] = field(default_factory=lambda: [[] for _ in range(4)])
    reaction_kind: str | None = None
    reaction_source: int | None = None
    reaction_tile: int | None = None
    pending_kong: Action | None = None
    responses: dict[int, Action] = field(default_factory=dict)
    action_log: list[dict] = field(default_factory=list)
    terminal_reason: str | None = None
    winning_tile: int | None = None


class MahjongGame:
    """每個 episode 一手；支援凍結的簡化桌規與明確指定的舊版規則。"""

    def __init__(
        self,
        *,
        seed: int | None = None,
        wall_order: list[int] | None = None,
        dealer: int = 0,
        dealer_streak: int = 0,
        round_wind: Wind = Wind.EAST,
        rules: RulesConfig | None = None,
    ):
        self.rules = load_rules() if rules is None else rules
        _check_flow_rules(self.rules)
        if type(dealer_streak) is not int or not 0 <= dealer_streak <= 9:
            raise ValueError("連莊次數必須介於0～9")
        if not isinstance(round_wind, Wind):
            raise TypeError("圈風必須是 Wind")
        if wall_order is None:
            wall_order = list(range(144))
            random.Random(seed).shuffle(wall_order)
        self.state = new_game_state(
            self.rules.version, dealer=dealer, wall_order=wall_order
        )
        self.state.dealer_streak = dealer_streak
        self.state.round_wind = round_wind
        self.turn = TurnData(extra_player=dealer)
        self._deal()
        self.validate()

    @property
    def live_tiles(self) -> int:
        kongs = sum(
            m.kind not in (MeldKind.CHI, MeldKind.PONG)
            for p in self.state.players
            for m in p.melds
        )
        return max(self.state.wall.remaining_count - 16 - kongs, 0)

    @property
    def waiting_players(self) -> list[int]:
        if self.state.phase == Phase.FINISHED:
            return []
        if self.state.phase == Phase.REACTION:
            return [
                i
                for i in range(4)
                if i != self.turn.reaction_source and i not in self.turn.responses
            ]
        return [self.state.current_player]

    def _take(self, player: int, *, back: bool) -> int | None:
        if self.live_tiles <= 0:
            self._finish_draw()
            return None
        wall = self.state.wall
        if back:
            wall.supplement_index -= 1
            tile_id = wall.tile_ids[wall.supplement_index]
        else:
            tile_id = wall.tile_ids[wall.draw_index]
            wall.draw_index += 1
        tile = Tile(tile_id)
        owner = self.state.players[player]
        (owner.flowers if tile.is_flower else owner.hand).append(tile_id)
        self.state.events.append(
            Event(
                EventKind.FLOWER if tile.is_flower else EventKind.DRAW,
                player,
                [tile_id],
            )
        )
        if len(owner.flowers) >= 7 and not ordinary_flower_scoring(self.rules):
            raise UnsupportedRuleError(
                "遇到七／八花局面，需尚未完成的花胡評估器；不能當普通牌局繼續"
            )
        return tile_id

    def _deal(self) -> None:
        self.state.phase = Phase.DEALING
        order = [(self.state.dealer + i) % 4 for i in range(4)]
        for _ in range(4):
            for player in order:
                for _ in range(4):
                    self._take(player, back=False)
        self._take(self.state.dealer, back=False)
        needed = [len(p.flowers) for p in self.state.players]
        while any(needed):
            next_round = [0] * 4
            for player in order:
                for _ in range(needed[player]):
                    tile = self._take(player, back=True)
                    if tile is None:
                        return
                    next_round[player] += int(Tile(tile).is_flower)
            needed = next_round
        self.state.phase = Phase.DISCARD

    def _draw(self, origin: DrawOrigin = DrawOrigin.NORMAL) -> None:
        player = self.state.current_player
        normal = origin == DrawOrigin.NORMAL
        if normal:
            self.turn.passed_pong[player] = []
        tile = self._take(player, back=not normal)
        if tile is None:
            return
        is_last = normal and not Tile(tile).is_flower and self.live_tiles == 0
        while Tile(tile).is_flower:
            origin = DrawOrigin.FLOWER
            tile = self._take(player, back=True)
            if tile is None:
                return
        self.turn.extra_player = player
        self.turn.drawn_tile = tile
        self.turn.draw_origin = origin.value
        self.turn.last_normal_draw = is_last
        self.turn.can_self_kong = True
        self.turn.forbidden_types = []
        self.state.phase = Phase.DISCARD
        if self.turn.ready[player]:
            added = [
                a for a in self.legal_actions(player) if a.kind == ActionKind.ADDED_KONG
            ]
            if added:
                self._start_added_kong(added[0])

    def _waits(self, player: int, counts: list[int]) -> list[int]:
        fixed = [0] * 34
        for meld in self.state.players[player].melds:
            for tile in meld.tile_ids:
                fixed[Tile(tile).type_id] += 1
        return list(
            _structural_waits(
                tuple(counts), tuple(fixed), len(self.state.players[player].melds)
            )
        )

    def _context(self, player: int) -> WinContext:
        if self.state.phase == Phase.REACTION:
            source = self.turn.reaction_source
            method = (
                WinMethod.ROB_ADDED_KONG
                if self.turn.reaction_kind == "added_kong"
                else WinMethod.DISCARD
            )
            return WinContext(
                self.turn.reaction_tile,
                method,
                source,
                round_wind=self.state.round_wind,
                declared_ready=self.turn.ready[player],
                source_first_discard=method == WinMethod.DISCARD
                and self.turn.discard_counts[source] == 1,
            )
        return WinContext(
            self.turn.drawn_tile,
            WinMethod.SELF_DRAW,
            round_wind=self.state.round_wind,
            draw_origin=DrawOrigin(self.turn.draw_origin),
            declared_ready=self.turn.ready[player],
            last_normal_draw=self.turn.last_normal_draw,
        )

    def _can_win(self, player: int) -> bool:
        owner = self.state.players[player]
        if self.state.phase == Phase.DISCARD:
            return self.turn.drawn_tile is not None and bool(analyze_player_hand(owner))
        return bool(analyze_player_hand(owner, winning_tile_id=self.turn.reaction_tile))

    def legal_actions(
        self, player: int, *, _check_saved_response: bool = False
    ) -> tuple[Action, ...]:
        if type(player) is not int or not 0 <= player < 4:
            raise ValueError("座位必須介於0～3")
        if player not in self.waiting_players and not (
            _check_saved_response
            and self.state.phase == Phase.REACTION
            and player != self.turn.reaction_source
        ):
            return ()
        if self.state.phase == Phase.DRAW:
            return (Action(ActionKind.DRAW),)
        owner = self.state.players[player]
        by_type = defaultdict(list)
        for tile in sorted(owner.hand):
            by_type[Tile(tile).type_id].append(tile)
        if self.state.phase == Phase.REACTION:
            result = [Action(ActionKind.PASS)]
            if self._can_win(player):
                result.append(Action(ActionKind.WIN))
            if (
                self.turn.reaction_kind == "added_kong"
                or self.live_tiles <= 3
                or self.turn.ready[player]
            ):
                return tuple(result)
            kind = Tile(self.turn.reaction_tile).type_id
            if len(by_type[kind]) >= 2 and kind not in self.turn.passed_pong[player]:
                result.append(Action(ActionKind.PONG, tuple(by_type[kind][:2])))
            if player == (self.turn.reaction_source + 1) % 4 and kind < 27:
                for start in range(
                    max(kind // 9 * 9, kind - 2), min(kind, kind // 9 * 9 + 6) + 1
                ):
                    others = [i for i in range(start, start + 3) if i != kind]
                    if all(by_type[i] for i in others):
                        result.append(
                            Action(
                                ActionKind.CHI,
                                tuple(sorted(by_type[i][0] for i in others)),
                            )
                        )
            return tuple(result)
        if self.state.phase != Phase.DISCARD:
            raise ValueError("未支援的決策階段")
        result = []
        if self._can_win(player):
            result.append(Action(ActionKind.WIN))
        discards = [
            i
            for i in sorted(owner.hand)
            if Tile(i).type_id not in self.turn.forbidden_types
        ]
        if self.turn.ready[player]:
            discards = (
                [self.turn.drawn_tile] if self.turn.drawn_tile in owner.hand else []
            )
        for tile in discards:
            result.append(Action(ActionKind.DISCARD, (tile,)))
            if not self.turn.ready[player] and not any(
                m.kind == MeldKind.CONCEALED_KONG for m in owner.melds
            ):
                counts = owner.counts34()
                counts[Tile(tile).type_id] -= 1
                if self._waits(player, counts):
                    result.append(Action(ActionKind.DECLARE_READY, (tile,)))
        if self.turn.can_self_kong and self.live_tiles >= 2:
            if not self.turn.ready[player]:
                result.extend(
                    Action(ActionKind.CONCEALED_KONG, tuple(ids))
                    for ids in by_type.values()
                    if len(ids) == 4
                )
            for index, meld in enumerate(owner.melds):
                if meld.kind == MeldKind.PONG:
                    kind = Tile(meld.tile_ids[0]).type_id
                    if by_type[kind]:
                        if self.turn.ready[player]:
                            counts = owner.counts34()
                            counts[kind] -= 1
                            if (
                                self._waits(player, counts)
                                != self.turn.ready_waits[player]
                            ):
                                continue
                        result.append(
                            Action(ActionKind.ADDED_KONG, (by_type[kind][0],), index)
                        )
        return tuple(result)

    def apply(self, player: int, action: Action) -> None:
        if not isinstance(action, Action) or action not in self.legal_actions(player):
            raise IllegalActionError("不是該玩家當下可執行的動作")
        previous = deepcopy((self.state, self.turn))
        try:
            self._apply(player, action)
            self.turn.action_log.append({"player": player, "action": action.to_dict()})
            self.validate()
        except Exception:
            self.state, self.turn = previous
            raise

    def _apply(self, player: int, action: Action) -> None:
        kind = action.kind
        if self.state.phase == Phase.REACTION:
            if (
                any(a.kind == ActionKind.PONG for a in self.legal_actions(player))
                and kind != ActionKind.PONG
            ):
                tile_type = Tile(self.turn.reaction_tile).type_id
                if tile_type not in self.turn.passed_pong[player]:
                    self.turn.passed_pong[player].append(tile_type)
            self.turn.responses[player] = action
            if not self.waiting_players:
                self._resolve()
        elif kind == ActionKind.DRAW:
            self._draw()
        elif kind == ActionKind.WIN:
            self._finish_win(player)
        elif kind in (ActionKind.DISCARD, ActionKind.DECLARE_READY):
            tile = action.tile_ids[0]
            if kind == ActionKind.DECLARE_READY:
                counts = self.state.players[player].counts34()
                counts[Tile(tile).type_id] -= 1
                self.turn.ready[player] = True
                self.turn.ready_waits[player] = self._waits(player, counts)
                self.state.events.append(Event(EventKind.READY, player))
            self.state.players[player].hand.remove(tile)
            self.state.players[player].river.append(tile)
            self.state.last_discard = DiscardRecord(tile, player)
            self.state.events.append(Event(EventKind.DISCARD, player, [tile]))
            self.turn.discard_counts[player] += 1
            self.turn.extra_player = None
            self.turn.forbidden_types = []
            self._reaction("discard", player, tile)
        elif kind == ActionKind.CONCEALED_KONG:
            owner = self.state.players[player]
            for tile in action.tile_ids:
                owner.hand.remove(tile)
            owner.melds.append(Meld(MeldKind.CONCEALED_KONG, list(action.tile_ids)))
            self.state.events.append(
                Event(EventKind.MELD, player, list(action.tile_ids))
            )
            self.turn.extra_player = None
            self._draw(DrawOrigin.CONCEALED_KONG)
        elif kind == ActionKind.ADDED_KONG:
            self._start_added_kong(action)

    def _reaction(self, kind: str, source: int, tile: int) -> None:
        self.state.phase = Phase.REACTION
        self.turn.reaction_kind, self.turn.reaction_source, self.turn.reaction_tile = (
            kind,
            source,
            tile,
        )
        self.turn.responses = {}

    def _start_added_kong(self, action: Action) -> None:
        self.turn.pending_kong = action
        self.state.last_discard = None
        self._reaction("added_kong", self.state.current_player, action.tile_ids[0])

    def _resolve(self) -> None:
        source, tile = self.turn.reaction_source, self.turn.reaction_tile
        ordered = [(source + i) % 4 for i in range(1, 4)]
        for player in ordered:
            if self.turn.responses[player].kind == ActionKind.WIN:
                self._finish_win(player)
                self._clear_reaction()
                return
        if self.turn.reaction_kind == "added_kong":
            action = self.turn.pending_kong
            owner = self.state.players[source]
            owner.hand.remove(tile)
            meld = owner.melds[action.meld_index]
            meld.tile_ids.append(tile)
            meld.kind = MeldKind.ADDED_KONG
            self.state.events.append(Event(EventKind.MELD, source, [tile]))
            self.turn.extra_player = None
            self._clear_reaction()
            self._draw(DrawOrigin.ADDED_KONG)
            return
        winner = None
        for priority in (ActionKind.PONG, ActionKind.CHI):
            winner = next(
                (p for p in ordered if self.turn.responses[p].kind == priority), None
            )
            if winner is not None:
                break
        if winner is not None:
            action = self.turn.responses[winner]
            owner = self.state.players[winner]
            for hand_tile in action.tile_ids:
                owner.hand.remove(hand_tile)
            self.state.players[source].river.remove(tile)
            ids = list(action.tile_ids) + [tile]
            owner.melds.append(
                Meld(
                    MeldKind.PONG if action.kind == ActionKind.PONG else MeldKind.CHI,
                    ids,
                    source,
                    tile,
                )
            )
            self.state.events.append(Event(EventKind.MELD, winner, list(ids)))
            tile_type = Tile(tile).type_id
            if action.kind == ActionKind.PONG:
                forbidden = [tile_type]
            else:
                types = [Tile(i).type_id for i in action.tile_ids]
                forbidden = [
                    i
                    for i in range(tile_type // 9 * 9, tile_type // 9 * 9 + 9)
                    if len(set(types + [i])) == 3
                    and max(types + [i]) - min(types + [i]) == 2
                ]
            self._clear_reaction()
            self.state.current_player = winner
            self.state.phase = Phase.DISCARD
            self.turn.extra_player = winner
            self.turn.drawn_tile, self.turn.draw_origin = None, None
            self.turn.last_normal_draw = False
            self.turn.can_self_kong = False
            self.turn.forbidden_types = forbidden
            return
        self._clear_reaction()
        self.state.current_player = (source + 1) % 4
        self.turn.drawn_tile, self.turn.draw_origin = None, None
        if not self.live_tiles:
            self._finish_draw()
        else:
            self.state.phase = Phase.DRAW

    def _clear_reaction(self) -> None:
        self.turn.reaction_kind = None
        self.turn.reaction_source = None
        self.turn.reaction_tile = None
        self.turn.pending_kong = None
        self.turn.responses = {}

    def _finish_draw(self) -> None:
        self.turn.terminal_reason = "wall_exhausted"
        self.state.result = settle_draw()
        self.state.phase = Phase.FINISHED
        self.state.events.append(Event(EventKind.SETTLEMENT, self.state.current_player))

    def _finish_win(self, player: int) -> None:
        context = self._context(player)
        score = calculate_tai(self.state.players[player], context, rules=self.rules)
        self.state.result = settle_score(
            score,
            dealer=self.state.dealer,
            dealer_streak=self.state.dealer_streak,
            rules=self.rules,
        )
        self.turn.terminal_reason = context.method.value
        self.turn.winning_tile = context.winning_tile_id
        self.state.events.append(
            Event(EventKind.WIN, player, [context.winning_tile_id])
        )
        self.state.events.append(Event(EventKind.SETTLEMENT, player))
        self.state.phase = Phase.FINISHED
        self.state.current_player = player

    def validate(self) -> None:
        self.state.validate()
        ordinary_flowers = ordinary_flower_scoring(self.rules)
        if self.state.rules_version != self.rules.version:
            raise ValueError("牌局與引擎規則版本不符")
        if self.state.phase not in {
            Phase.DRAW,
            Phase.DISCARD,
            Phase.REACTION,
            Phase.FINISHED,
        }:
            raise ValueError("回合快照不在可續接的階段")
        if self.state.phase == Phase.DRAW and self.turn.extra_player is not None:
            raise ValueError("待摸牌時四家不應持有多餘牌")
        if (
            self.state.phase == Phase.DISCARD
            and self.turn.extra_player != self.state.current_player
        ):
            raise ValueError("待打牌者必須持有多一張牌")
        if self.state.phase != Phase.FINISHED and (
            self.state.result is not None or self.turn.terminal_reason is not None
        ):
            raise ValueError("尚未終局不可保留結算")
        if self.state.phase == Phase.FINISHED:
            if self.turn.terminal_reason not in {
                "wall_exhausted",
                *(m.value for m in WinMethod),
            }:
                raise ValueError("終局原因無效")
            if self.turn.terminal_reason != "wall_exhausted":
                Tile(self.turn.winning_tile)
        t = self.turn
        for field_value in (t.discard_counts, t.ready, t.ready_waits, t.passed_pong):
            if len(field_value) != 4:
                raise ValueError("回合欄位必須記錄四家")
        for kinds in (t.forbidden_types, *t.ready_waits, *t.passed_pong):
            if any(type(i) is not int or not 0 <= i < 34 for i in kinds):
                raise ValueError("回合牌型欄位無效")
        if type(t.last_normal_draw) is not bool or type(t.can_self_kong) is not bool:
            raise ValueError("回合旗標必須是布林值")
        if t.drawn_tile is not None:
            Tile(t.drawn_tile)
            if t.draw_origin not in {
                o.value for o in DrawOrigin if o != DrawOrigin.EXPOSED_KONG
            }:
                raise ValueError("摸牌來源無效")
            if (
                self.state.phase == Phase.DISCARD
                and t.drawn_tile
                not in self.state.players[self.state.current_player].hand
            ):
                raise ValueError("完成牌不在目前玩家手牌")
        if any(type(i) is not int or i < 0 for i in t.discard_counts) or any(
            type(i) is not bool for i in t.ready
        ):
            raise ValueError("回合計數或宣告旗標無效")
        if t.extra_player is not None and (
            type(t.extra_player) is not int or not 0 <= t.extra_player < 4
        ):
            raise ValueError("多一張牌的玩家座位不符")
        for player in self.state.players:
            if (len(player.flowers) >= 7 and not ordinary_flowers) or any(
                m.kind == MeldKind.EXPOSED_KONG for m in player.melds
            ):
                raise UnsupportedRuleError("回合快照含未支援的花胡或大明槓")
            expected = 16 - 3 * len(player.melds) + int(player.seat == t.extra_player)
            if len(player.hand) != expected:
                raise ValueError("暗手張數不符合目前階段與固定面子")
            if t.ready[player.seat] and not t.ready_waits[player.seat]:
                raise ValueError("已宣告玩家必須保存等待集合")
            if t.ready[player.seat] and any(
                m.kind == MeldKind.CONCEALED_KONG for m in player.melds
            ):
                raise UnsupportedRuleError("宣告與暗槓組合尚未支援")
        if self.state.phase == Phase.REACTION:
            if (
                t.reaction_kind not in ("discard", "added_kong")
                or type(t.reaction_source) is not int
                or t.reaction_source not in range(4)
            ):
                raise ValueError("等待反應來源無效")
            Tile(t.reaction_tile)
            if self.state.current_player != t.reaction_source:
                raise ValueError("反應階段來源與目前玩家不符")
            if t.reaction_kind == "discard":
                if t.extra_player is not None or t.pending_kong is not None:
                    raise ValueError("棄牌反應不可有多餘牌或待加槓")
                if self.state.last_discard != DiscardRecord(
                    t.reaction_tile, t.reaction_source
                ):
                    raise ValueError("反應牌與最近棄牌不符")
            else:
                if t.extra_player != t.reaction_source:
                    raise ValueError("加槓者應尚持有第四張牌")
                action = t.pending_kong
                owner = self.state.players[t.reaction_source]
                if (
                    action is None
                    or action.kind != ActionKind.ADDED_KONG
                    or action.tile_ids != (t.reaction_tile,)
                    or t.reaction_tile not in owner.hand
                    or action.meld_index >= len(owner.melds)
                ):
                    raise ValueError("待提交的加槓不符")
                meld = owner.melds[action.meld_index]
                if (
                    meld.kind != MeldKind.PONG
                    or Tile(meld.tile_ids[0]).type_id != Tile(t.reaction_tile).type_id
                ):
                    raise ValueError("加槓必須補在同牌碰子上")
            if any(
                type(p) is not int or p not in range(4) or p == t.reaction_source
                for p in t.responses
            ):
                raise ValueError("反應玩家不符")
            for player, action in t.responses.items():
                if action not in self.legal_actions(player, _check_saved_response=True):
                    raise ValueError("保存的反應不是合法動作")
        elif (
            any(
                value is not None
                for value in (
                    t.reaction_kind,
                    t.reaction_source,
                    t.reaction_tile,
                    t.pending_kong,
                )
            )
            or t.responses
        ):
            raise ValueError("非反應階段不應保留主張")

    def player_view(self, player: int) -> dict:
        view = self.state.to_player_view(player)
        view.update(
            {
                "live_tiles": self.live_tiles,
                "declared_ready": list(self.turn.ready),
                "legal_actions": [a.to_dict() for a in self.legal_actions(player)],
                "reaction": None
                if self.turn.reaction_kind is None
                else {
                    "kind": self.turn.reaction_kind,
                    "source": self.turn.reaction_source,
                    "tile_id": self.turn.reaction_tile,
                },
                "result": asdict(self.state.result)
                if self.state.result is not None
                else None,
            }
        )
        view["terminal_reason"] = self.turn.terminal_reason
        view["winning_tile"] = self.turn.winning_tile
        return view

    def to_json(self) -> str:
        self.validate()
        runtime = asdict(self.turn)
        runtime["pending_kong"] = (
            self.turn.pending_kong.to_dict() if self.turn.pending_kong else None
        )
        runtime["responses"] = {
            str(p): a.to_dict() for p, a in self.turn.responses.items()
        }
        return json.dumps(
            {"game_schema_version": 1, "state": self.state.to_dict(), "turn": runtime},
            ensure_ascii=False,
            indent=2,
        )

    @classmethod
    def from_json(cls, text: str, *, rules: RulesConfig | None = None) -> "MahjongGame":
        data = json.loads(text)
        if (
            not isinstance(data, dict)
            or set(data) != {"game_schema_version", "state", "turn"}
            or type(data["game_schema_version"]) is not int
            or data["game_schema_version"] != 1
        ):
            raise ValueError("回合快照格式無效")
        game = cls.__new__(cls)
        game.rules = load_rules() if rules is None else rules
        _check_flow_rules(game.rules)
        game.state = GameState.from_dict(data["state"])
        runtime = data["turn"]
        if any(p not in {"0", "1", "2", "3"} for p in runtime["responses"]):
            raise ValueError("反應座位格式無效")
        runtime["pending_kong"] = (
            Action.from_dict(runtime["pending_kong"])
            if runtime["pending_kong"]
            else None
        )
        runtime["responses"] = {
            int(p): Action.from_dict(a) for p, a in runtime["responses"].items()
        }
        game.turn = TurnData(**runtime)
        game.validate()
        return game
