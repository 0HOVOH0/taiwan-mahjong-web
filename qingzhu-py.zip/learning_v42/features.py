"""Public V4.2 after-action tile structure and conditional ordinary-hand value.

The first forty fields and teacher score are the frozen V4 contract.  Added
fields describe the student's own tiles and public table only.  Waiting-hand
values are conditional on a future discard win under an unseen-pool prior;
they are neither a winning probability nor an expected return for the action.
"""

from dataclasses import replace
from functools import lru_cache

import numpy as np

from engine_v4.rules import load_rules
from engine_v4.scoring import WinContext, WinMethod, calculate_tai, settle_score
from engine_v4.state import Meld, MeldKind, PlayerState, Wind
from engine_v4.tiles import Tile
from learning_v4.features import (
    ACTION_KINDS,
    MAX_ACTIONS,
    ActionAnalysis,
    canonical_actions,
    kind_of,
)
from learning_v4.features import (
    FEATURE_NAMES as V4_FEATURE_NAMES,
)
from learning_v4.features import (
    analyze_actions as analyze_v4_actions,
)

FEATURE_VERSION = "public-structure-value-v42.0"
VALUE_FEATURE_NAMES = (
    "value_dragon_triplet_fraction",
    "value_seat_wind_triplet",
    "value_round_wind_triplet",
    "value_suit_concentration",
    "value_ordinary_flower_tai_fraction",
    "waiting_discard_tai_mean_scaled",
    "waiting_discard_points_mean_scaled",
    "waiting_discard_value_available",
)
FEATURE_NAMES = (
    tuple(V4_FEATURE_NAMES)
    + tuple(f"after_hand_type_{i}" for i in range(34))
    + tuple(f"after_fixed_meld_type_{i}" for i in range(34))
    + tuple(f"related_type_{i}" for i in range(34))
    + VALUE_FEATURE_NAMES
)
FEATURE_DIM = len(FEATURE_NAMES)
STATE_DIM = 326
STATE_NAMES = (
    tuple(f"own_hand_{i}" for i in range(34))
    + tuple(f"relative_{seat}_river_{i}" for seat in range(4) for i in range(34))
    + tuple(f"relative_{seat}_visible_meld_{i}" for seat in range(4) for i in range(34))
    + tuple(f"relative_{seat}_ready" for seat in range(4))
    + tuple(f"relative_{seat}_flower_fraction" for seat in range(4))
    + tuple(f"relative_{seat}_dealer" for seat in range(4))
    + tuple(f"round_wind_{wind.value}" for wind in Wind)
    + tuple(f"own_seat_wind_{wind.value}" for wind in Wind)
)
VALUE_NOTE = (
    "Exact ordinary scoring conditional on a future discard win, averaging "
    "publicly unseen winning types and possible payer seats. This is not the "
    "current supplement's legality, win probability, or expected action return. "
    "Non-ready hands use only explicitly named structural value potentials."
)
assert FEATURE_DIM == 150 and len(STATE_NAMES) == STATE_DIM

__all__ = [
    "ACTION_KINDS",
    "FEATURE_DIM",
    "FEATURE_NAMES",
    "FEATURE_VERSION",
    "MAX_ACTIONS",
    "STATE_DIM",
    "STATE_NAMES",
    "VALUE_FEATURE_NAMES",
    "VALUE_NOTE",
    "ActionAnalysis",
    "after_action_tiles",
    "analyze_actions",
    "candidate_matrix",
    "canonical_actions",
    "encode_state",
    "kind_of",
]


@lru_cache(maxsize=1)
def _default_rules():
    return load_rules()


def _own(view):
    viewer = view["viewer"]
    return next(player for player in view["players"] if player["seat"] == viewer)


def _counts(ids):
    counts = np.zeros(34, dtype=np.float32)
    for tile_id in ids:
        kind = Tile(tile_id).type_id
        if kind >= 34:
            raise ValueError("flowers cannot be encoded as concealed/meld tiles")
        counts[kind] += 1
    if np.any(counts > 4):
        raise ValueError("more than four identical tiles in a public area")
    return counts


def _visible_meld_ids(player, viewer):
    # Check visibility before reading tile_ids, even if an unsafe caller injects
    # hidden identities into a supposed public view.
    return [
        tile
        for meld in player["melds"]
        if player["seat"] == viewer or meld["kind"] != "concealed_kong"
        for tile in (meld.get("tile_ids") or ())
    ]


def _public_view(view):
    players = []
    for player in view["players"]:
        if player["seat"] == view["viewer"]:
            players.append(player)
            continue
        players.append(
            {
                **player,
                "hand": None,
                "melds": [
                    {**meld, "tile_ids": None}
                    if meld["kind"] == "concealed_kong"
                    else meld
                    for meld in player["melds"]
                ],
            }
        )
    return {**view, "players": players}


def _known_counts(view):
    physical = set(_own(view)["hand"])
    for player in view["players"]:
        physical.update(player["river"])
        physical.update(_visible_meld_ids(player, view["viewer"]))
    for reference in (view.get("reaction"), view.get("last_discard")):
        if reference is not None:
            physical.add(reference["tile_id"])
    return _counts(physical)


def encode_state(view):
    """Encode own hand and public table in clockwise relative-seat order."""
    viewer = view["viewer"]
    own = _own(view)
    if not isinstance(own["hand"], list):
        raise TypeError("only the student's own concealed hand may be encoded")
    players = {player["seat"]: player for player in view["players"]}
    order = [(viewer + offset) % 4 for offset in range(4)]
    winds = list(Wind)
    parts = [_counts(own["hand"]) / 4]
    parts.extend(_counts(players[seat]["river"]) / 4 for seat in order)
    parts.extend(
        _counts(_visible_meld_ids(players[seat], viewer)) / 4 for seat in order
    )
    parts.extend(
        (
            np.asarray(
                [view.get("declared_ready", [False] * 4)[seat] for seat in order]
            ),
            np.asarray([len(players[seat]["flowers"]) / 8 for seat in order]),
            np.asarray([float(view.get("dealer", 0) == seat) for seat in order]),
            np.asarray(
                [float(Wind(view.get("round_wind", "east")) == wind) for wind in winds]
            ),
            np.asarray([float(Wind(own["seat_wind"]) == wind) for wind in winds]),
        )
    )
    result = np.concatenate(parts).astype(np.float32)
    if result.shape != (STATE_DIM,) or not np.isfinite(result).all():
        raise ValueError("invalid V4.2 public state")
    if np.any(result < 0) or np.any(result > 1):
        raise ValueError("public state outside normalized bounds")
    return result


def _meld_from_public(meld):
    kind = MeldKind(meld["kind"])
    ids = list(meld["tile_ids"])
    return Meld(
        kind,
        ids,
        None if kind == MeldKind.CONCEALED_KONG else meld["source_player"],
        None if kind == MeldKind.CONCEALED_KONG else ids[0],
    )


def after_action_tiles(view, row):
    """Reconstruct the exact own waiting boundary used by V4's teacher."""
    own = _own(view)
    hand = list(own["hand"])
    melds = [_meld_from_public(meld) for meld in own["melds"]]
    kind = row.kind
    action = row.action
    if kind in (
        "discard",
        "declare_ready",
        "chi",
        "pong",
        "concealed_kong",
        "added_kong",
        "exposed_kong",
    ):
        for tile in action.tile_ids:
            hand.remove(tile)
    if kind in ("chi", "pong", "exposed_kong"):
        reaction = view["reaction"]
        claimed = reaction["tile_id"]
        melds.append(
            Meld(
                MeldKind(kind),
                sorted([*action.tile_ids, claimed]),
                reaction["source"],
                claimed,
            )
        )
    elif kind == "concealed_kong":
        melds.append(Meld(MeldKind.CONCEALED_KONG, list(action.tile_ids)))
    elif kind == "added_kong":
        old = melds[action.meld_index]
        if old.kind != MeldKind.PONG:
            raise ValueError("added kong must extend a pong")
        melds[action.meld_index] = Meld(
            MeldKind.ADDED_KONG,
            [*old.tile_ids, *action.tile_ids],
            old.source_player,
            old.claimed_tile_id,
        )
    if row.followup_discard_type is not None:
        discarded = next(
            tile for tile in hand if Tile(tile).type_id == row.followup_discard_type
        )
        hand.remove(discarded)
    if len(hand) != row.after_hand_count or len(melds) != row.after_fixed_meld_count:
        raise ValueError("V4.2 after-action structure disagrees with frozen V4 profile")
    return hand, melds


def _ordinary_flower_tai(own, rules):
    flowers = {Tile(tile).type_id for tile in own["flowers"]}
    table = rules.table_rules
    config = table["tai_stacking"]
    covered = set()
    tai = 0
    for group in config["flower_sets"]:
        if set(group) <= flowers:
            covered.update(group)
            tai += table["tai_table"]["flower_set_each"]
    matching = set(config["flower_type_ids_by_seat_wind"][own["seat_wind"]])
    tai += len((flowers - covered) & matching) * table["tai_table"]["seat_flower_each"]
    return tai


def _waiting_value(view, row, hand, melds, known, rules):
    if row.profile.shanten != 0 or len(hand) != 16 - 3 * len(melds):
        return 0.0, 0.0, False
    own = _own(view)
    viewer = view["viewer"]
    player = PlayerState(
        viewer, Wind(own["seat_wind"]), hand, melds, list(own["flowers"])
    )
    used = set(hand) | {tile for meld in melds for tile in meld.tile_ids}
    weights, tai_values, point_values = [], [], []
    for kind in row.profile.effective_types:
        remaining = 4 - known[kind]
        if remaining <= 0:
            continue
        tile = next(
            (tile for tile in range(kind * 4, kind * 4 + 4) if tile not in used), None
        )
        if tile is None:
            continue
        payers = [seat for seat in range(4) if seat != viewer]
        context = WinContext(
            tile,
            WinMethod.DISCARD,
            source_player=payers[0],
            round_wind=Wind(view.get("round_wind", "east")),
            declared_ready=bool(
                view.get("declared_ready", [False] * 4)[viewer]
                or row.kind == "declare_ready"
            ),
            # These are hypothetical completions of the exact current hand;
            # no claim is made about a future ready-kong action being legal.
            ready_concealed_kong_validated=True,
        )
        score = calculate_tai(player, context, rules=rules)
        for payer in payers:
            settlement = settle_score(
                replace(score, source_player=payer),
                dealer=view.get("dealer", 0),
                dealer_streak=view.get("dealer_streak", 0),
                rules=rules,
            )
            weights.append(remaining)
            tai_values.append(score.tai)
            point_values.append(settlement.payments[viewer])
    if not weights:
        return 0.0, 0.0, False
    return (
        float(np.average(tai_values, weights=weights)),
        float(np.average(point_values, weights=weights)),
        True,
    )


def analyze_actions(view, legal_actions, rules=None):
    """Extend frozen V4 rows, retaining every canonical action and teacher score."""
    rules = _default_rules() if rules is None else rules
    view = _public_view(view)
    rows = analyze_v4_actions(view, legal_actions)
    own = _own(view)
    known = _known_counts(view)
    round_type = 27 + list(Wind).index(Wind(view.get("round_wind", "east")))
    seat_type = 27 + list(Wind).index(Wind(own["seat_wind"]))
    flowers = _ordinary_flower_tai(own, rules)
    results = []
    for row in rows:
        hand, melds = after_action_tiles(view, row)
        counts = _counts(hand)
        fixed = _counts([tile for meld in melds for tile in meld.tile_ids])
        related = np.zeros(34, dtype=np.float32)
        for tile in row.action.tile_ids:
            related[Tile(tile).type_id] = 1
        if view.get("reaction") and row.kind in (
            "pass",
            "chi",
            "pong",
            "exposed_kong",
            "win",
        ):
            related[Tile(view["reaction"]["tile_id"]).type_id] = 1
        triplets = {kind for kind, count in enumerate(counts) if count >= 3}
        triplets.update(
            Tile(meld.tile_ids[0]).type_id
            for meld in melds
            if meld.kind != MeldKind.CHI
        )
        combined = counts + fixed
        suit_totals = [sum(combined[start : start + 9]) for start in (0, 9, 18)]
        concentration = max(suit_totals) / max(1, sum(combined))
        mean_tai, mean_points, available = _waiting_value(
            view, row, hand, melds, known, rules
        )
        value = np.asarray(
            (
                len(triplets & {31, 32, 33}) / 3,
                float(seat_type in triplets),
                float(round_type in triplets),
                concentration,
                flowers / 8,
                mean_tai / 32,
                mean_points / 2048,
                float(available),
            ),
            dtype=np.float32,
        )
        features = np.concatenate(
            (row.features, counts / 4, fixed / 4, related, np.clip(value, 0, 1))
        ).astype(np.float32)
        if features.shape != (FEATURE_DIM,) or not np.isfinite(features).all():
            raise ValueError("invalid V4.2 candidate features")
        explanation = {
            **row.explanation,
            "value_note": VALUE_NOTE,
            "waiting_discard_tai_mean": mean_tai if available else None,
            "waiting_discard_points_mean": mean_points if available else None,
            "ordinary_flower_tai": flowers,
        }
        results.append(replace(row, features=features, explanation=explanation))
    return tuple(results)


def candidate_matrix(candidates):
    if not candidates or len(candidates) > MAX_ACTIONS:
        raise ValueError("V4.2 needs 1..96 distinct public legal actions")
    matrix = np.zeros((MAX_ACTIONS, FEATURE_DIM), dtype=np.float32)
    mask = np.zeros(MAX_ACTIONS, dtype=np.float32)
    for index, row in enumerate(candidates):
        matrix[index] = row.features
        mask[index] = 1
    return matrix, mask
