"""Gym interface for every legal discard, chi, pong, kong and pass candidate."""

import json
import random
from collections import Counter
from copy import deepcopy
from pathlib import Path
from typing import ClassVar

import gymnasium as gym
import numpy as np
from gymnasium import spaces
from gymnasium.error import ResetNeeded

from engine_v4.actions import ActionKind
from engine_v4.game import IllegalActionError, MahjongGame
from engine_v4.rules import load_rules
from engine_v4.state import MeldKind, Phase, Wind
from engine_v4.tiles import Tile
from evaluation.batch import derive_seed
from learning_v4.strategy import TeacherAgent
from learning_v42.features import (
    FEATURE_NAMES,
    MAX_ACTIONS,
    STATE_DIM,
    analyze_actions,
    encode_state,
)

CONTEXT_DIM = 16
ENV_CONTRACT_VERSION = "calls-public-context-v4.2-decision-only"
FIXED_POLICY = "win_draw_auto_ready_v42_optional_calls"


def public_observation(view, rows, *, terminal_delivery=False):
    """Encode only an already redacted view and its complete candidate list."""
    candidates = np.zeros((MAX_ACTIONS, len(FEATURE_NAMES)), np.float32)
    mask = np.zeros(MAX_ACTIONS, np.float32)
    context = np.zeros(CONTEXT_DIM, np.float32)
    state = np.zeros(STATE_DIM, np.float32)
    if terminal_delivery:
        mask[0] = context[-1] = 1
    elif view is not None:
        if not 0 < len(rows) <= MAX_ACTIONS:
            raise ValueError("public observation requires all legal candidates")
        for index, row in enumerate(rows):
            candidates[index] = row.features
            mask[index] = 1
        seat = view["viewer"]
        own = next(p for p in view["players"] if p["seat"] == seat)
        others = [p for p in view["players"] if p["seat"] != seat]
        context[:15] = (
            view["live_tiles"] / 144,
            view["remaining_tiles"] / 144,
            len(own["melds"]) / 5,
            own["hand_count"] / 17,
            float(view["declared_ready"][seat]),
            float(any(view["declared_ready"][p["seat"]] for p in others)),
            max(len(p["melds"]) for p in others) / 5,
            len(own["flowers"]) / 8,
            float(view["dealer"] == seat),
            view["dealer_streak"] / 9,
            float(view["reaction"] is not None),
            len(rows) / MAX_ACTIONS,
            len(own["river"]) / 136,
            max(len(p["river"]) for p in others) / 136,
            sum(len(p["melds"]) for p in view["players"]) / 20,
        )
        state[:] = encode_state(view)
    return {
        "candidates": candidates,
        "candidate_mask": mask,
        "context": context,
        "state": state,
    }


def safe_public_history(game, viewer):
    """Controller redacts hidden events before any strategy sees the history."""
    concealed = {
        frozenset(m.tile_ids)
        for p in game.state.players
        if p.seat != viewer
        for m in p.melds
        if m.kind == MeldKind.CONCEALED_KONG
    }
    result = []
    for event in game.state.events:
        hidden = event.player != viewer and (
            event.kind.value == "draw"
            or (event.kind.value == "meld" and frozenset(event.tile_ids) in concealed)
        )
        result.append(
            {
                "kind": event.kind.value,
                "player": event.player,
                "tile_count": len(event.tile_ids),
                "types": []
                if hidden
                else [Tile(tile).type_id for tile in event.tile_ids],
            }
        )
    return result


def common_ready_policy(actions, auto_ready=True):
    """Canonicalize physical duplicates, retaining every different call and pass."""
    ready = {
        Tile(a.tile_ids[0]).type_id
        for a in actions
        if a.kind == ActionKind.DECLARE_READY
    }
    selected = []
    seen = set()
    for action in actions:
        if action.kind == ActionKind.DECLARE_READY and not auto_ready:
            continue
        if (
            action.kind == ActionKind.DISCARD
            and auto_ready
            and Tile(action.tile_ids[0]).type_id in ready
        ):
            continue
        key = (
            action.kind.value,
            tuple(sorted(Tile(tile).type_id for tile in action.tile_ids)),
            action.meld_index,
        )
        if key not in seen:
            seen.add(key)
            selected.append(action)
    return tuple(
        sorted(
            selected,
            key=lambda a: (
                a.kind.value,
                tuple(Tile(t).type_id for t in a.tile_ids),
                -1 if a.meld_index is None else a.meld_index,
            ),
        )
    )


class CallsEnv(gym.Env):
    metadata: ClassVar[dict] = {"render_modes": ["ansi"], "render_fps": 1}

    def __init__(
        self,
        *,
        rules=None,
        controlled_seat=None,
        opponents="teacher",
        reward_scale=100.0,
        max_decisions=None,
        max_engine_actions=1600,
        auto_ready=True,
        render_mode=None,
    ):
        super().__init__()
        if controlled_seat is not None and (
            type(controlled_seat) is not int or controlled_seat not in range(4)
        ):
            raise ValueError("controlled_seat must be None or seat 0..3")
        names = (opponents,) * 4 if isinstance(opponents, str) else tuple(opponents)
        if len(names) != 4 or any(name not in ("teacher", "random") for name in names):
            raise ValueError("opponents must be teacher/random or four strategy names")
        if (
            type(reward_scale) not in (int, float)
            or not np.isfinite(reward_scale)
            or reward_scale <= 0
        ):
            raise ValueError("reward_scale must be positive and finite")
        if max_decisions is not None and (
            type(max_decisions) is not int or max_decisions < 1
        ):
            raise ValueError("max_decisions must be None or positive")
        if (
            type(max_engine_actions) is not int
            or max_engine_actions < 1
            or type(auto_ready) is not bool
        ):
            raise ValueError("invalid action limit or ready policy")
        if render_mode not in (None, "ansi"):
            raise ValueError("unsupported render mode")
        self.rules = load_rules() if rules is None else rules
        self.controlled_seat, self.opponent_names = controlled_seat, names
        self.reward_scale, self.max_decisions = float(reward_scale), max_decisions
        self.max_engine_actions, self.auto_ready, self.render_mode = (
            max_engine_actions,
            auto_ready,
            render_mode,
        )
        self.action_space = spaces.Discrete(MAX_ACTIONS)
        self.observation_space = spaces.Dict(
            {
                "candidates": spaces.Box(
                    0.0, 1.0, (MAX_ACTIONS, len(FEATURE_NAMES)), np.float32
                ),
                "candidate_mask": spaces.Box(0.0, 1.0, (MAX_ACTIONS,), np.float32),
                "context": spaces.Box(0.0, 1.0, (CONTEXT_DIM,), np.float32),
                "state": spaces.Box(0.0, 1.0, (STATE_DIM,), np.float32),
            }
        )
        self._game = None
        self._needs_reset = True
        self._pending_terminal = False
        self._candidates = ()
        self._last_failure = None
        self._initial = None
        self._attempted_action = None
        self.decision_steps = self.raw_decision_steps = 0
        self.forced_decision_steps = self.terminal_delivery_steps = 0
        self.engine_actions = self.episode_cursor = 0
        self.seat = 0
        self.action_counts = Counter()
        self.student_action_counts = Counter()
        self.student_forced_action_counts = Counter()
        self.student_automatic_action_counts = Counter()
        self.student_choice_counts = Counter()
        self.student_opportunities = Counter()
        self.student_multichoice_opportunities = Counter()
        self.student_multichoice_choices = Counter()
        self.student_decisions = []
        self._teacher = TeacherAgent()

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        options = {} if options is None else dict(options)
        if set(options) - {
            "wall_order",
            "dealer",
            "dealer_streak",
            "round_wind",
            "controlled_seat",
        }:
            raise ValueError("unknown reset options")
        self._needs_reset = True
        self._pending_terminal = False
        self._candidates = ()
        self._last_failure = None
        self._attempted_action = None
        self.decision_steps = self.raw_decision_steps = 0
        self.forced_decision_steps = self.terminal_delivery_steps = 0
        self.engine_actions = 0
        self.action_counts = Counter()
        self.student_action_counts = Counter()
        self.student_forced_action_counts = Counter()
        self.student_automatic_action_counts = Counter()
        self.student_choice_counts = Counter()
        self.student_opportunities = Counter()
        self.student_multichoice_opportunities = Counter()
        self.student_multichoice_choices = Counter()
        self.student_decisions = []
        self._episode_seed = int(self.np_random.integers(0, 2**63 - 1))
        self.episode_cursor += 1
        seat = options.get("controlled_seat", self.controlled_seat)
        self.seat = int(self.np_random.integers(4)) if seat is None else seat
        if type(self.seat) is not int or self.seat not in range(4):
            raise ValueError("invalid controlled seat")
        wall = deepcopy(options.get("wall_order"))
        if wall is None:
            wall = list(range(144))
            random.Random(derive_seed(self._episode_seed, "v4-wall")).shuffle(wall)
        self._initial = {
            "wall_order": wall,
            "dealer": options.get("dealer", int(self.np_random.integers(4))),
            "dealer_streak": options.get("dealer_streak", 0),
            "round_wind": Wind(options.get("round_wind", Wind.EAST)),
        }
        try:
            self._game = MahjongGame(rules=self.rules, **self._initial)
            self._advance()
        except Exception as error:
            self._fail(error, "reset")
            raise
        self._needs_reset = False
        self._pending_terminal = self._game.state.phase == Phase.FINISHED
        return self._observation(), self._info()

    def _view(self, player):
        view = self._game.player_view(player)
        view["public_history"] = safe_public_history(self._game, player)
        return view

    def player_view(self):
        if self._game is None:
            raise ResetNeeded("reset first")
        return self._view(self.seat)

    def legal_actions(self):
        return tuple(row.action for row in self._candidates)

    def legal_candidates(self):
        return self._candidates

    def candidate_index(self, action):
        return next(i for i, row in enumerate(self._candidates) if row.action == action)

    def teacher_action_index(self):
        if self._pending_terminal:
            return 0
        if not self._candidates:
            raise ResetNeeded("no current decision")
        return min(
            range(len(self._candidates)), key=lambda i: (self._candidates[i].score, i)
        )

    def _apply(self, player, action):
        self._attempted_action = {"player": player, "action": action.to_dict()}
        if self.engine_actions >= self.max_engine_actions:
            raise RuntimeError("engine action limit exceeded; not a fabricated draw")
        self._game.apply(player, action)
        self.engine_actions += 1
        self.action_counts[action.kind.value] += 1
        if player == self.seat:
            self.student_action_counts[action.kind.value] += 1
        self._attempted_action = None

    def _advance(self):
        self._candidates = ()
        while self._game.state.phase != Phase.FINISHED:
            player = self._game.waiting_players[0]
            native = self._game.legal_actions(player)
            automatic = next(
                (
                    a
                    for kind in (ActionKind.WIN, ActionKind.DRAW)
                    for a in native
                    if a.kind == kind
                ),
                None,
            )
            if automatic is not None:
                if player == self.seat:
                    self.student_automatic_action_counts[automatic.kind.value] += 1
                self._apply(player, automatic)
                continue
            actions = common_ready_policy(native, self.auto_ready)
            if not actions:
                raise RuntimeError("no legal candidate at a decision")
            if player == self.seat:
                self.raw_decision_steps += 1
                if len(actions) == 1:
                    self.forced_decision_steps += 1
                    action = actions[0]
                    self.student_forced_action_counts[action.kind.value] += 1
                    self.student_decisions.append(
                        {
                            "decision": self.raw_decision_steps - 1,
                            "policy_decision": None,
                            "kind": action.kind.value,
                            "legal_kinds": [action.kind.value],
                            "legal_count": 1,
                            "multi_choice": False,
                            "reaction": self._view(player)["reaction"] is not None,
                            "forced": True,
                        }
                    )
                    self._apply(player, action)
                    continue
                self._candidates = analyze_actions(
                    self._view(player), actions, rules=self.rules
                )
                if not 0 < len(self._candidates) <= MAX_ACTIONS:
                    raise RuntimeError("candidate overflow or missing legal action")
                if {r.action for r in self._candidates} != set(actions):
                    raise RuntimeError("candidate analysis dropped a legal action")
                return
            if self.opponent_names[player] == "random":
                action = actions[int(self.np_random.integers(len(actions)))]
            else:
                action = self._teacher.act(self._view(player), actions)
            if action not in actions:
                raise RuntimeError("opponent returned illegal action")
            self._apply(player, action)

    def action_masks(self):
        mask = np.zeros(MAX_ACTIONS, dtype=np.bool_)
        if not self._needs_reset:
            if self._pending_terminal:
                mask[0] = True
            else:
                mask[: len(self._candidates)] = True
        return mask

    def _observation(self):
        obs = public_observation(
            None if self._pending_terminal else self.player_view(),
            self._candidates,
            terminal_delivery=self._pending_terminal,
        )
        if not self.observation_space.contains(obs):
            raise ValueError(
                "candidate observation violates shape, bounds or finite contract"
            )
        return obs

    def step(self, action):
        if self._needs_reset:
            raise ResetNeeded("reset first")
        if (
            isinstance(action, (bool, np.bool_))
            or not self.action_space.contains(action)
            or not self.action_masks()[int(action)]
        ):
            raise IllegalActionError("action index outside legal candidate mask")
        if self._pending_terminal:
            self.terminal_delivery_steps += 1
            self._pending_terminal = False
            self._needs_reset = True
            obs = public_observation(None, ())
            return (
                obs,
                self._game.state.result.payments[self.seat] / self.reward_scale,
                True,
                False,
                self._info(),
            )
        chosen = self._candidates[int(action)].action
        try:
            self._record_choice(int(action))
            self._apply(self.seat, chosen)
            self._advance()
        except Exception as error:
            self._fail(error, "step")
            raise
        ended = self._game.state.phase == Phase.FINISHED
        truncated = (
            not ended
            and self.max_decisions is not None
            and self.decision_steps >= self.max_decisions
        )
        self._pending_terminal = ended
        obs = self._observation()
        # Final observations retain a nonempty delivery mask for value bootstrapping.
        reward = (
            self._game.state.result.payments[self.seat] / self.reward_scale
            if ended
            else 0.0
        )
        self._needs_reset = ended or truncated
        return obs, reward, ended, truncated, self._info(truncated=truncated)

    def _record_choice(self, index):
        row = self._candidates[index]
        kinds = sorted({r.action.kind.value for r in self._candidates})
        multi = len(self._candidates) > 1
        kind = row.action.kind.value
        self.student_choice_counts[kind] += 1
        self.student_opportunities.update(kinds)
        if multi:
            self.student_multichoice_opportunities.update(kinds)
            self.student_multichoice_choices[kind] += 1
        self.student_decisions.append(
            {
                "decision": self.raw_decision_steps - 1,
                "policy_decision": self.decision_steps,
                "kind": kind,
                "type_ids": [Tile(t).type_id for t in row.action.tile_ids],
                "legal_kinds": kinds,
                "legal_count": len(self._candidates),
                "multi_choice": multi,
                "reaction": self.player_view()["reaction"] is not None,
                "teacher_kind": self._candidates[
                    self.teacher_action_index()
                ].action.kind.value,
                "after_shanten": row.profile.shanten,
                "after_ukeire": row.profile.unseen_count,
                "followup_discard_type": row.followup_discard_type,
                "post_action_risk_score": float(row.features[30]),
                "forced": False,
            }
        )
        self.decision_steps += 1

    def _info(self, *, truncated=False):
        ended = self._game is not None and self._game.state.phase == Phase.FINISHED
        info = {
            "controlled_seat": self.seat,
            "decision_steps": self.decision_steps,
            "raw_decision_steps": self.raw_decision_steps,
            "forced_decision_steps": self.forced_decision_steps,
            "terminal_delivery_steps": self.terminal_delivery_steps,
            "engine_actions": self.engine_actions,
            "fixed_policy": FIXED_POLICY,
            "auto_ready": self.auto_ready,
            "reward_scale": self.reward_scale,
            "terminal_delivery": self._pending_terminal,
            "termination_reason": "decision_limit"
            if truncated
            else self._game.turn.terminal_reason,
            "action_counts": dict(self.action_counts),
            "observation_version": ENV_CONTRACT_VERSION,
            "student_action_counts": dict(self.student_action_counts),
            "student_forced_action_counts": dict(self.student_forced_action_counts),
            "student_automatic_action_counts": dict(self.student_automatic_action_counts),
            "student_committed_meld_counts": dict(
                Counter(
                    meld.kind.value
                    for meld in self._game.state.players[self.seat].melds
                )
            ),
            "student_choice_counts": dict(self.student_choice_counts),
            "student_opportunities": dict(self.student_opportunities),
            "student_multichoice_opportunities": dict(
                self.student_multichoice_opportunities
            ),
            "student_multichoice_choices": dict(self.student_multichoice_choices),
            "student_decisions": deepcopy(self.student_decisions)
            if ended or truncated
            else [],
            "call_counts_scope": "call_counts covers whole table; student_action_counts are submitted engine commands; forced and automatic actions are separated; student_committed_meld_counts are the controlled seat's present melds",
            "call_counts": dict(
                Counter(m.kind.value for p in self._game.state.players for m in p.melds)
            ),
        }
        if ended:
            info["result"] = deepcopy(self._game.player_view(self.seat)["result"])
            info["net_points"] = self._game.state.result.payments[self.seat]
            info["won"] = self.seat in self._game.state.result.winners
            info["deal_in"] = (
                bool(self._game.state.result.winners)
                and self._game.state.result.source_player == self.seat
            )
        return info

    def _fail(self, error, stage):
        self._needs_reset = True
        self._candidates = ()
        self._last_failure = {
            "privacy": "PRIVATE diagnostic only; hidden hands and wall must never become features",
            "stage": stage,
            "exception": {"type": type(error).__name__, "message": str(error)},
            "initial": deepcopy(self._initial),
            "attempted_action": deepcopy(self._attempted_action),
            "rules": self.rules.to_dict(),
            "snapshot": None,
        }
        if self._game is not None:
            try:
                self._last_failure["snapshot"] = json.loads(self._game.to_json())
            except Exception as secondary:  # noqa: BLE001 - retain primary engine failure
                self._last_failure["snapshot_error"] = str(secondary)

    def save_failure(self, path):
        if self._last_failure is None:
            raise ValueError("no recorded failure")
        path = Path(path)
        if path.exists():
            raise FileExistsError(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(self._last_failure, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    def render(self):
        if self.render_mode != "ansi" or self._game is None:
            return None
        return f"seat {self.seat}, phase {self._game.state.phase.value}, live {self._game.live_tiles}; candidates {[r.action.to_dict() for r in self._candidates]}"

    def close(self):
        self._needs_reset = True
