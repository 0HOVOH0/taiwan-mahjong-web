"""青竹十六張：瀏覽器（Pyodide）版後端。

在瀏覽器裡直接執行原本的 game_ui.core / replay / analysis / outcomes，
不改動任何牌局、教師或特徵程式碼。差別只有兩處：
1. 不載入 PyTorch／gymnasium／stable-baselines3：以極小的替身模組滿足 import。
2. BC 模型改用 numpy 計算同一個 actor（actor + public_encoder + context_actor），
   權重由 tools/export_numpy_policy.py 從 artifacts/inference-bc/policy.pt 匯出。
handle() 對應原本 server.py 的每一個 /api/ 路徑，回傳 (HTTP 狀態碼, JSON 字串)。
"""

import hashlib
import json
import sys
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
WEB_FORMAT = "qingzhu-browser-actor-v1"


# ---------------------------------------------------------------- stand-ins
def _install_stubs():
    if "torch" not in sys.modules:
        torch = types.ModuleType("torch")

        class _NoGrad:
            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        torch.no_grad = lambda: _NoGrad()
        torch.set_num_threads = lambda n: None
        torch.__qingzhu_stub__ = True
        sys.modules["torch"] = torch

    if "gymnasium" not in sys.modules:
        gym = types.ModuleType("gymnasium")
        spaces = types.ModuleType("gymnasium.spaces")
        error = types.ModuleType("gymnasium.error")

        class Env:  # only used as a base class at import time
            pass

        class _Space:
            def __init__(self, *args, **kwargs):
                self.args, self.kwargs = args, kwargs

        for name in ("Box", "Discrete", "Dict", "MultiBinary"):
            setattr(spaces, name, type(name, (_Space,), {}))

        class ResetNeeded(Exception):
            pass

        error.ResetNeeded = ResetNeeded
        gym.Env, gym.spaces, gym.error = Env, spaces, error
        sys.modules.update(
            {"gymnasium": gym, "gymnasium.spaces": spaces, "gymnasium.error": error}
        )

    # core.py imports load_checkpoint only for the training-checkpoint fallback.
    if "learning_v42.artifacts" not in sys.modules:
        import learning_v42

        artifacts = types.ModuleType("learning_v42.artifacts")

        def load_checkpoint(*args, **kwargs):
            raise RuntimeError("training checkpoints are not available in the browser build")

        artifacts.load_checkpoint = load_checkpoint
        sys.modules["learning_v42.artifacts"] = artifacts
        learning_v42.artifacts = artifacts


# ---------------------------------------------------------------- numpy actor
class _Array:
    def __init__(self, value):
        self.value = value

    def cpu(self):
        return self

    def numpy(self):
        return self.value


class NumpyCandidatePolicy:
    """Same scoring as learning_v42.policy.CandidatePolicy._parts + masked softmax.

    logits = actor(candidates) + context_actor([candidates, public_encoder(public)])
    probabilities = softmax(where(mask, logits, -1e8))   (MaskableCategorical)
    """

    def __init__(self, weights):
        self.w = {k: np.asarray(v, dtype=np.float32) for k, v in weights.items()}

    def set_training_mode(self, mode):
        return None

    def obs_to_tensor(self, obs):
        return obs, True

    @staticmethod
    def _linear(x, w, b):
        return x @ w.T + b

    def logits(self, obs):
        w = self.w
        candidates = np.asarray(obs["candidates"], dtype=np.float32)
        public = np.concatenate(
            (np.asarray(obs["context"], np.float32), np.asarray(obs["state"], np.float32))
        )
        if not np.isfinite(candidates).all() or not np.isfinite(public).all():
            raise FloatingPointError("nonfinite public observation")
        h = np.tanh(self._linear(candidates, w["actor.0.weight"], w["actor.0.bias"]))
        h = np.tanh(self._linear(h, w["actor.2.weight"], w["actor.2.bias"]))
        own = self._linear(h, w["actor.4.weight"], w["actor.4.bias"])
        e = np.tanh(self._linear(public, w["public_encoder.0.weight"], w["public_encoder.0.bias"]))
        e = np.tanh(self._linear(e, w["public_encoder.2.weight"], w["public_encoder.2.bias"]))
        joined = np.concatenate(
            (candidates, np.broadcast_to(e, (candidates.shape[0], e.shape[0]))), axis=1
        )
        g = np.tanh(self._linear(joined, w["context_actor.0.weight"], w["context_actor.0.bias"]))
        ctx = self._linear(g, w["context_actor.2.weight"], w["context_actor.2.bias"])
        return (own + ctx).reshape(-1).astype(np.float32)

    def get_distribution(self, obs, action_masks=None):
        observed = np.asarray(obs["candidate_mask"]).astype(bool)
        mask = observed if action_masks is None else np.asarray(action_masks).astype(bool).reshape(-1)
        if not mask.any() or (mask & ~observed).any():
            raise ValueError("invalid mask or mask enables absent candidate")
        logits = np.where(mask, self.logits(obs), np.float32(-1e8)).astype(np.float32)
        shifted = logits - logits.max()
        exp = np.exp(shifted, dtype=np.float32)
        probs = (exp / exp.sum(dtype=np.float32)).astype(np.float32)
        return types.SimpleNamespace(distribution=types.SimpleNamespace(probs=_Array(probs)))


def load_numpy_model(root=ROOT):
    folder = Path(root) / "artifacts/inference-bc"
    info = json.loads((folder / "policy_actor.json").read_text(encoding="utf-8"))
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    raw = (folder / "policy_actor.npz").read_bytes()
    if info.get("format") != WEB_FORMAT or hashlib.sha256(raw).hexdigest() != info["npz_sha256"]:
        raise ValueError("browser model file digest/format mismatch")
    if info["source_manifest_sha256"] != manifest["manifest_sha256"]:
        raise ValueError("browser model was exported from a different inference bundle")
    with np.load(folder / "policy_actor.npz") as data:
        weights = {k: data[k] for k in data.files}
    if any(list(weights[k].shape) != v for k, v in info["tensors"].items()):
        raise ValueError("browser model tensor shapes differ")
    return NumpyCandidatePolicy(weights), manifest


# ---------------------------------------------------------------- app state
_install_stubs()
from game_ui.analysis import analyze_hand  # noqa: E402
from game_ui.core import Advisor, Table  # noqa: E402
from game_ui.replay import MAX_BYTES, export_table, validate_replay  # noqa: E402
from game_ui.settlement import build_settlement  # noqa: E402

ADVISOR = None
TABLE = None


def boot():
    """Load rules + numpy model once. Returns a short status dict."""
    global ADVISOR
    if ADVISOR is not None:
        return {"model_loaded": ADVISOR.model is not None, "error": ADVISOR.error}
    advisor = Advisor(ROOT)  # torch path fails cleanly -> rules-teacher fallback
    try:
        policy, manifest = load_numpy_model(ROOT)
        rules_digest = hashlib.sha256(
            json.dumps(
                advisor.rules.to_dict(), ensure_ascii=False, sort_keys=True,
                separators=(",", ":"), allow_nan=False,
            ).encode()
        ).hexdigest()
        if manifest["rules_sha256"] != rules_digest:
            raise ValueError("Model rules differ from game rules")
        advisor.model = types.SimpleNamespace(policy=policy)
        advisor.manifest = manifest
        advisor.error = None
        try:
            from game_ui.outcomes import OutcomeForecast

            advisor.outcome = OutcomeForecast(ROOT, manifest["model_sha256"], manifest["rules_sha256"])
        except (ValueError, KeyError, OSError):
            advisor.outcome = None
    except Exception as error:  # keep the game playable with the rules teacher
        advisor.model = None
        advisor.error = f"{type(error).__name__}: {error}"
    ADVISOR = advisor
    return {"model_loaded": advisor.model is not None, "error": advisor.error}


def _ok(body, status=200):
    return status, json.dumps(body, ensure_ascii=False, allow_nan=False)


def handle(method, path, body_text=None):
    """Mirror of game_ui/server.py routes (single local player, no cookies)."""
    global TABLE
    boot()
    try:
        if method == "GET":
            if path == "/api/health":
                return _ok({"application": "qingzhu-mahjong", "ready": True,
                            "model_loaded": ADVISOR.model is not None, "browser": True})
            if path == "/api/example-replay":
                sample = ROOT / "game_ui/examples/public-replay.json"
                return _ok(validate_replay(json.loads(sample.read_text(encoding="utf-8"))))
            if path == "/api/state":
                return _ok({"state": None if TABLE is None else TABLE.snapshot})
            if path == "/api/forecast":
                snapshot = None if TABLE is None else TABLE.snapshot
                estimate = (ADVISOR.outcome.predict(snapshot)
                            if snapshot is not None and ADVISOR.outcome is not None else None)
                return _ok({"forecast": estimate,
                            "version": None if snapshot is None else snapshot["version"]})
            if path == "/api/settlement":
                return _ok({"settlement": None if TABLE is None else build_settlement(TABLE)})
            if path == "/api/replay" and TABLE is not None:
                return _ok(export_table(TABLE))
            return _ok({"error": "找不到此頁面"}, 404)
        if method == "POST":
            raw = (body_text or "").encode("utf-8")
            limit = MAX_BYTES if path == "/api/import-replay" else 16384
            if not 0 < len(raw) <= limit:
                raise ValueError("請求大小不正確")
            body = json.loads(body_text)
            if not isinstance(body, dict):
                raise ValueError("請求必須是物件")
            if path == "/api/import-replay":
                return _ok(validate_replay(body))
            if path == "/api/analyze-hand":
                return _ok(analyze_hand(body))
            if path == "/api/new":
                TABLE = Table(ADVISOR, seat=body.get("seat", 0))
                return _ok({"state": TABLE.snapshot})
            if path == "/api/action" and TABLE:
                return _ok({"state": TABLE.choose(body.get("version"), body.get("candidate"))})
            return _ok({"error": "牌桌尚未開始"}, 404)
        return _ok({"error": "不支援的請求"}, 405)
    except (ValueError, KeyError, TypeError) as error:
        return _ok({"error": str(error)}, 400)
    except Exception:
        import traceback

        traceback.print_exc()
        return _ok({"error": "牌桌發生錯誤；保留目前局面，請重新整理後再試"}, 500)
