"""批量單局：每個種子只嘗試一次；完整紀錄含暗牌，僅供內部除錯。"""

import argparse
import hashlib
import json
import platform
import random
import time
from dataclasses import asdict
from pathlib import Path

from engine.actions import Action
from engine.game import MahjongGame
from engine.rules import RulesConfig, load_rules, load_rules_data
from engine.scoring import SUPPORTED_PROFILE_VERSIONS, UnsupportedRuleError
from engine.state import Phase, Wind

PRIVACY_NOTICE = (
    "PRIVATE DEBUG DATA: attempt files contain the full wall, all concealed hands "
    "and complete snapshots. Never provide these files to a player policy or public UI. "
    "Policies receive only their own player_view and legal_actions."
)
RECORD_VERSION = 1


class ActionLimitError(RuntimeError):
    """超過動作上限是驗證失敗，不能當成流局。"""


def canonical_json(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def rules_digest(data: dict) -> str:
    return hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()


def rules_from_record(data: dict) -> RulesConfig:
    """重播走與 YAML 相同的 schema 驗證，不能直接信任存檔 dict。"""
    if not isinstance(data, dict):
        raise TypeError("存檔規則必須是物件")
    return load_rules_data(data)


def derive_seed(seed: int, label: str) -> int:
    return int.from_bytes(
        hashlib.sha256(f"mahjong-batch-v1:{seed}:{label}".encode()).digest()[:8],
        "big",
    )


def make_agent(name: str, seed: int, seat: int):
    del seat  # 座位保留在工廠介面，策略本身只讀傳入觀察。
    if name == "random":
        from agents.random_agent import RandomAgent

        return RandomAgent(seed=seed)
    if name == "heuristic":
        from agents.heuristic_agent import HeuristicAgent

        return HeuristicAgent(seed=seed)
    raise ValueError(f"未知策略：{name}")


def _validate_arguments(
    seed, agent_names, dealer, dealer_streak, round_wind, max_actions
):
    if type(seed) is not int:
        raise TypeError("seed 必須是整數")
    if len(agent_names) != 4 or any(
        name not in ("random", "heuristic") for name in agent_names
    ):
        raise ValueError("必須指定四家 random 或 heuristic 策略")
    if type(dealer) is not int or dealer not in range(4):
        raise ValueError("dealer 必須介於0～3")
    if type(dealer_streak) is not int or dealer_streak not in range(10):
        raise ValueError("dealer_streak 必須介於0～9")
    if not isinstance(round_wind, Wind):
        raise TypeError("round_wind 必須是 Wind")
    if type(max_actions) is not int or max_actions < 1:
        raise ValueError("max_actions 必須是正整數")


def _exception(exc: Exception) -> dict:
    return {"type": type(exc).__name__, "message": str(exc)}


def _snapshot(game: MahjongGame | None) -> dict | None:
    return json.loads(game.to_json()) if game is not None else None


def run_hand(
    *,
    seed: int,
    agent_names=("random", "random", "random", "random"),
    rules: RulesConfig | None = None,
    dealer: int = 0,
    dealer_streak: int = 0,
    round_wind: Wind = Wind.EAST,
    max_actions: int = 1200,
    wall_order: list[int] | None = None,
    agent_factory=None,
) -> dict:
    """完整私有 attempt；支援/未支援/錯誤皆回傳一筆，不重新抽牌。"""
    agent_names = tuple(agent_names)
    _validate_arguments(
        seed, agent_names, dealer, dealer_streak, round_wind, max_actions
    )
    source_rules = load_rules() if rules is None else rules
    rule_data = source_rules.to_dict()
    shuffle_seed = derive_seed(seed, "shuffle")
    policy_seeds = [derive_seed(seed, f"policy:{seat}") for seat in range(4)]
    wall = list(range(144)) if wall_order is None else list(wall_order)
    if wall_order is None:
        random.Random(shuffle_seed).shuffle(wall)
    record = {
        "record_version": RECORD_VERSION,
        "privacy": PRIVACY_NOTICE,
        "seed": seed,
        "shuffle_seed": shuffle_seed,
        "wall_source": "seeded_shuffle" if wall_order is None else "provided",
        "rng": {
            "algorithm": "python.random.Random",
            "python_version": platform.python_version(),
        },
        "policies": [
            {"seat": seat, "name": name, "seed": policy_seeds[seat]}
            for seat, name in enumerate(agent_names)
        ],
        "policy_factory": "builtin"
        if agent_factory is None
        else f"{agent_factory.__module__}.{getattr(agent_factory, '__qualname__', type(agent_factory).__qualname__)}",
        "rules": rule_data,
        "rules_sha256": rules_digest(rule_data),
        "initial": {
            "wall_order": wall,
            "dealer": dealer,
            "dealer_streak": dealer_streak,
            "round_wind": round_wind.value,
        },
        "max_actions": max_actions,
        "actions": [],
        "status": "error",
        "terminal_reason": None,
        "result": None,
        "final_snapshot": None,
        "failure": None,
        "elapsed_seconds": 0.0,
    }
    game = None
    stage = "rules"
    attempted = None
    started = time.perf_counter()
    try:
        checked_rules = rules_from_record(rule_data)
        stage = "initialization"
        if (
            checked_rules.version not in SUPPORTED_PROFILE_VERSIONS
            or checked_rules.pending_fields
        ):
            raise UnsupportedRuleError(
                "回合引擎僅接受目前明確子集，其他版本或待確認設定尚未支援"
            )
        game = MahjongGame(
            wall_order=wall.copy(),
            dealer=dealer,
            dealer_streak=dealer_streak,
            round_wind=round_wind,
            rules=checked_rules,
        )
        stage = "policy_initialization"
        factory = make_agent if agent_factory is None else agent_factory
        policies = [
            factory(name, policy_seeds[seat], seat)
            for seat, name in enumerate(agent_names)
        ]
        for metadata, policy in zip(record["policies"], policies, strict=True):
            metadata["implementation"] = (
                f"{type(policy).__module__}.{type(policy).__qualname__}"
            )
        while game.state.phase != Phase.FINISHED:
            stage = "action_limit"
            if len(record["actions"]) >= max_actions:
                raise ActionLimitError(f"單局超過 {max_actions} 個動作")
            player = game.waiting_players[0]
            stage = "observation"
            # 沒有把 game、state、turn、wall 或歷史私有快照交給策略。
            observation = game.player_view(player)
            legal = tuple(Action.from_dict(a) for a in observation["legal_actions"])
            stage = "policy"
            chosen = policies[player].act(observation, legal)
            if not isinstance(chosen, Action):
                raise TypeError("策略必須回傳 Action")
            attempted = {"player": player, "action": chosen.to_dict()}
            stage = "apply"
            game.apply(player, chosen)
            record["actions"].append(attempted)
            attempted = None
        stage = "final_validation"
        game.validate()
        record.update(
            status="completed",
            terminal_reason=game.turn.terminal_reason,
            result=asdict(game.state.result),
            final_snapshot=_snapshot(game),
        )
    except Exception as exc:  # noqa: BLE001 -- 一局故障必須保存並繼續後續種子。
        record["status"] = (
            "unsupported" if isinstance(exc, UnsupportedRuleError) else "error"
        )
        # apply 是交易式操作，失敗後快照應與失敗前完全相同。
        # to_json 自帶 validate；如果 validate 本身失敗，保留快照失敗原因。
        try:
            before_failure = _snapshot(game)
            snapshot_error = None
        except Exception as snapshot_exc:  # noqa: BLE001 -- 保留快照本身的失敗證據。
            before_failure = None
            snapshot_error = _exception(snapshot_exc)
        record["failure"] = {
            "stage": stage,
            "exception": _exception(exc),
            "attempted_action": attempted,
            "before_failure_snapshot": before_failure,
            "snapshot_error": snapshot_error,
        }
    record["elapsed_seconds"] = time.perf_counter() - started
    return record


def summarize(records: list[dict], *, elapsed_seconds: float) -> dict:
    """分數與勝負分母一律只使用正常完成局，不把未支援當流局。"""
    counts = {
        name: sum(r["status"] == name for r in records)
        for name in ("completed", "unsupported", "error")
    }
    completed = [r for r in records if r["status"] == "completed"]
    denominator = len(completed)
    reason_counts = {
        reason: sum(r["terminal_reason"] == reason for r in completed)
        for reason in ("self_draw", "discard", "rob_added_kong", "wall_exhausted")
    }
    seats = []
    for seat in range(4):
        wins = sum(seat in r["result"]["winners"] for r in completed)
        discard_losses = sum(
            r["terminal_reason"] == "discard" and r["result"]["source_player"] == seat
            for r in completed
        )
        rob_losses = sum(
            r["terminal_reason"] == "rob_added_kong"
            and r["result"]["source_player"] == seat
            for r in completed
        )
        net = sum(r["result"]["payments"][seat] for r in completed)
        seats.append(
            {
                "seat": seat,
                "wins": wins,
                "win_rate_completed": wins / denominator if denominator else None,
                "discard_losses": discard_losses,
                "discard_loss_rate_completed": discard_losses / denominator
                if denominator
                else None,
                "rob_added_kong_losses": rob_losses,
                "wall_draws": reason_counts["wall_exhausted"],
                "net_points": net,
                "mean_net_points_completed": net / denominator if denominator else None,
            }
        )
    actions = sum(r.get("action_count", len(r.get("actions", []))) for r in records)
    return {
        "summary_version": 1,
        "privacy": PRIVACY_NOTICE,
        "attempts": len(records),
        "counts": counts,
        "statistics_denominator": {
            "name": "completed_hands_only",
            "hands": denominator,
        },
        "terminal_reasons_completed": reason_counts,
        "wall_draw_rate_completed": reason_counts["wall_exhausted"] / denominator
        if denominator
        else None,
        "seats": seats,
        "elapsed_seconds": elapsed_seconds,
        "total_applied_actions": actions,
        "attempts_per_second": len(records) / elapsed_seconds
        if elapsed_seconds
        else None,
        "actions_per_second": actions / elapsed_seconds if elapsed_seconds else None,
        "validation_passed": bool(completed) and len(completed) == len(records),
        "supported_validation_passed": bool(completed) and counts["error"] == 0,
        "validation_scope": "all_attempts_must_be_supported_and_completed; no_unsupported_or_errors",
        "supported_validation_scope": "supported_completed_hands_only; unsupported attempts remain unvalidated",
        "all_attempts_supported_and_completed": len(completed) == len(records),
        "all_attempts_completed": len(completed) == len(records),
        "exit_code": int(counts["error"] > 0),
    }


def run_batch(
    *,
    games: int,
    seed: int = 0,
    agent_names=("random", "random", "random", "random"),
    rules: RulesConfig | None = None,
    output: str | Path | None = None,
    max_actions: int = 1200,
    agent_factory=None,
    progress=None,
) -> dict:
    """連續種子 seed..seed+games-1，各試一次；輸出路徑不可覆蓋舊紀錄。"""
    if type(games) is not int or games < 1:
        raise ValueError("games 必須是正整數")
    agent_names = tuple(agent_names)
    _validate_arguments(seed, agent_names, 0, 0, Wind.EAST, max_actions)
    effective_rules = load_rules() if rules is None else rules
    root = Path(output) if output is not None else None
    if root is not None:
        if (root / "summary.json").exists() or (root / "attempts").exists():
            raise FileExistsError("輸出目錄已有批次紀錄，請使用新的 output 路徑")
        (root / "attempts").mkdir(parents=True)
        (root / "PRIVACY.txt").write_text(PRIVACY_NOTICE + "\n", encoding="utf-8")
    records = []
    record_refs = []
    started = time.perf_counter()
    for index in range(games):
        attempt = run_hand(
            seed=seed + index,
            agent_names=agent_names,
            rules=effective_rules,
            dealer=index % 4,
            max_actions=max_actions,
            agent_factory=agent_factory,
        )
        # 摘要只保留統計所需欄位；萬局評估不把所有完整快照留在記憶體。
        records.append(
            {
                "status": attempt["status"],
                "terminal_reason": attempt["terminal_reason"],
                "result": attempt["result"],
                "action_count": len(attempt["actions"]),
            }
        )
        filename = f"attempts/{index:06d}-seed-{seed + index}.json"
        if root is not None:
            (root / filename).write_text(
                json.dumps(attempt, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        record_refs.append(
            {
                "index": index,
                "seed": attempt["seed"],
                "status": attempt["status"],
                "record_file": filename if root is not None else None,
                "actions": len(attempt["actions"]),
                "elapsed_seconds": attempt["elapsed_seconds"],
                "failure": None
                if attempt["failure"] is None
                else {
                    "stage": attempt["failure"]["stage"],
                    "exception": attempt["failure"]["exception"],
                },
            }
        )
        if progress is not None:
            progress(index + 1, games, attempt["status"])
    summary = summarize(records, elapsed_seconds=time.perf_counter() - started)
    summary["agents"] = list(agent_names)
    summary["rules_sha256"] = rules_digest(effective_rules.to_dict())
    summary["seed_start"] = seed
    summary["records"] = record_refs
    if root is not None:
        (root / "summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--games", type=int, default=100)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--agents", default="random,random,random,random")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rules", type=Path)
    parser.add_argument("--max-actions", type=int, default=1200)
    args = parser.parse_args()
    summary = run_batch(
        games=args.games,
        seed=args.seed,
        agent_names=tuple(args.agents.split(",")),
        output=args.output,
        rules=load_rules(args.rules) if args.rules else None,
        max_actions=args.max_actions,
        progress=lambda done, total, status: print(
            f"{done}/{total}: {status}", flush=True
        ),
    )
    print(
        json.dumps(
            {
                key: summary[key]
                for key in (
                    "counts",
                    "statistics_denominator",
                    "elapsed_seconds",
                    "validation_passed",
                    "validation_scope",
                )
            },
            ensure_ascii=False,
        )
    )
    print(f"紀錄含所有暗牌與牌牆，限內部使用：{args.output}")
    raise SystemExit(summary["exit_code"])


if __name__ == "__main__":
    main()
