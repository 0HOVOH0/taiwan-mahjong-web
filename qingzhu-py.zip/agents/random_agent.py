"""可重現的隨機基準：有胡就胡，其餘合法動作均勻抽選。"""

import random
from collections.abc import Sequence

from agents.base import check_seed, checked_actions
from engine.actions import Action, ActionKind


class RandomAgent:
    def __init__(self, seed: int = 0) -> None:
        check_seed(seed)
        self.rng = random.Random(seed)

    def act(self, observation: dict, legal_actions: Sequence[Action]) -> Action:
        actions = checked_actions(legal_actions)
        win = next(
            (action for action in actions if action.kind == ActionKind.WIN), None
        )
        return win if win is not None else self.rng.choice(actions)
