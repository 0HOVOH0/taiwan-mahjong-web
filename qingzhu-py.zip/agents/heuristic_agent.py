"""五面子一對的牌效率基準；沒有防守、台數預測或最優策略保證。"""

from collections.abc import Sequence
from dataclasses import dataclass

from agents.base import check_seed, checked_actions
from engine.actions import Action, ActionKind
from engine.shanten import calculate_shanten, find_effective_tiles
from engine.tiles import Tile


@dataclass(frozen=True)
class DiscardAnalysis:
    type_id: int
    tile_id: int
    shanten: int
    effective_types: tuple[int, ...]
    unseen_count: int
    action: Action

    def to_dict(self) -> dict:
        return {
            "type_id": self.type_id,
            "tile_id": self.tile_id,
            "shanten": self.shanten,
            "effective_types": list(self.effective_types),
            "unseen_count": self.unseen_count,
            "action": self.action.to_dict(),
        }


def _own_player(observation: dict) -> dict:
    viewer = observation["viewer"]
    if type(viewer) is not int or viewer not in range(4):
        raise ValueError("玩家視圖的 viewer 必須是 0～3")
    players = observation["players"]
    if len(players) != 4 or {player["seat"] for player in players} != set(range(4)):
        raise ValueError("玩家視圖必須包含四個不同座位")
    own = next(player for player in players if player["seat"] == viewer)
    if not isinstance(own["hand"], list):
        raise TypeError("自己的手牌必須是可見清單")
    return own


def visible_counts34(observation: dict) -> tuple[int, ...]:
    """計入自己手牌與公開實體牌；同一棄牌／反應目標只計一次。

    對手暗手即使被錯加到輸入內也不讀取；暗槓僅計可見的 tile_ids。
    加槓第四張在等待搶槓時仍留在對手暗手，但 reaction 已公開該張。
    """
    own = _own_player(observation)
    physical_ids = set(own["hand"])
    for player in observation["players"]:
        physical_ids.update(player["river"])
        for meld in player["melds"]:
            if meld["tile_ids"] is not None:
                physical_ids.update(meld["tile_ids"])
    for reference in (observation.get("last_discard"), observation.get("reaction")):
        if reference is not None:
            physical_ids.add(reference["tile_id"])
    counts = [0] * 34
    for physical_id in physical_ids:
        tile = Tile(physical_id)
        if tile.is_flower:
            raise ValueError("已知非花牌區不應包含花牌")
        counts[tile.type_id] += 1
    return tuple(counts)


def _discard_candidates(observation: dict, legal_actions: Sequence[Action]):
    own = _own_player(observation)
    counts = [0] * 34
    for physical_id in own["hand"]:
        tile = Tile(physical_id)
        if tile.is_flower:
            raise ValueError("暗手不應包含花牌")
        counts[tile.type_id] += 1
    if len(set(own["hand"])) != len(own["hand"]) or max(counts) > 4:
        raise ValueError("自己的手牌有重複實體牌或超過四張同牌型")
    chosen: dict[int, Action] = {}
    for action in legal_actions:
        if action.kind not in (ActionKind.DISCARD, ActionKind.DECLARE_READY):
            continue
        tile_id = action.tile_ids[0]
        if tile_id not in own["hand"]:
            raise ValueError("合法棄牌必須在自己的手牌內")
        kind = Tile(tile_id).type_id
        old = chosen.get(kind)
        # 相同牌型先固定使用最小實體 ID；同張可宣告時優先宣告聽牌。
        key = (tile_id, action.kind != ActionKind.DECLARE_READY)
        if old is None or key < (
            old.tile_ids[0],
            old.kind != ActionKind.DECLARE_READY,
        ):
            chosen[kind] = action
    fixed_count = len(own["melds"])
    candidates = []
    for kind, action in sorted(chosen.items()):
        after = list(counts)
        after[kind] -= 1
        candidates.append((kind, action, after, fixed_count))
    return candidates


def analyze_discards(
    observation: dict, legal_actions: Sequence[Action]
) -> tuple[DiscardAnalysis, ...]:
    """每個合法可打牌型一筆；按向聽、未見進張數、牌型／實體 ID 排序。

    未見數為 4 減去所有已知同型牌，包含自己即將丟出的那張。
    這是未見牌張數，包含未知對手暗手與保留牌，並非保證可摸到的牌。
    """
    actions = checked_actions(legal_actions)
    known = visible_counts34(observation)
    results = []
    for kind, action, after, fixed_count in _discard_candidates(observation, actions):
        effective = find_effective_tiles(
            after, fixed_meld_count=fixed_count, visible_counts34=known
        )
        results.append(
            DiscardAnalysis(
                type_id=kind,
                tile_id=action.tile_ids[0],
                shanten=calculate_shanten(after, fixed_meld_count=fixed_count),
                effective_types=effective,
                unseen_count=sum(4 - known[tile_type] for tile_type in effective),
                action=action,
            )
        )
    return tuple(
        sorted(
            results,
            key=lambda result: (
                result.shanten,
                -result.unseen_count,
                result.type_id,
                result.tile_id,
            ),
        )
    )


class HeuristicAgent:
    """有胡就胡，摸牌時摸牌；出牌選向聽最少、未見進張最多。

    反應一律過，不主動吃碰槓；有相同棄牌可宣告時宣告聽牌。
    因此這是保守且可解釋的牌效率比較基準，不評估防守或收益。
    seed 僅為與隨機基準的建構介面一致，並列完全固定而不抽亂數。
    """

    def __init__(self, seed: int = 0) -> None:
        check_seed(seed)

    def act(self, observation: dict, legal_actions: Sequence[Action]) -> Action:
        actions = checked_actions(legal_actions)
        for kind in (ActionKind.WIN, ActionKind.DRAW):
            action = next((action for action in actions if action.kind == kind), None)
            if action is not None:
                return action
        if any(
            action.kind in (ActionKind.DISCARD, ActionKind.DECLARE_READY)
            for action in actions
        ):
            return analyze_discards(observation, actions)[0].action
        passed = next(
            (action for action in actions if action.kind == ActionKind.PASS), None
        )
        if passed is not None:
            return passed
        raise ValueError("目前沒有基準策略支援的合法選擇")
