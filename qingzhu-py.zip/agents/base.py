"""策略只接收自己的公開視圖與引擎已裁決的合法動作。"""

from collections.abc import Sequence
from typing import Protocol

from engine.actions import Action


class Agent(Protocol):
    def act(self, observation: dict, legal_actions: Sequence[Action]) -> Action:
        """選擇一個傳入的合法動作；不接收完整牌局物件。"""
        ...


def checked_actions(legal_actions: Sequence[Action]) -> tuple[Action, ...]:
    actions = tuple(legal_actions)
    if not actions:
        raise ValueError("此玩家目前沒有合法動作")
    if any(not isinstance(action, Action) for action in actions):
        raise TypeError("合法動作必須是 Action")
    return actions


def check_seed(seed: int) -> None:
    if type(seed) is not int:
        raise TypeError("策略 seed 必須是整數")
