"""牌局資料、位置守恆及快照；回合合法性由後續 game/actions 模組負責。"""

import json
from collections import Counter
from copy import deepcopy
from dataclasses import asdict, dataclass, field, fields
from enum import Enum
from typing import Any

from engine_v4.tiles import TOTAL_TILE_COUNT, Tile

STATE_SCHEMA_VERSION = 1


class StateValidationError(ValueError):
    """狀態格式、牌的位置或參照不一致。"""


class Wind(str, Enum):
    EAST = "east"
    SOUTH = "south"
    WEST = "west"
    NORTH = "north"


class Phase(str, Enum):
    SETUP = "setup"
    DEALING = "dealing"
    DRAW = "draw"
    DISCARD = "discard"
    REACTION = "reaction"
    SETTLEMENT = "settlement"
    FINISHED = "finished"


class MeldKind(str, Enum):
    CHI = "chi"
    PONG = "pong"
    EXPOSED_KONG = "exposed_kong"
    CONCEALED_KONG = "concealed_kong"
    ADDED_KONG = "added_kong"


class ClaimKind(str, Enum):
    CHI = "chi"
    PONG = "pong"
    KONG = "kong"
    WIN = "win"
    PASS = "pass"


class EventKind(str, Enum):
    DRAW = "draw"
    FLOWER = "flower"
    DISCARD = "discard"
    MELD = "meld"
    WIN = "win"
    SETTLEMENT = "settlement"
    READY = "ready"


def _integer(value: int, minimum: int, maximum: int, label: str) -> None:
    if type(value) is not int or not minimum <= value <= maximum:
        raise StateValidationError(f"{label} 必須是 {minimum}～{maximum} 的整數")


def _tile_id(value: int) -> None:
    _integer(value, 0, TOTAL_TILE_COUNT - 1, "實體牌 ID")


def _seat(value: int) -> None:
    _integer(value, 0, 3, "玩家座位")


@dataclass
class WallState:
    # 完整原始牌序是歷史參照；只有 [draw_index:supplement_index] 屬於剩餘牌牆。
    tile_ids: list[int] = field(default_factory=lambda: list(range(TOTAL_TILE_COUNT)))
    draw_index: int = 0
    supplement_index: int = TOTAL_TILE_COUNT  # 不包含此位置

    @property
    def remaining_ids(self) -> list[int]:
        return self.tile_ids[self.draw_index : self.supplement_index]

    @property
    def remaining_count(self) -> int:
        return self.supplement_index - self.draw_index


@dataclass
class Meld:
    kind: MeldKind
    tile_ids: list[int]
    source_player: int | None = None
    claimed_tile_id: int | None = None


@dataclass
class PlayerState:
    seat: int
    seat_wind: Wind
    hand: list[int] = field(default_factory=list)
    melds: list[Meld] = field(default_factory=list)
    flowers: list[int] = field(default_factory=list)
    river: list[int] = field(default_factory=list)

    def counts34(self) -> list[int]:
        counts = [0] * 34
        for tile_id in self.hand:
            tile = Tile(tile_id)
            if tile.is_flower:
                raise StateValidationError("花牌應記在 flowers，不可留在 hand")
            counts[tile.type_id] += 1
        return counts


@dataclass
class DiscardRecord:
    tile_id: int
    player: int


@dataclass
class PendingClaim:
    player: int
    kind: ClaimKind
    hand_tile_ids: list[int] = field(default_factory=list)


@dataclass
class Event:
    # 事件內的牌 ID 是歷史參照，不是牌的目前位置；此紀錄限引擎／除錯使用。
    kind: EventKind
    player: int
    tile_ids: list[int] = field(default_factory=list)


@dataclass
class RoundResult:
    winners: list[int] = field(default_factory=list)
    source_player: int | None = None  # 自摸／流局為 None
    tai: list[int] = field(default_factory=lambda: [0] * 4)
    patterns: list[list[str]] = field(default_factory=lambda: [[] for _ in range(4)])
    payments: list[int] = field(default_factory=lambda: [0] * 4)


def validate_meld(meld: Meld, owner: int) -> None:
    """共用的固定面子結構驗證；不判斷成立時機與吃牌來源限制。"""
    if not isinstance(meld, Meld):
        raise TypeError("meld 必須是 Meld")
    _seat(owner)
    if not isinstance(meld.kind, MeldKind):
        raise StateValidationError("副露種類無效")
    expected_size = 3 if meld.kind in (MeldKind.CHI, MeldKind.PONG) else 4
    if len(meld.tile_ids) != expected_size:
        raise StateValidationError("吃碰應有三張，槓應有四張")
    for tile_id in meld.tile_ids:
        _tile_id(tile_id)
    if len(set(meld.tile_ids)) != len(meld.tile_ids):
        raise StateValidationError("副露不可重複引用同一張實體牌")
    types = sorted(Tile(tile_id).type_id for tile_id in meld.tile_ids)
    if types[-1] >= 34:
        raise StateValidationError("花牌不可放入副露")
    if meld.kind == MeldKind.CHI:
        if types[-1] >= 27 or types[0] // 9 != types[-1] // 9:
            raise StateValidationError("順子不可用字牌或跨花色")
        if types != list(range(types[0], types[0] + 3)):
            raise StateValidationError("順子必須是連續三種牌")
    elif len(set(types)) != 1:
        raise StateValidationError("碰槓必須使用相同牌型")
    if meld.kind == MeldKind.CONCEALED_KONG:
        if meld.source_player is not None or meld.claimed_tile_id is not None:
            raise StateValidationError("暗槓不可有他家來源牌")
    else:
        _seat(meld.source_player)
        _tile_id(meld.claimed_tile_id)
        if meld.source_player == owner or meld.claimed_tile_id not in meld.tile_ids:
            raise StateValidationError("副露的來源玩家或取得的牌不符")


@dataclass
class GameState:
    rules_version: str
    players: list[PlayerState]
    wall: WallState = field(default_factory=WallState)
    dealer: int = 0
    current_player: int = 0
    round_wind: Wind = Wind.EAST
    dealer_streak: int = 0
    phase: Phase = Phase.SETUP
    last_discard: DiscardRecord | None = None
    pending_claims: list[PendingClaim] = field(default_factory=list)
    events: list[Event] = field(default_factory=list)
    result: RoundResult | None = None
    schema_version: int = STATE_SCHEMA_VERSION

    def validate(self) -> None:
        """檢查結構與 144 張位置守恆；不宣稱已驗證摸打、胡牌或台數規則。"""
        if (
            type(self.schema_version) is not int
            or self.schema_version != STATE_SCHEMA_VERSION
        ):
            raise StateValidationError("不支援的牌局 schema_version")
        if not isinstance(self.rules_version, str) or not self.rules_version.strip():
            raise StateValidationError("rules_version 不可空白")
        _seat(self.dealer)
        _seat(self.current_player)
        _integer(self.dealer_streak, 0, 10**9, "連莊次數")
        if not isinstance(self.phase, Phase) or not isinstance(self.round_wind, Wind):
            raise StateValidationError("階段或圈風無效")
        if len(self.players) != 4 or [p.seat for p in self.players] != list(range(4)):
            raise StateValidationError("players 必須依序保存座位 0～3")
        if any(not isinstance(p.seat_wind, Wind) for p in self.players):
            raise StateValidationError("玩家風位無效")
        if len({p.seat_wind for p in self.players}) != 4:
            raise StateValidationError("四家風位不可重複")

        for tile_id in self.wall.tile_ids:
            _tile_id(tile_id)
        if Counter(self.wall.tile_ids) != Counter(range(TOTAL_TILE_COUNT)):
            raise StateValidationError("原始牌牆必須恰好包含 0～143 各一次")
        _integer(self.wall.draw_index, 0, TOTAL_TILE_COUNT, "摸牌指標")
        _integer(
            self.wall.supplement_index,
            self.wall.draw_index,
            TOTAL_TILE_COUNT,
            "補牌指標",
        )
        locations = list(self.wall.remaining_ids)
        for player in self.players:
            _seat(player.seat)
            for tile_id in player.hand + player.river:
                _tile_id(tile_id)
                if Tile(tile_id).is_flower:
                    raise StateValidationError("花牌不可留在暗手牌或牌河")
            for tile_id in player.flowers:
                _tile_id(tile_id)
                if not Tile(tile_id).is_flower:
                    raise StateValidationError("flowers 只能存放花牌")
            locations.extend(player.hand + player.flowers + player.river)
            if len(player.melds) > 5:
                raise StateValidationError("副露不可超過五組")
            for meld in player.melds:
                validate_meld(meld, player.seat)
                locations.extend(meld.tile_ids)
        counts = Counter(locations)
        missing = sorted(set(range(TOTAL_TILE_COUNT)) - counts.keys())
        repeated = sorted(tile_id for tile_id, count in counts.items() if count > 1)
        if missing or repeated or len(locations) != TOTAL_TILE_COUNT:
            raise StateValidationError(
                f"牌的位置不守恆：遺失 {missing}，重複 {repeated}"
            )

        if self.last_discard is not None:
            _seat(self.last_discard.player)
            _tile_id(self.last_discard.tile_id)
            tile_id = self.last_discard.tile_id
            in_river = tile_id in self.players[self.last_discard.player].river
            in_meld = any(
                m.claimed_tile_id == tile_id
                and m.source_player == self.last_discard.player
                for p in self.players
                for m in p.melds
            )
            if not in_river and not in_meld:
                raise StateValidationError("最近棄牌應位於來源牌河或已取得它的副露")
        for event in self.events:
            if not isinstance(event.kind, EventKind):
                raise StateValidationError("事件種類無效")
            _seat(event.player)
            for tile_id in event.tile_ids:
                _tile_id(tile_id)
        if self.pending_claims and (
            self.phase != Phase.REACTION or self.last_discard is None
        ):
            raise StateValidationError("棄牌主張只能出現在有最近棄牌的等待反應階段")
        for claim in self.pending_claims:
            _seat(claim.player)
            if not isinstance(claim.kind, ClaimKind):
                raise StateValidationError("主張種類無效")
            if claim.player == self.last_discard.player:
                raise StateValidationError("不可對自己的棄牌主張")
            if len(set(claim.hand_tile_ids)) != len(claim.hand_tile_ids):
                raise StateValidationError("主張使用的手牌不可重複")
            for tile_id in claim.hand_tile_ids:
                _tile_id(tile_id)
                if tile_id not in self.players[claim.player].hand:
                    raise StateValidationError("主張引用了不在自己手中的牌")
        self._validate_result()

    def _validate_result(self) -> None:
        if self.result is None:
            if self.phase == Phase.FINISHED:
                raise StateValidationError("結束牌局必須包含結算結果")
            return
        if self.phase not in (Phase.SETTLEMENT, Phase.FINISHED):
            raise StateValidationError("結算結果只能出現在結算或結束階段")
        result = self.result
        for winner in result.winners:
            _seat(winner)
        if len(set(result.winners)) != len(result.winners):
            raise StateValidationError("胡牌玩家不可重複")
        if result.source_player is not None:
            _seat(result.source_player)
            if not result.winners or result.source_player in result.winners:
                raise StateValidationError("放槍來源不符")
        if (
            len(result.tai) != 4
            or len(result.patterns) != 4
            or len(result.payments) != 4
        ):
            raise StateValidationError("台數、台型與支付必須各記錄四位玩家")
        for tai in result.tai:
            _integer(tai, 0, 10**9, "台數")
        if any(
            not isinstance(patterns, list)
            or any(not isinstance(p, str) for p in patterns)
            for patterns in result.patterns
        ):
            raise StateValidationError("台型必須是字串清單")
        if any(type(payment) is not int for payment in result.payments):
            raise StateValidationError("支付必須是整數")
        if sum(result.payments) != 0:
            raise StateValidationError("四家支付加總必須為零")

    def move_wall_tile(self, player: int, *, from_back: bool = False) -> int:
        """低階資料搬移，花牌直接記入 flowers；不自動補牌、發牌或切換階段。"""
        self.validate()
        _seat(player)
        if type(from_back) is not bool:
            raise StateValidationError("from_back 必須是布林值")
        if self.phase in (Phase.SETTLEMENT, Phase.FINISHED) or self.pending_claims:
            raise StateValidationError("結算或待裁決時不可搬移牌牆牌")
        if not self.wall.remaining_count:
            raise StateValidationError("牌牆已空")
        if from_back:
            self.wall.supplement_index -= 1
            tile_id = self.wall.tile_ids[self.wall.supplement_index]
        else:
            tile_id = self.wall.tile_ids[self.wall.draw_index]
            self.wall.draw_index += 1
        tile = Tile(tile_id)
        target = (
            self.players[player].flowers
            if tile.is_flower
            else self.players[player].hand
        )
        target.append(tile_id)
        self.events.append(
            Event(
                EventKind.FLOWER if tile.is_flower else EventKind.DRAW,
                player,
                [tile_id],
            )
        )
        self.validate()
        return tile_id

    def move_hand_tile_to_river(self, player: int, tile_id: int) -> None:
        """低階資料搬移，不裁決是否輪到該玩家出牌；後續 game 層負責合法性。"""
        self.validate()
        _seat(player)
        _tile_id(tile_id)
        if self.phase in (Phase.SETTLEMENT, Phase.FINISHED) or self.pending_claims:
            raise StateValidationError("結算或待裁決時不可搬移手牌")
        if tile_id not in self.players[player].hand:
            raise StateValidationError("這張牌不在玩家暗手牌中")
        self.players[player].hand.remove(tile_id)
        self.players[player].river.append(tile_id)
        self.last_discard = DiscardRecord(tile_id, player)
        self.events.append(Event(EventKind.DISCARD, player, [tile_id]))
        self.validate()

    def to_dict(self) -> dict[str, Any]:
        """完整內部快照，包含所有暗牌與原始牌牆，禁止當作玩家觀測。"""
        self.validate()
        return json.loads(json.dumps(asdict(self), ensure_ascii=False))

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GameState":
        try:
            if not isinstance(data, dict) or set(data) != {f.name for f in fields(cls)}:
                raise StateValidationError("完整快照欄位不符 schema_version 1")
            players = []
            for player in data["players"]:
                melds = [
                    Meld(**{**meld, "kind": MeldKind(meld["kind"])})
                    for meld in player["melds"]
                ]
                players.append(
                    PlayerState(
                        **{
                            **player,
                            "seat_wind": Wind(player["seat_wind"]),
                            "melds": melds,
                        }
                    )
                )
            claims = [
                PendingClaim(**{**claim, "kind": ClaimKind(claim["kind"])})
                for claim in data["pending_claims"]
            ]
            events = [
                Event(**{**event, "kind": EventKind(event["kind"])})
                for event in data["events"]
            ]
            state = cls(
                **{
                    **data,
                    "players": players,
                    "wall": WallState(**data["wall"]),
                    "round_wind": Wind(data["round_wind"]),
                    "phase": Phase(data["phase"]),
                    "last_discard": DiscardRecord(**data["last_discard"])
                    if data["last_discard"] is not None
                    else None,
                    "pending_claims": claims,
                    "events": events,
                    "result": RoundResult(**data["result"])
                    if data["result"] is not None
                    else None,
                }
            )
            state.validate()
            # 呼叫端再修改原始 dict 不可影響還原後的狀態。
            return deepcopy(state)
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            raise StateValidationError(f"無法還原牌局：{error}") from error

    @classmethod
    def from_json(cls, text: str) -> "GameState":
        try:
            data = json.loads(text)
        except (TypeError, ValueError) as error:
            raise StateValidationError("牌局 JSON 格式錯誤") from error
        return cls.from_dict(data)

    def to_player_view(self, viewer: int) -> dict[str, Any]:
        """桌面串接用的安全快照 v1；尚不是完整的 AI observation encoder。"""
        self.validate()
        _seat(viewer)
        players = []
        for player in self.players:
            melds = []
            for meld in player.melds:
                visible = player.seat == viewer or meld.kind != MeldKind.CONCEALED_KONG
                melds.append(
                    {
                        "kind": meld.kind.value,
                        "tile_count": len(meld.tile_ids),
                        "tile_ids": list(meld.tile_ids) if visible else None,
                        "source_player": meld.source_player,
                    }
                )
            players.append(
                {
                    "seat": player.seat,
                    "seat_wind": player.seat_wind.value,
                    "hand": list(player.hand) if player.seat == viewer else None,
                    "hand_count": len(player.hand),
                    "melds": melds,
                    "flowers": list(player.flowers),
                    "river": list(player.river),
                }
            )
        return {
            "schema_version": STATE_SCHEMA_VERSION,
            "rules_version": self.rules_version,
            "viewer": viewer,
            "dealer": self.dealer,
            "current_player": self.current_player,
            "round_wind": self.round_wind.value,
            "dealer_streak": self.dealer_streak,
            "phase": self.phase.value,
            "remaining_tiles": self.wall.remaining_count,
            "players": players,
            "counts34": self.players[viewer].counts34(),
            "last_discard": asdict(self.last_discard)
            if self.last_discard is not None
            else None,
        }


def new_game_state(
    rules_version: str, *, dealer: int = 0, wall_order: list[int] | None = None
) -> GameState:
    """建立發牌前狀態；接受指定牌序，不在此處選桌規或使用全域亂數。"""
    _seat(dealer)
    winds = list(Wind)
    state = GameState(
        rules_version=rules_version,
        players=[PlayerState(seat, winds[(seat - dealer) % 4]) for seat in range(4)],
        wall=WallState(
            list(wall_order)
            if wall_order is not None
            else list(range(TOTAL_TILE_COUNT))
        ),
        dealer=dealer,
        current_player=dealer,
    )
    state.validate()
    return state
