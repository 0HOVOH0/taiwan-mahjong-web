"""牌桌／策略共用的明確動作；合法性由 MahjongGame.legal_actions 裁決。"""

from dataclasses import dataclass
from enum import Enum

from engine_v4.tiles import Tile


class ActionKind(str, Enum):
    DRAW = "draw"
    DISCARD = "discard"
    PASS = "pass"
    WIN = "win"
    CHI = "chi"
    PONG = "pong"
    EXPOSED_KONG = "exposed_kong"
    CONCEALED_KONG = "concealed_kong"
    ADDED_KONG = "added_kong"
    DECLARE_READY = "declare_ready"


@dataclass(frozen=True)
class Action:
    kind: ActionKind
    tile_ids: tuple[int, ...] = ()
    meld_index: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.kind, ActionKind) or not isinstance(
            self.tile_ids, tuple
        ):
            raise TypeError("動作必須使用 ActionKind 與實體牌 ID tuple")
        for tile_id in self.tile_ids:
            Tile(tile_id)
        if len(set(self.tile_ids)) != len(self.tile_ids):
            raise ValueError("動作不可重複引用同一張牌")
        sizes = {
            ActionKind.DISCARD: 1,
            ActionKind.CHI: 2,
            ActionKind.PONG: 2,
            ActionKind.EXPOSED_KONG: 3,
            ActionKind.CONCEALED_KONG: 4,
            ActionKind.ADDED_KONG: 1,
            ActionKind.DECLARE_READY: 1,
        }
        if len(self.tile_ids) != sizes.get(self.kind, 0):
            raise ValueError("動作參數張數不符")
        if self.kind == ActionKind.ADDED_KONG:
            if type(self.meld_index) is not int or self.meld_index < 0:
                raise ValueError("加槓必須指定非負的副露索引")
        elif self.meld_index is not None:
            raise ValueError("此動作不可指定副露索引")

    def to_dict(self) -> dict:
        return {
            "kind": self.kind.value,
            "tile_ids": list(self.tile_ids),
            "meld_index": self.meld_index,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Action":
        if not isinstance(data, dict) or set(data) != {
            "kind",
            "tile_ids",
            "meld_index",
        }:
            raise ValueError("動作資料欄位不符")
        if not isinstance(data["tile_ids"], list):
            raise TypeError("tile_ids 必須是清單")
        return cls(
            ActionKind(data["kind"]), tuple(data["tile_ids"]), data["meld_index"]
        )
