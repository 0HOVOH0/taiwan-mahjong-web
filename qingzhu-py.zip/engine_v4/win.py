"""十六張一般完成型：五面子一對。只判結構，不裁決最低台數或胡牌權利。"""

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from numbers import Integral
from typing import Any

from engine_v4.state import PlayerState, validate_meld
from engine_v4.tiles import NON_FLOWER_TYPE_COUNT, Tile


class HandMeldKind(str, Enum):
    SEQUENCE = "sequence"
    TRIPLET = "triplet"


@dataclass(frozen=True)
class HandMeld:
    kind: HandMeldKind
    type_ids: tuple[int, int, int]


@dataclass(frozen=True)
class WinDecomposition:
    pair_type_id: int
    concealed_melds: tuple[HandMeld, ...]
    fixed_meld_count: int

    def to_dict(self) -> dict[str, Any]:
        """只含一般 JSON 資料；牌 ID 都是牌型 ID，不是實體牌 ID。"""
        return {
            "pair": [self.pair_type_id, self.pair_type_id],
            "concealed_melds": [
                {"kind": meld.kind.value, "type_ids": list(meld.type_ids)}
                for meld in self.concealed_melds
            ],
            "fixed_meld_count": self.fixed_meld_count,
        }


def _normalise_counts(counts34: Iterable[int]) -> tuple[int, ...]:
    if isinstance(counts34, (str, bytes)):
        raise TypeError("counts34 必須是 34 個整數，不可傳文字")
    counts = tuple(counts34)
    if len(counts) != NON_FLOWER_TYPE_COUNT:
        raise ValueError("counts34 必須剛好有 34 個元素，花牌另記")
    for count in counts:
        if isinstance(count, bool) or not isinstance(count, Integral):
            raise TypeError("counts34 每項必須是整數")
        if not 0 <= count <= 4:
            raise ValueError("每種非花牌的張數必須介於 0～4")
    return tuple(int(count) for count in counts)


def _normalise_fixed_count(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError("fixed_meld_count 必須是整數")
    if not 0 <= value <= 5:
        raise ValueError("已登記面子數必須介於 0～5")
    return int(value)


@lru_cache(maxsize=8192)
def _split_melds(
    counts: tuple[int, ...], groups_left: int
) -> tuple[tuple[tuple[int, int, int], ...], ...]:
    """每次從最小剩餘牌開始，完整嘗試刻子與順子，不用貪心固定拆法。"""
    if groups_left == 0:
        return ((),) if not any(counts) else ()
    if sum(counts) != groups_left * 3:
        return ()
    first = next(i for i, count in enumerate(counts) if count)
    choices = []
    if counts[first] >= 3:
        choices.append((first, first, first))
    # 僅萬筒條可成順；每門的 8、9 不可當順子的起點。
    if first < 27 and first % 9 <= 6 and counts[first + 1] and counts[first + 2]:
        choices.append((first, first + 1, first + 2))
    results = set()
    for group in choices:
        remaining = list(counts)
        for type_id in group:
            remaining[type_id] -= 1
        for tail in _split_melds(tuple(remaining), groups_left - 1):
            # 面子順序不影響拆法；排序後去除重複排列。
            results.add(tuple(sorted((group, *tail))))
    return tuple(sorted(results))


def find_win_decompositions(
    counts34: Iterable[int], *, fixed_meld_count: int = 0
) -> tuple[WinDecomposition, ...]:
    """回傳所有一般完成型拆法。

    counts34 只包含暗手牌，已包含完成型最後一張牌，不包含副露或花牌。
    k 組已登記面子需要 3*(5-k)+2 張暗手牌；槓在此只算一組。
    合法格式但不成型回傳空 tuple；無效格式、第五張同牌等輸入拋例外。
    本入口沒有固定面子的牌面資料；要跨手牌與副露驗證，使用 analyze_player_hand。
    """
    counts = _normalise_counts(counts34)
    fixed_count = _normalise_fixed_count(fixed_meld_count)
    needed = 5 - fixed_count
    if sum(counts) != needed * 3 + 2:
        return ()
    results = []
    for pair, count in enumerate(counts):
        if count < 2:
            continue
        remaining = list(counts)
        remaining[pair] -= 2
        for groups in _split_melds(tuple(remaining), needed):
            melds = tuple(
                HandMeld(
                    HandMeldKind.TRIPLET
                    if group[0] == group[1]
                    else HandMeldKind.SEQUENCE,
                    group,
                )
                for group in groups
            )
            results.append(WinDecomposition(pair, melds, fixed_count))
    return tuple(results)


def is_winning_hand(counts34: Iterable[int], *, fixed_meld_count: int = 0) -> bool:
    """一般牌型結構是否完成；尚不代表符合最低台數、過水或回合限制。"""
    return bool(find_win_decompositions(counts34, fixed_meld_count=fixed_meld_count))


def analyze_player_hand(
    player: PlayerState, *, winning_tile_id: int | None = None
) -> tuple[WinDecomposition, ...]:
    """接既有玩家狀態；不修改手牌、副露、花牌或牌河。

    自摸型態：完成牌已在 hand，winning_tile_id 留為 None。
    接別家棄牌：hand 仍是未加入棄牌的手牌，另傳該張實體 ID。
    呼叫端仍需由合法動作引擎確認來源、時機、台數與胡牌權利。
    """
    if not isinstance(player, PlayerState):
        raise TypeError("player 必須是 PlayerState")
    if type(player.seat) is not int or not 0 <= player.seat < 4:
        raise ValueError("玩家座位必須是 0～3")
    fixed_count = _normalise_fixed_count(len(player.melds))
    physical_ids = list(player.hand) + list(player.flowers) + list(player.river)
    hand_ids = list(player.hand)
    for meld in player.melds:
        validate_meld(meld, player.seat)
        physical_ids.extend(meld.tile_ids)
    if winning_tile_id is not None:
        hand_ids.append(winning_tile_id)
        physical_ids.append(winning_tile_id)
    # ID 驗證也拒絕花牌越界、bool 等；實體 ID 不可重複使用。
    for tile_id in physical_ids:
        Tile(tile_id)
    if len(set(physical_ids)) != len(physical_ids):
        raise ValueError("玩家區域或胡牌候選重複引用同一張實體牌")
    for tile_id in hand_ids + list(player.river):
        if Tile(tile_id).is_flower:
            raise ValueError("暗手牌、牌河或胡牌候選不可使用花牌")
    if any(not Tile(tile_id).is_flower for tile_id in player.flowers):
        raise ValueError("flowers 只能包含花牌")
    counts = Counter(Tile(tile_id).type_id for tile_id in hand_ids)
    return find_win_decompositions(
        [counts[type_id] for type_id in range(34)], fixed_meld_count=fixed_count
    )
